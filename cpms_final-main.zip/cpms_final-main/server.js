// Production server for the MOH Planning application
const express = require('express');
const path = require('path');
const fs = require('fs');
const { execSync } = require('child_process');

// Configuration
const PORT = process.env.PORT || 3000;
const DJANGO_PORT = process.env.DJANGO_PORT || 8000;
const app = express();

// Check if we need to start Django
const DJANGO_AUTO_START = process.env.DJANGO_AUTO_START === 'true';
if (DJANGO_AUTO_START) {
  console.log('Auto-starting Django server...');
  try {
    execSync('python manage.py runserver 0.0.0.0:8000 &', {
      stdio: 'inherit'
    });
  } catch (err) {
    console.error('Failed to start Django server:', err);
  }
}

// Serve static files from the React app
const distPath = path.join(__dirname, 'dist');
if (!fs.existsSync(distPath)) {
  console.error('Error: dist directory not found. Please run "npm run build" first.');
  process.exit(1);
}

app.use(express.static(distPath));

// API proxy to Django
app.use('/api', (req, res) => {
  res.redirect(`http://localhost:${DJANGO_PORT}/api${req.url}`);
});

// Admin proxy to Django
app.use('/admin', (req, res) => {
  res.redirect(`http://localhost:${DJANGO_PORT}/admin${req.url}`);
});

// Always return the main index.html for any other route
app.get('*', (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

// Start the server
app.listen(PORT, () => {
  console.log(`🚀 Frontend server is running on port ${PORT}`);
  console.log(`Django API expected at http://localhost:${DJANGO_PORT}`);
  console.log(`Open http://localhost:${PORT} in your browser`);
});