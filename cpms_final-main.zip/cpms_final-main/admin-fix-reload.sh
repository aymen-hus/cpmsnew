#!/bin/bash
set -e

echo "Fixing Django Admin 504 Gateway Timeout..."

# Create necessary directories with proper permissions
sudo mkdir -p /var/www/moh-planning/logs
sudo chown -R www-data:www-data /var/www/moh-planning/logs

# Copy the new configuration files
sudo cp moh-planning.nginx.conf /etc/nginx/sites-available/moh-planning
sudo cp gunicorn.conf.py /var/www/moh-planning/

# Check if static files exist, if not collect them
if [ ! -d "/var/www/moh-planning/staticfiles/admin" ]; then
    echo "Admin static files missing, collecting static files..."
    cd /var/www/moh-planning
    source venv/bin/activate
    python manage.py collectstatic --noinput
    sudo chown -R www-data:www-data /var/www/moh-planning/staticfiles
fi

# Test nginx configuration
echo "Testing Nginx configuration..."
sudo nginx -t

# Reload systemd daemon
echo "Reloading systemd daemon..."
sudo systemctl daemon-reload

# Restart services with new timeout settings
echo "Restarting services with new timeout settings..."
sudo systemctl restart moh-planning
sudo systemctl restart nginx

# Check if services are running
echo "Checking service status..."
sudo systemctl status moh-planning --no-pager
sudo systemctl status nginx --no-pager

echo "Done! Django admin should now be accessible."
echo "If you still experience issues, check the logs:"
echo "  sudo tail -f /var/www/moh-planning/logs/gunicorn-error.log"
echo "  sudo tail -f /var/log/nginx/moh-planning-error.log"