from django.db import migrations, models

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '0013_update_air_transport_model'),
    ]

    operations = [
        migrations.CreateModel(
            name='ProcurementItem',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('category', models.CharField(choices=[
                    ('OFFICE_SUPPLIES', 'Office Supplies'),
                    ('COMPUTER_EQUIPMENT', 'Computer Equipment'),
                    ('FURNITURE', 'Furniture'),
                    ('CLEANING_SUPPLIES', 'Cleaning Supplies'),
                    ('COMMUNICATION', 'Communication'),
                    ('STATIONERY', 'Stationery'),
                    ('ELECTRONICS', 'Electronics'),
                    ('MEDICAL_SUPPLIES', 'Medical Supplies'),
                    ('TRANSPORTATION', 'Transportation'),
                    ('OTHER', 'Other')
                ], max_length=20)),
                ('name', models.CharField(max_length=255)),
                ('unit', models.CharField(choices=[
                    ('PIECE', 'Piece'),
                    ('BOX', 'Box'),
                    ('PACK', 'Pack'),
                    ('SET', 'Set'),
                    ('UNIT', 'Unit'),
                    ('DOZEN', 'Dozen'),
                    ('KILOGRAM', 'Kilogram'),
                    ('METER', 'Meter'),
                    ('LITER', 'Liter'),
                    ('EACH', 'Each')
                ], max_length=20)),
                ('unit_price', models.DecimalField(decimal_places=2, max_digits=12)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
            options={
                'ordering': ['category', 'name'],
                'unique_together': {('category', 'name', 'unit')},
            },
        ),
        migrations.AddIndex(
            model_name='procurementitem',
            index=models.Index(fields=['category'], name='idx_procurement_category'),
        ),
        migrations.AddIndex(
            model_name='procurementitem',
            index=models.Index(fields=['name'], name='idx_procurement_name'),
        ),
    ]