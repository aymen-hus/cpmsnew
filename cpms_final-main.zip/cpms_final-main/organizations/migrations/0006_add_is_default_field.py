from django.db import migrations, models

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '0005_update_baseline_field'),
    ]

    operations = [
        migrations.AddField(
            model_name='strategicinitiative',
            name='is_default',
            field=models.BooleanField(
                default=True,
                help_text="Whether this initiative is a default one created by admin"
            ),
        ),
        migrations.AddField(
            model_name='strategicobjective',
            name='is_default',
            field=models.BooleanField(
                default=True,
                help_text="Whether this objective is a default one created by admin"
            ),
        ),
        migrations.AddField(
            model_name='program',
            name='is_default',
            field=models.BooleanField(
                default=True,
                help_text="Whether this program is a default one created by admin"
            ),
        ),
        migrations.AddField(
            model_name='subprogram',
            name='is_default',
            field=models.BooleanField(
                default=True,
                help_text="Whether this subprogram is a default one created by admin"
            ),
        ),
    ]