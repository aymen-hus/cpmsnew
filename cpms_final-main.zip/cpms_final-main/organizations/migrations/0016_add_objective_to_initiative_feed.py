from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '0015_add_initial_procurement_items'),
    ]

    operations = [
        migrations.AddField(
            model_name='initiativefeed',
            name='strategic_objective',
            field=models.ForeignKey(
                blank=True,
                help_text='The strategic objective this initiative feed belongs to',
                null=True,
                on_delete=django.db.models.deletion.CASCADE,
                related_name='initiative_feeds',
                to='organizations.strategicobjective'
            ),
        ),
        migrations.AddIndex(
            model_name='initiativefeed',
            index=models.Index(fields=['strategic_objective'], name='idx_initiative_feed_objective'),
        ),
    ]