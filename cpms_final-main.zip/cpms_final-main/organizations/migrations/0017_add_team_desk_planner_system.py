from django.db import migrations, models
import django.db.models.deletion
import django.core.validators

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '0016_add_objective_to_initiative_feed'),
    ]

    operations = [
        # Add TEAM_DESK_PLANNER role to OrganizationUser choices
        migrations.AlterField(
            model_name='organizationuser',
            name='role',
            field=models.CharField(
                choices=[
                    ('ADMIN', 'Admin'),
                    ('PLANNER', 'Planner'),
                    ('EVALUATOR', 'Evaluator'),
                    ('TEAM_DESK_PLANNER', 'Team/Desk Planner')
                ],
                max_length=20
            ),
        ),

        # Create DetailActivity model
        migrations.CreateModel(
            name='DetailActivity',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=255)),
                ('weight', models.DecimalField(
                    decimal_places=2,
                    max_digits=5,
                    validators=[
                        django.core.validators.MinValueValidator(0.01),
                        django.core.validators.MaxValueValidator(100)
                    ]
                )),
                ('baseline', models.CharField(max_length=255, default='', blank=True)),
                ('target_type', models.CharField(
                    choices=[
                        ('cumulative', 'Cumulative'),
                        ('increasing', 'Increasing'),
                        ('decreasing', 'Decreasing'),
                        ('constant', 'Constant')
                    ],
                    default='cumulative',
                    max_length=20
                )),
                ('q1_target', models.DecimalField(
                    decimal_places=2,
                    default=0,
                    max_digits=10,
                    verbose_name='Q1 Target (Jul-Sep)'
                )),
                ('q2_target', models.DecimalField(
                    decimal_places=2,
                    default=0,
                    max_digits=10,
                    verbose_name='Q2 Target (Oct-Dec)'
                )),
                ('q3_target', models.DecimalField(
                    decimal_places=2,
                    default=0,
                    max_digits=10,
                    verbose_name='Q3 Target (Jan-Mar)'
                )),
                ('q4_target', models.DecimalField(
                    decimal_places=2,
                    default=0,
                    max_digits=10,
                    verbose_name='Q4 Target (Apr-Jun)'
                )),
                ('annual_target', models.DecimalField(
                    decimal_places=2,
                    default=0,
                    max_digits=10
                )),
                ('selected_months', models.JSONField(null=True, blank=True)),
                ('selected_quarters', models.JSONField(null=True, blank=True)),
                ('main_activity', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='detail_activities',
                    to='organizations.mainactivity'
                )),
                ('organization', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='detail_activities',
                    to='organizations.organization',
                    help_text='The team/desk organization that created this detail activity'
                )),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
        ),

        # Create TeamDeskPlan model
        migrations.CreateModel(
            name='TeamDeskPlan',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('status', models.CharField(
                    choices=[
                        ('DRAFT', 'Draft'),
                        ('SUBMITTED', 'Submitted'),
                        ('APPROVED', 'Approved'),
                        ('REJECTED', 'Rejected')
                    ],
                    default='DRAFT',
                    max_length=20
                )),
                ('organization', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='team_desk_plans',
                    to='organizations.organization',
                    help_text='The organization this team/desk plan belongs to'
                )),
                ('team_desk', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='desk_plans',
                    to='organizations.organization',
                    help_text='The specific team/desk creating this plan'
                )),
                ('leo_eo_plan', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='team_desk_plans',
                    to='organizations.plan',
                    help_text='The approved LEO/EO plan this is based on'
                )),
                ('objectives', models.ManyToManyField(
                    to='organizations.strategicobjective',
                    related_name='team_desk_plans',
                    blank=True
                )),
                ('initiatives', models.ManyToManyField(
                    to='organizations.strategicinitiative',
                    related_name='team_desk_plans',
                    blank=True
                )),
                ('performance_measures', models.ManyToManyField(
                    to='organizations.performancemeasure',
                    related_name='team_desk_plans',
                    blank=True
                )),
                ('main_activities', models.ManyToManyField(
                    to='organizations.mainactivity',
                    related_name='team_desk_plans',
                    blank=True
                )),
                ('detail_activities', models.ManyToManyField(
                    to='organizations.detailactivity',
                    related_name='team_desk_plans',
                    blank=True
                )),
                ('submitted_at', models.DateTimeField(null=True, blank=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
        ),

        # Create TeamDeskPlanReview model
        migrations.CreateModel(
            name='TeamDeskPlanReview',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('status', models.CharField(
                    choices=[('APPROVED', 'Approved'), ('REJECTED', 'Rejected')],
                    max_length=20
                )),
                ('feedback', models.TextField()),
                ('reviewed_at', models.DateTimeField(auto_now_add=True)),
                ('plan', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='reviews',
                    to='organizations.teamdeskplan'
                )),
                ('reviewer', models.ForeignKey(
                    on_delete=django.db.models.deletion.SET_NULL,
                    null=True,
                    related_name='team_desk_reviews',
                    to='organizations.organizationuser'
                )),
            ],
        ),

        # Add indexes for better performance
        migrations.AddIndex(
            model_name='detailactivity',
            index=models.Index(fields=['main_activity'], name='idx_detail_activity_main'),
        ),
        migrations.AddIndex(
            model_name='detailactivity',
            index=models.Index(fields=['organization'], name='idx_detail_activity_org'),
        ),
        migrations.AddIndex(
            model_name='teamdeskplan',
            index=models.Index(fields=['status'], name='idx_team_desk_plan_status'),
        ),
        migrations.AddIndex(
            model_name='teamdeskplan',
            index=models.Index(fields=['organization'], name='idx_team_desk_plan_org'),
        ),
    ]