from django.db import migrations
from decimal import Decimal

def add_initial_procurement_items(apps, schema_editor):
    """
    Add initial procurement items to the database
    """
    ProcurementItem = apps.get_model('organizations', 'ProcurementItem')
    
    # Initial procurement items with their categories, units, and prices
    procurement_items = [
        # Office Supplies
        {'category': 'OFFICE_SUPPLIES', 'name': 'Air Freshener', 'unit': 'PIECE', 'unit_price': Decimal('150')},
        {'category': 'OFFICE_SUPPLIES', 'name': 'Binding Ring', 'unit': 'BOX', 'unit_price': Decimal('50')},
        {'category': 'OFFICE_SUPPLIES', 'name': 'Paper Clip', 'unit': 'BOX', 'unit_price': Decimal('20')},
        {'category': 'OFFICE_SUPPLIES', 'name': 'Paper Fastener', 'unit': 'BOX', 'unit_price': Decimal('30')},
        {'category': 'OFFICE_SUPPLIES', 'name': 'Paper Punch', 'unit': 'PIECE', 'unit_price': Decimal('300')},
        {'category': 'OFFICE_SUPPLIES', 'name': 'File Cabinet', 'unit': 'PIECE', 'unit_price': Decimal('5000')},
        {'category': 'OFFICE_SUPPLIES', 'name': 'File Holder', 'unit': 'PIECE', 'unit_price': Decimal('200')},
        {'category': 'OFFICE_SUPPLIES', 'name': 'Divider', 'unit': 'PIECE', 'unit_price': Decimal('100')},
        
        # Stationery
        {'category': 'STATIONERY', 'name': 'Stationary', 'unit': 'SET', 'unit_price': Decimal('500')},
        {'category': 'STATIONERY', 'name': 'Marker', 'unit': 'PIECE', 'unit_price': Decimal('50')},
        {'category': 'STATIONERY', 'name': 'Note Book', 'unit': 'PIECE', 'unit_price': Decimal('100')},
        {'category': 'STATIONERY', 'name': 'Note Pad', 'unit': 'PIECE', 'unit_price': Decimal('50')},
        {'category': 'STATIONERY', 'name': 'Paper', 'unit': 'PACK', 'unit_price': Decimal('200')},
        {'category': 'STATIONERY', 'name': 'Paper Ream', 'unit': 'PIECE', 'unit_price': Decimal('400')},
        {'category': 'STATIONERY', 'name': 'Envelope', 'unit': 'PACK', 'unit_price': Decimal('10')},
        
        # Computer Equipment
        {'category': 'COMPUTER_EQUIPMENT', 'name': 'Computer', 'unit': 'PIECE', 'unit_price': Decimal('30000')},
        {'category': 'COMPUTER_EQUIPMENT', 'name': 'Flash Disk', 'unit': 'PIECE', 'unit_price': Decimal('500')},
        {'category': 'COMPUTER_EQUIPMENT', 'name': 'External Hard Drive', 'unit': 'PIECE', 'unit_price': Decimal('3000')},
        {'category': 'COMPUTER_EQUIPMENT', 'name': 'Hard Disk', 'unit': 'PIECE', 'unit_price': Decimal('2000')},
        {'category': 'COMPUTER_EQUIPMENT', 'name': 'Printer', 'unit': 'PIECE', 'unit_price': Decimal('20000')},
        {'category': 'COMPUTER_EQUIPMENT', 'name': 'Scanner', 'unit': 'PIECE', 'unit_price': Decimal('15000')},
        {'category': 'COMPUTER_EQUIPMENT', 'name': 'Projector', 'unit': 'PIECE', 'unit_price': Decimal('30000')},
        {'category': 'COMPUTER_EQUIPMENT', 'name': 'UPS', 'unit': 'PIECE', 'unit_price': Decimal('3000')},
        {'category': 'COMPUTER_EQUIPMENT', 'name': 'Toner', 'unit': 'PIECE', 'unit_price': Decimal('5000')},
        
        # Electronics
        {'category': 'ELECTRONICS', 'name': 'Calculator', 'unit': 'PIECE', 'unit_price': Decimal('300')},
        {'category': 'ELECTRONICS', 'name': 'Camera', 'unit': 'PIECE', 'unit_price': Decimal('15000')},
        {'category': 'ELECTRONICS', 'name': 'Fax Machine', 'unit': 'PIECE', 'unit_price': Decimal('10000')},
        {'category': 'ELECTRONICS', 'name': 'Copier', 'unit': 'PIECE', 'unit_price': Decimal('50000')},
        {'category': 'ELECTRONICS', 'name': 'Laminator', 'unit': 'PIECE', 'unit_price': Decimal('5000')},
        
        # Communication
        {'category': 'COMMUNICATION', 'name': 'Air Time', 'unit': 'PIECE', 'unit_price': Decimal('100')},
        {'category': 'COMMUNICATION', 'name': 'CDMA', 'unit': 'PIECE', 'unit_price': Decimal('2000')},
        {'category': 'COMMUNICATION', 'name': 'D Link', 'unit': 'PIECE', 'unit_price': Decimal('1000')},
        {'category': 'COMMUNICATION', 'name': 'Network Cable', 'unit': 'METER', 'unit_price': Decimal('1000')},
        
        # Furniture
        {'category': 'FURNITURE', 'name': 'Chair', 'unit': 'PIECE', 'unit_price': Decimal('3000')},
        {'category': 'FURNITURE', 'name': 'Table', 'unit': 'PIECE', 'unit_price': Decimal('4000')},
        {'category': 'FURNITURE', 'name': 'Shelf', 'unit': 'PIECE', 'unit_price': Decimal('3000')},
        {'category': 'FURNITURE', 'name': 'Carpet', 'unit': 'PIECE', 'unit_price': Decimal('2000')},
        {'category': 'FURNITURE', 'name': 'Curtain', 'unit': 'PIECE', 'unit_price': Decimal('3000')},
        {'category': 'FURNITURE', 'name': 'Coat Hanger', 'unit': 'PIECE', 'unit_price': Decimal('200')},
        
        # Cleaning Supplies
        {'category': 'CLEANING_SUPPLIES', 'name': 'Broom', 'unit': 'PIECE', 'unit_price': Decimal('100')},
        {'category': 'CLEANING_SUPPLIES', 'name': 'Mop', 'unit': 'PIECE', 'unit_price': Decimal('200')},
        {'category': 'CLEANING_SUPPLIES', 'name': 'Dust Bin', 'unit': 'PIECE', 'unit_price': Decimal('300')},
        {'category': 'CLEANING_SUPPLIES', 'name': 'Detergent', 'unit': 'PIECE', 'unit_price': Decimal('100')},
        {'category': 'CLEANING_SUPPLIES', 'name': 'Disinfectant', 'unit': 'PIECE', 'unit_price': Decimal('200')},
        {'category': 'CLEANING_SUPPLIES', 'name': 'Soap', 'unit': 'PIECE', 'unit_price': Decimal('50')},
        {'category': 'CLEANING_SUPPLIES', 'name': 'Toilet Paper', 'unit': 'PACK', 'unit_price': Decimal('100')},
        {'category': 'CLEANING_SUPPLIES', 'name': 'Scouring Powder', 'unit': 'PIECE', 'unit_price': Decimal('100')},
        {'category': 'CLEANING_SUPPLIES', 'name': 'Vacuum Cleaner', 'unit': 'PIECE', 'unit_price': Decimal('10000')},
        {'category': 'CLEANING_SUPPLIES', 'name': 'Water Filter', 'unit': 'PIECE', 'unit_price': Decimal('5000')},
        
        # Transportation
        {'category': 'TRANSPORTATION', 'name': 'Car', 'unit': 'PIECE', 'unit_price': Decimal('2000000')},
        {'category': 'TRANSPORTATION', 'name': 'Car Part', 'unit': 'PIECE', 'unit_price': Decimal('5000')},
        
        # Other
        {'category': 'OTHER', 'name': 'Bag', 'unit': 'PIECE', 'unit_price': Decimal('800')},
        {'category': 'OTHER', 'name': 'Glove', 'unit': 'PAIR', 'unit_price': Decimal('100')},
        {'category': 'OTHER', 'name': 'Shoe', 'unit': 'PAIR', 'unit_price': Decimal('2000')},
        {'category': 'OTHER', 'name': 'T Shirt', 'unit': 'PIECE', 'unit_price': Decimal('500')},
        {'category': 'OTHER', 'name': 'Cloth', 'unit': 'PIECE', 'unit_price': Decimal('1000')},
        {'category': 'OTHER', 'name': 'Cloth Accessory', 'unit': 'PIECE', 'unit_price': Decimal('500')},
        {'category': 'OTHER', 'name': 'Textile', 'unit': 'PIECE', 'unit_price': Decimal('1000')},
        {'category': 'OTHER', 'name': 'Gawn Tetron', 'unit': 'PIECE', 'unit_price': Decimal('2000')},
        {'category': 'OTHER', 'name': 'Generator', 'unit': 'PIECE', 'unit_price': Decimal('50000')},
        {'category': 'OTHER', 'name': 'Antivirus', 'unit': 'PIECE', 'unit_price': Decimal('1500')},
        {'category': 'OTHER', 'name': 'Surge Arrestor', 'unit': 'PIECE', 'unit_price': Decimal('1000')},
        {'category': 'OTHER', 'name': 'Rope', 'unit': 'METER', 'unit_price': Decimal('100')},
        {'category': 'OTHER', 'name': 'Fantastic Glue', 'unit': 'PIECE', 'unit_price': Decimal('50')},
        {'category': 'OTHER', 'name': 'Uhu', 'unit': 'PIECE', 'unit_price': Decimal('100')},
        {'category': 'OTHER', 'name': 'Cassette', 'unit': 'PIECE', 'unit_price': Decimal('100')},
        {'category': 'OTHER', 'name': 'CD', 'unit': 'PIECE', 'unit_price': Decimal('50')},
        {'category': 'OTHER', 'name': 'Carbon Paper', 'unit': 'PACK', 'unit_price': Decimal('50')},
    ]
    
    for item_data in procurement_items:
        ProcurementItem.objects.get_or_create(
            category=item_data['category'],
            name=item_data['name'],
            unit=item_data['unit'],
            defaults={'unit_price': item_data['unit_price']}
        )

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '0014_add_procurement_item_model'),
    ]

    operations = [
        migrations.RunPython(add_initial_procurement_items),
    ]