from django.db import migrations
from decimal import Decimal

def add_initial_locations(apps, schema_editor):
    Location = apps.get_model('organizations', 'Location')
    
    locations_data = [
        {'name': 'Addis Ababa', 'region': 'Addis Ababa', 'is_hardship_area': False},
        {'name': 'Adama', 'region': 'Oromia', 'is_hardship_area': False},
        {'name': 'Bahir Dar', 'region': 'Amhara', 'is_hardship_area': False},
        {'name': 'Mekele', 'region': 'Tigray', 'is_hardship_area': False},
        {'name': 'Hawassa', 'region': 'Sidama', 'is_hardship_area': False},
        {'name': 'Gambella', 'region': 'Gambela', 'is_hardship_area': True},
        {'name': 'Semera', 'region': 'Afar', 'is_hardship_area': True},
        {'name': 'Jigjiga', 'region': 'Somali', 'is_hardship_area': True},
    ]
    
    for data in locations_data:
        Location.objects.get_or_create(
            name=data['name'],
            defaults=data
        )

def add_perdiem_rates(apps, schema_editor):
    Location = apps.get_model('organizations', 'Location')
    PerDiem = apps.get_model('organizations', 'PerDiem')
    
    perdiem_data = [
        {'location_name': 'Addis Ababa', 'amount': Decimal('1200'), 'hardship_allowance_amount': Decimal('0')},
        {'location_name': 'Adama', 'amount': Decimal('1000'), 'hardship_allowance_amount': Decimal('0')},
        {'location_name': 'Bahir Dar', 'amount': Decimal('1100'), 'hardship_allowance_amount': Decimal('0')},
        {'location_name': 'Mekele', 'amount': Decimal('1100'), 'hardship_allowance_amount': Decimal('0')},
        {'location_name': 'Hawassa', 'amount': Decimal('1000'), 'hardship_allowance_amount': Decimal('0')},
        {'location_name': 'Gambella', 'amount': Decimal('1200'), 'hardship_allowance_amount': Decimal('200')},
        {'location_name': 'Semera', 'amount': Decimal('1200'), 'hardship_allowance_amount': Decimal('200')},
        {'location_name': 'Jigjiga', 'amount': Decimal('1200'), 'hardship_allowance_amount': Decimal('200')},
    ]
    
    for data in perdiem_data:
        try:
            location = Location.objects.get(name=data['location_name'])
            PerDiem.objects.get_or_create(
                location=location,
                defaults={
                    'amount': data['amount'],
                    'hardship_allowance_amount': data['hardship_allowance_amount']
                }
            )
        except Location.DoesNotExist:
            print(f"Location {data['location_name']} not found")

def add_accommodation_rates(apps, schema_editor):
    Location = apps.get_model('organizations', 'Location')
    Accommodation = apps.get_model('organizations', 'Accommodation')
    
    # For each location, add all service types
    service_types = ['LUNCH', 'HALL_REFRESHMENT', 'DINNER', 'BED', 'FULL_BOARD']
    
    # Base prices for Addis Ababa
    base_prices = {
        'LUNCH': Decimal('400'),
        'HALL_REFRESHMENT': Decimal('800'),
        'DINNER': Decimal('500'),
        'BED': Decimal('1500'),
        'FULL_BOARD': Decimal('2400')
    }
    
    # Location price modifiers (as percentage of Addis prices)
    location_modifiers = {
        'Addis Ababa': 1.0,     # 100% (baseline)
        'Adama': 0.85,          # 85%
        'Bahir Dar': 0.9,       # 90%
        'Mekele': 0.9,          # 90%
        'Hawassa': 0.85,        # 85%
        'Gambella': 1.1,        # 110%
        'Semera': 1.1,          # 110%
        'Jigjiga': 1.1          # 110%
    }
    
    for location_name, modifier in location_modifiers.items():
        try:
            location = Location.objects.get(name=location_name)
            
            for service_type in service_types:
                base_price = base_prices[service_type]
                adjusted_price = base_price * Decimal(str(modifier))
                
                Accommodation.objects.get_or_create(
                    location=location,
                    service_type=service_type,
                    defaults={
                        'price': adjusted_price.quantize(Decimal('0.01'))
                    }
                )
        except Location.DoesNotExist:
            print(f"Location {location_name} not found")

def add_participant_session_costs(apps, schema_editor):
    ParticipantCost = apps.get_model('organizations', 'ParticipantCost')
    SessionCost = apps.get_model('organizations', 'SessionCost')
    
    # Participant costs
    participant_costs = [
        {'cost_type': 'FLASH_DISK', 'price': Decimal('500')},
        {'cost_type': 'STATIONARY', 'price': Decimal('200')},
        {'cost_type': 'ALL', 'price': Decimal('700')}
    ]
    
    for data in participant_costs:
        ParticipantCost.objects.get_or_create(
            cost_type=data['cost_type'],
            defaults={'price': data['price']}
        )
    
    # Session costs
    session_costs = [
        {'cost_type': 'FLIP_CHART', 'price': Decimal('300')},
        {'cost_type': 'MARKER', 'price': Decimal('150')},
        {'cost_type': 'TONER_PAPER', 'price': Decimal('1000')},
        {'cost_type': 'ALL', 'price': Decimal('1450')}
    ]
    
    for data in session_costs:
        SessionCost.objects.get_or_create(
            cost_type=data['cost_type'],
            defaults={'price': data['price']}
        )

def add_printing_costs(apps, schema_editor):
    PrintingCost = apps.get_model('organizations', 'PrintingCost')
    
    printing_costs = [
        {'document_type': 'MANUAL', 'price_per_page': Decimal('50')},
        {'document_type': 'BOOKLET', 'price_per_page': Decimal('40')},
        {'document_type': 'LEAFLET', 'price_per_page': Decimal('30')},
        {'document_type': 'BROCHURE', 'price_per_page': Decimal('35')}
    ]
    
    for data in printing_costs:
        PrintingCost.objects.get_or_create(
            document_type=data['document_type'],
            defaults={'price_per_page': data['price_per_page']}
        )

def add_supervisor_costs(apps, schema_editor):
    SupervisorCost = apps.get_model('organizations', 'SupervisorCost')
    
    supervisor_costs = [
        {'cost_type': 'MOBILE_CARD_300', 'amount': Decimal('300')},
        {'cost_type': 'MOBILE_CARD_500', 'amount': Decimal('500')},
        {'cost_type': 'STATIONARY', 'amount': Decimal('200')},
        {'cost_type': 'ALL', 'amount': Decimal('1000')}
    ]
    
    for data in supervisor_costs:
        SupervisorCost.objects.get_or_create(
            cost_type=data['cost_type'],
            defaults={'amount': data['amount']}
        )

def add_transport_costs(apps, schema_editor):
    Location = apps.get_model('organizations', 'Location')
    LandTransport = apps.get_model('organizations', 'LandTransport')
    AirTransport = apps.get_model('organizations', 'AirTransport')
    
    # Get Addis Ababa as reference point
    try:
        addis = Location.objects.get(name='Addis Ababa')
        
        # Define transport costs from/to Addis to other locations
        transport_data = [
            {'location': 'Adama', 'land_price': Decimal('1000'), 'air_single': Decimal('0'), 'air_round': Decimal('0')},
            {'location': 'Bahir Dar', 'land_price': Decimal('2000'), 'air_single': Decimal('5000'), 'air_round': Decimal('9000')},
            {'location': 'Mekele', 'land_price': Decimal('2500'), 'air_single': Decimal('6000'), 'air_round': Decimal('11000')},
            {'location': 'Hawassa', 'land_price': Decimal('1200'), 'air_single': Decimal('4500'), 'air_round': Decimal('8000')},
            {'location': 'Gambella', 'land_price': Decimal('3000'), 'air_single': Decimal('7000'), 'air_round': Decimal('13000')},
            {'location': 'Semera', 'land_price': Decimal('2800'), 'air_single': Decimal('6500'), 'air_round': Decimal('12000')},
            {'location': 'Jigjiga', 'land_price': Decimal('3500'), 'air_single': Decimal('7500'), 'air_round': Decimal('14000')},
        ]
        
        for data in transport_data:
            try:
                location = Location.objects.get(name=data['location'])
                
                # Land transport (if price > 0)
                if data['land_price'] > 0:
                    LandTransport.objects.get_or_create(
                        origin=addis,
                        destination=location,
                        defaults={
                            'trip_type': 'SINGLE',
                            'price': data['land_price']
                        }
                    )
                    
                    LandTransport.objects.get_or_create(
                        origin=location,
                        destination=addis,
                        defaults={
                            'trip_type': 'SINGLE',
                            'price': data['land_price']
                        }
                    )
                
                # Air transport (if price > 0)
                if data['air_single'] > 0:
                    AirTransport.objects.get_or_create(
                        origin=addis,
                        destination=location,
                        defaults={
                            'single_trip_price': data['air_single'],
                            'round_trip_price': data['air_round']
                        }
                    )
                    
                    AirTransport.objects.get_or_create(
                        origin=location,
                        destination=addis,
                        defaults={
                            'single_trip_price': data['air_single'],
                            'round_trip_price': data['air_round']
                        }
                    )
                    
            except Location.DoesNotExist:
                print(f"Location {data['location']} not found")
                
    except Location.DoesNotExist:
        print("Addis Ababa location not found")

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '0010_add_ethiopia_regions'),
    ]

    operations = [
        migrations.RunPython(add_initial_locations),
        migrations.RunPython(add_perdiem_rates),
        migrations.RunPython(add_accommodation_rates),
        migrations.RunPython(add_participant_session_costs),
        migrations.RunPython(add_printing_costs),
        migrations.RunPython(add_supervisor_costs),
        migrations.RunPython(add_transport_costs),
    ]