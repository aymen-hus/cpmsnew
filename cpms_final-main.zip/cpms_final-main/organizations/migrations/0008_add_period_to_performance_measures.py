from django.db import migrations, models

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '0007_add_planner_weight_field'),
    ]

    operations = [
        migrations.AddField(
            model_name='performancemeasure',
            name='selected_months',
            field=models.JSONField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='performancemeasure',
            name='selected_quarters',
            field=models.JSONField(blank=True, null=True),
        ),
    ]