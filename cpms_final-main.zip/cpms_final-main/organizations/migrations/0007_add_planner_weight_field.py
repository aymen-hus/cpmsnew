from django.db import migrations, models
import organizations.models

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '0006_add_is_default_field'),
    ]

    operations = [
        migrations.AddField(
            model_name='strategicobjective',
            name='planner_weight',
            field=models.DecimalField(
                blank=True,
                decimal_places=2,
                help_text='Custom weight assigned by planner (overrides default weight)',
                max_digits=5,
                null=True,
                validators=[organizations.models.validate_positive_weight, organizations.models.validate_max_weight]
            ),
        ),
        migrations.AddIndex(
            model_name='strategicobjective',
            index=models.Index(fields=['planner_weight'], name='idx_planner_weight'),
        ),
    ]