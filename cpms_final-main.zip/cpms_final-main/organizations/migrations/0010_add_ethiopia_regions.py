from django.db import migrations, models

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '0009_costing_models'),
    ]

    operations = [
        migrations.AlterField(
            model_name='location',
            name='region',
            field=models.CharField(
                max_length=255,
                choices=[
                    ('Addis Ababa', 'Addis Ababa'),
                    ('Diredawa', 'Diredawa'),
                    ('Afar', 'Afar'),
                    ('Amhara', 'Amhara'),
                    ('Benishangul-Gumuz', 'Benishangul-Gumuz'),
                    ('Central Ethiopia', 'Central Ethiopia'),
                    ('Gambela', 'Gambela'),
                    ('Harari', 'Harari'),
                    ('Oromia', 'Oromia'),
                    ('Sidama', 'Sidama'),
                    ('Somali', 'Somali'),
                    ('South Ethiopia', 'South Ethiopia'),
                    ('Southwest', 'Southwest'),
                    ('Tigray', 'Tigray')
                ]
            ),
        ),
        migrations.AddIndex(
            model_name='location',
            index=models.Index(fields=['region'], name='idx_location_region'),
        ),
    ]