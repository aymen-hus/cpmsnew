from django.db import migrations, models

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '0005_update_baseline_field'),
    ]

    operations = [
        migrations.AddField(
            model_name='mainactivity',
            name='baseline',
            field=models.CharField(
                blank=True,
                default='',
                max_length=255,
            ),
        ),
        migrations.AddField(
            model_name='mainactivity',
            name='target_type',
            field=models.CharField(
                choices=[('cumulative', 'Cumulative'), ('increasing', 'Increasing'), ('decreasing', 'Decreasing')],
                default='cumulative',
                max_length=20
            ),
        ),
        migrations.AddField(
            model_name='mainactivity',
            name='q1_target',
            field=models.DecimalField(
                decimal_places=2,
                default=0,
                max_digits=10,
                verbose_name='Q1 Target (Jul-Sep)'
            ),
        ),
        migrations.AddField(
            model_name='mainactivity',
            name='q2_target',
            field=models.DecimalField(
                decimal_places=2,
                default=0,
                max_digits=10,
                verbose_name='Q2 Target (Oct-Dec)'
            ),
        ),
        migrations.AddField(
            model_name='mainactivity',
            name='q3_target',
            field=models.DecimalField(
                decimal_places=2,
                default=0,
                max_digits=10,
                verbose_name='Q3 Target (Jan-Mar)'
            ),
        ),
        migrations.AddField(
            model_name='mainactivity',
            name='q4_target',
            field=models.DecimalField(
                decimal_places=2,
                default=0,
                max_digits=10,
                verbose_name='Q4 Target (Apr-Jun)'
            ),
        ),
        migrations.AddField(
            model_name='mainactivity',
            name='annual_target',
            field=models.DecimalField(
                decimal_places=2,
                default=0,
                max_digits=10
            ),
        ),
        # Add field to performance measures too for consistency
        migrations.AddField(
            model_name='performancemeasure',
            name='target_type',
            field=models.CharField(
                choices=[('cumulative', 'Cumulative'), ('increasing', 'Increasing'), ('decreasing', 'Decreasing')],
                default='cumulative',
                max_length=20
            ),
        ),
    ]