from django.db import migrations
from decimal import Decimal

def ensure_perdiem_rates(apps, schema_editor):
    """
    Ensure every location has corresponding per diem and accommodation rates
    """
    Location = apps.get_model('organizations', 'Location')
    PerDiem = apps.get_model('organizations', 'PerDiem')
    Accommodation = apps.get_model('organizations', 'Accommodation')
    LandTransport = apps.get_model('organizations', 'LandTransport')
    AirTransport = apps.get_model('organizations', 'AirTransport')
    
    # Process each location
    for location in Location.objects.all():
        # Check if per diem exists for this location
        if not PerDiem.objects.filter(location=location).exists():
            # Calculate default rate based on region and hardship status
            base_amount = 1200 if location.region == 'Addis Ababa' else (
                1000 if location.region in ['Oromia', 'Diredawa'] else 1100
            )
            hardship_amount = 200 if location.is_hardship_area else 0
            
            # Create per diem record
            PerDiem.objects.create(
                location=location,
                amount=Decimal(str(base_amount)),
                hardship_allowance_amount=Decimal(str(hardship_amount))
            )
            print(f"Created per diem for {location.name}")
        
        # Check if accommodation exists for this location
        if not Accommodation.objects.filter(location=location, service_type='FULL_BOARD').exists():
            # Create accommodation records with service types
            service_types = ['LUNCH', 'HALL_REFRESHMENT', 'DINNER', 'BED', 'FULL_BOARD']
            base_prices = {
                'LUNCH': 400 if location.region == 'Addis Ababa' else (450 if location.is_hardship_area else 350),
                'HALL_REFRESHMENT': 800 if location.region == 'Addis Ababa' else (900 if location.is_hardship_area else 700),
                'DINNER': 500 if location.region == 'Addis Ababa' else (550 if location.is_hardship_area else 450),
                'BED': 1500 if location.region == 'Addis Ababa' else (1700 if location.is_hardship_area else 1200),
                'FULL_BOARD': 2400 if location.region == 'Addis Ababa' else (2700 if location.is_hardship_area else 2000)
            }
            
            for service_type in service_types:
                Accommodation.objects.create(
                    location=location,
                    service_type=service_type,
                    price=Decimal(str(base_prices[service_type]))
                )
            print(f"Created accommodation rates for {location.name}")
    
    # Create transport links to Addis Ababa if it exists
    try:
        addis = Location.objects.get(name='Addis Ababa')
        
        # Link all other locations to Addis with transport options
        for location in Location.objects.exclude(id=addis.id):
            # Add land transport if it doesn't exist
            if not LandTransport.objects.filter(
                origin=addis, destination=location
            ).exists():
                # Calculate price based on region and hardship status
                if location.region in ['Oromia', 'Diredawa', 'Addis Ababa']:
                    price = 1000
                elif location.is_hardship_area:
                    price = 3000
                else:
                    price = 2000
                    
                # Create bidirectional land transport
                LandTransport.objects.create(
                    origin=addis,
                    destination=location,
                    trip_type='SINGLE',
                    price=Decimal(str(price))
                )
                
                LandTransport.objects.create(
                    origin=location,
                    destination=addis,
                    trip_type='SINGLE',
                    price=Decimal(str(price))
                )
                
                print(f"Created land transport between Addis Ababa and {location.name}")
            
            # Add air transport for distant regions
            if (location.is_hardship_area or 
                location.region in ['Tigray', 'Somali', 'Gambela', 'Afar', 'Benishangul-Gumuz']):
                
                if not AirTransport.objects.filter(
                    origin=addis, destination=location
                ).exists():
                    # Create bidirectional air transport
                    AirTransport.objects.create(
                        origin=addis,
                        destination=location,
                        single_trip_price=Decimal('5000'),
                        round_trip_price=Decimal('9000')
                    )
                    
                    AirTransport.objects.create(
                        origin=location,
                        destination=addis,
                        single_trip_price=Decimal('5000'),
                        round_trip_price=Decimal('9000')
                    )
                    
                    print(f"Created air transport between Addis Ababa and {location.name}")
    
    except Location.DoesNotExist:
        print("Addis Ababa location not found, skipping transport creation")

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '0011_initial_costing_data'),
    ]

    operations = [
        migrations.RunPython(ensure_perdiem_rates),
    ]