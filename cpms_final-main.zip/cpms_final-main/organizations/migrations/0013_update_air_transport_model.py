from django.db import migrations, models

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '0012_ensure_perdiem_rates'),
    ]

    operations = [
        # Add the new price field first
        migrations.AddField(
            model_name='airtransport',
            name='price',
            field=models.DecimalField(decimal_places=2, default=0, max_digits=10),
            preserve_default=False,
        ),
        
        # Copy data from single_trip_price to price
        migrations.RunSQL(
            "UPDATE organizations_airtransport SET price = single_trip_price;",
            reverse_sql="UPDATE organizations_airtransport SET single_trip_price = price;"
        ),
        
        # Remove the old fields
        migrations.RemoveField(
            model_name='airtransport',
            name='single_trip_price',
        ),
        migrations.RemoveField(
            model_name='airtransport',
            name='round_trip_price',
        ),
        migrations.RemoveField(
            model_name='airtransport',
            name='trip_type',
        ),
    ]