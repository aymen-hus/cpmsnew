from django.shortcuts import render
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt, ensure_csrf_cookie
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from django.middleware.csrf import get_token
from django.utils.decorators import method_decorator
from django.db.models import Sum, Q, Prefetch
from rest_framework import viewsets, status
from rest_framework.decorators import api_view, action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from decimal import Decimal
import json
import logging

from .models import (
    Organization, OrganizationUser, StrategicObjective, Program, 
    StrategicInitiative, PerformanceMeasure, MainActivity, 
    ActivityBudget, ActivityCostingAssumption, Plan, PlanReview, 
    InitiativeFeed, Location, LandTransport, AirTransport, PerDiem, 
    Accommodation, ParticipantCost, SessionCost, PrintingCost, 
    SupervisorCost, ProcurementItem, DetailActivity, TeamDeskPlan, TeamDeskPlanReview
)
from .serializers import (
    OrganizationSerializer, StrategicObjectiveSerializer, ProgramSerializer,
    StrategicInitiativeSerializer, PerformanceMeasureSerializer, 
    MainActivitySerializer, ActivityBudgetSerializer, 
    ActivityCostingAssumptionSerializer, PlanSerializer, PlanReviewSerializer,
    InitiativeFeedSerializer, LocationSerializer, LandTransportSerializer,
    AirTransportSerializer, PerDiemSerializer, AccommodationSerializer,
    ParticipantCostSerializer, SessionCostSerializer, PrintingCostSerializer,
    SupervisorCostSerializer, ProcurementItemSerializer, DetailActivitySerializer,
    TeamDeskPlanSerializer, TeamDeskPlanReviewSerializer
)

# Set up logger
logger = logging.getLogger(__name__)

@ensure_csrf_cookie
@api_view(['GET'])
def csrf_token_view(request):
    """Get CSRF token"""
    token = get_token(request)
    return JsonResponse({'csrftoken': token})

@api_view(['POST'])
def login_view(request):
    """Login user"""
    try:
        data = json.loads(request.body)
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return Response({'detail': 'Username and password required'}, status=status.HTTP_400_BAD_REQUEST)
        
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            
            # Get user organizations
            user_organizations = OrganizationUser.objects.filter(user=user).select_related('organization')
            org_data = []
            for org_user in user_organizations:
                org_data.append({
                    'id': org_user.id,
                    'organization': org_user.organization.id,
                    'organization_name': org_user.organization.name,
                    'role': org_user.role
                })
            
            return Response({
                'detail': 'Login successful',
                'user': {
                    'id': user.id,
                    'username': user.username,
                    'email': user.email,
                    'first_name': user.first_name,
                    'last_name': user.last_name
                },
                'userOrganizations': org_data
            })
        else:
            return Response({'detail': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)
    except Exception as e:
        logger.exception("Login error")
        return Response({'detail': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
def logout_view(request):
    """Logout user"""
    try:
        logout(request)
        return Response({'detail': 'Logout successful'})
    except Exception as e:
        logger.exception("Logout error")
        return Response({'detail': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
def check_auth(request):
    """Check authentication status"""
    try:
        if request.user.is_authenticated:
            # Get user organizations
            user_organizations = OrganizationUser.objects.filter(user=request.user).select_related('organization')
            org_data = []
            for org_user in user_organizations:
                org_data.append({
                    'id': org_user.id,
                    'organization': org_user.organization.id,
                    'organization_name': org_user.organization.name,
                    'role': org_user.role
                })
            
            return Response({
                'isAuthenticated': True,
                'user': {
                    'id': request.user.id,
                    'username': request.user.username,
                    'email': request.user.email,
                    'first_name': request.user.first_name,
                    'last_name': request.user.last_name
                },
                'userOrganizations': org_data
            })
        else:
            return Response({'isAuthenticated': False})
    except Exception as e:
        logger.exception("Auth check error")
        return Response({'detail': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['PATCH'])
@login_required
def update_profile(request):
    """Update user profile"""
    try:
        user = request.user
        data = json.loads(request.body)
        
        if 'first_name' in data:
            user.first_name = data['first_name']
        if 'last_name' in data:
            user.last_name = data['last_name']
        if 'email' in data:
            user.email = data['email']
            
        user.save()
        
        return Response({
            'detail': 'Profile updated successfully',
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name
            }
        })
    except Exception as e:
        logger.exception("Profile update error")
        return Response({'detail': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
@login_required
def password_change(request):
    """Change user password"""
    try:
        user = request.user
        data = json.loads(request.body)
        
        current_password = data.get('current_password')
        new_password = data.get('new_password')
        
        if not current_password or not new_password:
            return Response({'detail': 'Current and new password required'}, status=status.HTTP_400_BAD_REQUEST)
        
        if not user.check_password(current_password):
            return Response({'detail': 'Current password is incorrect'}, status=status.HTTP_400_BAD_REQUEST)
        
        user.set_password(new_password)
        user.save()
        
        return Response({'detail': 'Password changed successfully'})
    except Exception as e:
        logger.exception("Password change error")
        return Response({'detail': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class OrganizationViewSet(viewsets.ModelViewSet):
    queryset = Organization.objects.all().order_by('type', 'name')
    serializer_class = OrganizationSerializer
    permission_classes = [IsAuthenticated]

class InitiativeFeedViewSet(viewsets.ModelViewSet):
    queryset = InitiativeFeed.objects.filter(is_active=True).select_related('strategic_objective').order_by('name')
    serializer_class = InitiativeFeedSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        queryset = super().get_queryset()
        strategic_objective = self.request.query_params.get('strategic_objective', None)
        if strategic_objective is not None:
            queryset = queryset.filter(strategic_objective=strategic_objective)
        return queryset

class StrategicObjectiveViewSet(viewsets.ModelViewSet):
    queryset = StrategicObjective.objects.all().prefetch_related('programs', 'initiatives')
    serializer_class = StrategicObjectiveSerializer
    permission_classes = [IsAuthenticated]

    @action(detail=False, methods=['get'])
    def weight_summary(self, request):
        """Get weight summary for all objectives"""
        try:
            objectives = self.get_queryset()
            total_weight = sum(obj.get_effective_weight() for obj in objectives)
            remaining_weight = 100 - total_weight
            is_valid = abs(total_weight - 100) < 0.01
            
            return Response({
                'total_weight': total_weight,
                'remaining_weight': remaining_weight,
                'is_valid': is_valid
            })
        except Exception as e:
            logger.exception("Error calculating weight summary")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=False, methods=['post'])
    def validate_total_weight(self, request):
        """Validate that total weight equals 100%"""
        try:
            objectives = self.get_queryset()
            total_weight = sum(obj.get_effective_weight() for obj in objectives)
            
            if abs(total_weight - 100) < 0.01:
                return Response({'message': 'Total weight is valid (100%)', 'is_valid': True})
            else:
                return Response({
                    'message': f'Total weight is {total_weight}%, must be 100%',
                    'is_valid': False,
                    'total_weight': total_weight
                }, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logger.exception("Error validating total weight")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class ProgramViewSet(viewsets.ModelViewSet):
    queryset = Program.objects.all().select_related('strategic_objective').prefetch_related('initiatives')
    serializer_class = ProgramSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = super().get_queryset()
        strategic_objective = self.request.query_params.get('strategic_objective', None)
        if strategic_objective is not None:
            queryset = queryset.filter(strategic_objective=strategic_objective)
        return queryset

class StrategicInitiativeViewSet(viewsets.ModelViewSet):
    queryset = StrategicInitiative.objects.all().select_related(
        'strategic_objective', 'program', 'organization', 'initiative_feed'
    ).prefetch_related('performance_measures', 'main_activities')
    serializer_class = StrategicInitiativeSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = super().get_queryset()
        
        # Filter by objective
        objective = self.request.query_params.get('objective', None)
        if objective is not None:
            queryset = queryset.filter(strategic_objective=objective)
        
        # Filter by program
        program = self.request.query_params.get('program', None)
        if program is not None:
            queryset = queryset.filter(program=program)
        
        # Filter by subprogram (if still needed for backward compatibility)
        subprogram = self.request.query_params.get('subprogram', None)
        if subprogram is not None:
            # Since we removed subprogram, this will return empty queryset
            queryset = queryset.none()
        
        return queryset

    @action(detail=False, methods=['get'])
    def weight_summary(self, request):
        """Get weight summary for initiatives under a parent"""
        try:
            parent_type = None
            parent_id = None
            
            if request.query_params.get('objective'):
                parent_type = 'objective'
                parent_id = request.query_params.get('objective')
                initiatives = self.get_queryset().filter(strategic_objective=parent_id)
            elif request.query_params.get('program'):
                parent_type = 'program'
                parent_id = request.query_params.get('program')
                initiatives = self.get_queryset().filter(program=parent_id)
            else:
                return Response({'error': 'Parent ID required'}, status=status.HTTP_400_BAD_REQUEST)
            
            total_initiatives_weight = initiatives.aggregate(Sum('weight'))['weight__sum'] or Decimal('0')
            
            # Get parent weight for calculation
            if parent_type == 'objective':
                try:
                    objective = StrategicObjective.objects.get(id=parent_id)
                    parent_weight = objective.get_effective_weight()
                except StrategicObjective.DoesNotExist:
                    return Response({'error': 'Objective not found'}, status=status.HTTP_404_NOT_FOUND)
            elif parent_type == 'program':
                try:
                    program = Program.objects.get(id=parent_id)
                    parent_weight = program.strategic_objective.get_effective_weight()
                except Program.DoesNotExist:
                    return Response({'error': 'Program not found'}, status=status.HTTP_404_NOT_FOUND)
            
            remaining_weight = parent_weight - total_initiatives_weight
            
            return Response({
                'total_initiatives_weight': float(total_initiatives_weight),
                'remaining_weight': float(remaining_weight),
                'parent_weight': float(parent_weight)
            })
        except Exception as e:
            logger.exception("Error calculating initiative weight summary")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=False, methods=['post'])
    def validate_initiatives_weight(self, request):
        """Validate initiatives weight for a parent"""
        try:
            parent_type = None
            parent_id = None
            
            if request.query_params.get('objective'):
                parent_type = 'objective'
                parent_id = request.query_params.get('objective')
                initiatives = self.get_queryset().filter(strategic_objective=parent_id)
            elif request.query_params.get('program'):
                parent_type = 'program'  
                parent_id = request.query_params.get('program')
                initiatives = self.get_queryset().filter(program=parent_id)
            else:
                return Response({'error': 'Parent ID required'}, status=status.HTTP_400_BAD_REQUEST)
            
            total_weight = initiatives.aggregate(Sum('weight'))['weight__sum'] or Decimal('0')
            
            # Get expected weight based on parent type
            if parent_type == 'objective':
                try:
                    objective = StrategicObjective.objects.get(id=parent_id)
                    expected_weight = objective.get_effective_weight()
                    
                    if abs(float(total_weight) - float(expected_weight)) < 0.01:
                        return Response({
                            'message': f'Initiative weights are valid ({total_weight}%)',
                            'is_valid': True
                        })
                    else:
                        return Response({
                            'message': f'Initiative weights ({total_weight}%) must equal objective weight ({expected_weight}%)',
                            'is_valid': False
                        }, status=status.HTTP_400_BAD_REQUEST)
                except StrategicObjective.DoesNotExist:
                    return Response({'error': 'Objective not found'}, status=status.HTTP_404_NOT_FOUND)
            
            return Response({'message': 'Validation completed', 'is_valid': True})
        except Exception as e:
            logger.exception("Error validating initiatives weight")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class PerformanceMeasureViewSet(viewsets.ModelViewSet):
    queryset = PerformanceMeasure.objects.all().select_related('initiative', 'organization')
    serializer_class = PerformanceMeasureSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = super().get_queryset()
        initiative = self.request.query_params.get('initiative', None)
        if initiative is not None:
            queryset = queryset.filter(initiative=initiative)
        return queryset

    @action(detail=False, methods=['get'])
    def weight_summary(self, request):
        """Get weight summary for performance measures under an initiative"""
        try:
            initiative_id = request.query_params.get('initiative')
            if not initiative_id:
                return Response({'error': 'Initiative ID required'}, status=status.HTTP_400_BAD_REQUEST)
            
            measures = self.get_queryset().filter(initiative=initiative_id)
            total_measures_weight = measures.aggregate(Sum('weight'))['weight__sum'] or Decimal('0')
            
            # Get initiative weight for calculation
            try:
                initiative = StrategicInitiative.objects.get(id=initiative_id)
                initiative_weight = initiative.weight
                expected_weight = initiative_weight * Decimal('0.35')  # 35% for measures
                remaining_weight = expected_weight - total_measures_weight
                
                return Response({
                    'total_measures_weight': float(total_measures_weight),
                    'remaining_weight': float(remaining_weight),
                    'expected_weight': float(expected_weight),
                    'initiative_weight': float(initiative_weight)
                })
            except StrategicInitiative.DoesNotExist:
                return Response({'error': 'Initiative not found'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            logger.exception("Error calculating measures weight summary")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=False, methods=['post'])
    def validate_measures_weight(self, request):
        """Validate performance measures weight for an initiative"""
        try:
            initiative_id = request.query_params.get('initiative')
            if not initiative_id:
                return Response({'error': 'Initiative ID required'}, status=status.HTTP_400_BAD_REQUEST)
            
            measures = self.get_queryset().filter(initiative=initiative_id)
            total_weight = measures.aggregate(Sum('weight'))['weight__sum'] or Decimal('0')
            
            try:
                initiative = StrategicInitiative.objects.get(id=initiative_id)
                expected_weight = initiative.weight * Decimal('0.35')  # 35% for measures
                
                if abs(float(total_weight) - float(expected_weight)) < 0.01:
                    return Response({
                        'message': f'Performance measures weights are valid ({total_weight}%)',
                        'is_valid': True
                    })
                else:
                    return Response({
                        'message': f'Performance measures weights ({total_weight}%) must equal 35% of initiative weight ({expected_weight}%)',
                        'is_valid': False
                    }, status=status.HTTP_400_BAD_REQUEST)
            except StrategicInitiative.DoesNotExist:
                return Response({'error': 'Initiative not found'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            logger.exception("Error validating measures weight")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class MainActivityViewSet(viewsets.ModelViewSet):
    queryset = MainActivity.objects.all().select_related('initiative', 'organization').prefetch_related('budget')
    serializer_class = MainActivitySerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = super().get_queryset()
        initiative = self.request.query_params.get('initiative', None)
        if initiative is not None:
            queryset = queryset.filter(initiative=initiative)
        return queryset

    @action(detail=True, methods=['post'])
    def update_budget(self, request, pk=None):
        """Update or create budget for a main activity"""
        try:
            activity = self.get_object()
            budget_data = request.data
            
            # Ensure activity_id is set
            budget_data['activity'] = activity.id
            
            # Get or create budget
            budget, created = ActivityBudget.objects.get_or_create(
                activity=activity,
                defaults=budget_data
            )
            
            if not created:
                # Update existing budget
                for key, value in budget_data.items():
                    setattr(budget, key, value)
                budget.save()
            
            serializer = ActivityBudgetSerializer(budget)
            return Response(serializer.data, status=status.HTTP_201_CREATED if created else status.HTTP_200_OK)
        except Exception as e:
            logger.exception("Error updating activity budget")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=False, methods=['get'])
    def weight_summary(self, request):
        """Get weight summary for main activities under an initiative"""
        try:
            initiative_id = request.query_params.get('initiative')
            if not initiative_id:
                return Response({'error': 'Initiative ID required'}, status=status.HTTP_400_BAD_REQUEST)
            
            activities = self.get_queryset().filter(initiative=initiative_id)
            total_activities_weight = activities.aggregate(Sum('weight'))['weight__sum'] or Decimal('0')
            
            # Get initiative weight for calculation
            try:
                initiative = StrategicInitiative.objects.get(id=initiative_id)
                initiative_weight = initiative.weight
                expected_weight = initiative_weight * Decimal('0.65')  # 65% for activities
                remaining_weight = expected_weight - total_activities_weight
                
                return Response({
                    'total_activities_weight': float(total_activities_weight),
                    'remaining_weight': float(remaining_weight),
                    'expected_weight': float(expected_weight),
                    'initiative_weight': float(initiative_weight)
                })
            except StrategicInitiative.DoesNotExist:
                return Response({'error': 'Initiative not found'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            logger.exception("Error calculating activities weight summary")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=False, methods=['post'])
    def validate_activities_weight(self, request):
        """Validate main activities weight for an initiative"""
        try:
            initiative_id = request.query_params.get('initiative')
            if not initiative_id:
                return Response({'error': 'Initiative ID required'}, status=status.HTTP_400_BAD_REQUEST)
            
            activities = self.get_queryset().filter(initiative=initiative_id)
            total_weight = activities.aggregate(Sum('weight'))['weight__sum'] or Decimal('0')
            
            try:
                initiative = StrategicInitiative.objects.get(id=initiative_id)
                expected_weight = initiative.weight * Decimal('0.65')  # 65% for activities
                
                if abs(float(total_weight) - float(expected_weight)) < 0.01:
                    return Response({
                        'message': f'Main activities weights are valid ({total_weight}%)',
                        'is_valid': True
                    })
                else:
                    return Response({
                        'message': f'Main activities weights ({total_weight}%) must equal 65% of initiative weight ({expected_weight}%)',
                        'is_valid': False
                    }, status=status.HTTP_400_BAD_REQUEST)
            except StrategicInitiative.DoesNotExist:
                return Response({'error': 'Initiative not found'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            logger.exception("Error validating activities weight")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class ActivityBudgetViewSet(viewsets.ModelViewSet):
    queryset = ActivityBudget.objects.all().select_related('activity')
    serializer_class = ActivityBudgetSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = super().get_queryset()
        activity = self.request.query_params.get('activity', None)
        if activity is not None:
            queryset = queryset.filter(activity=activity)
        return queryset

class ActivityCostingAssumptionViewSet(viewsets.ModelViewSet):
    queryset = ActivityCostingAssumption.objects.all().order_by('activity_type', 'location', 'cost_type')
    serializer_class = ActivityCostingAssumptionSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = super().get_queryset()
        activity_type = self.request.query_params.get('activity_type', None)
        if activity_type is not None:
            queryset = queryset.filter(activity_type=activity_type)
        return queryset

class PlanViewSet(viewsets.ModelViewSet):
    queryset = Plan.objects.all().select_related('organization', 'strategic_objective').prefetch_related('reviews', 'selected_objectives')
    serializer_class = PlanSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        """Filter plans based on user's role and organization"""
        queryset = super().get_queryset()
        user = self.request.user
        
        # Check for special 'all' parameter for evaluators/admins
        show_all = self.request.query_params.get('all', 'false').lower() == 'true'
        
        # Get user's organizations and role
        user_organizations = OrganizationUser.objects.filter(user=user)
        
        if not user_organizations.exists():
            # User has no organization access, return empty queryset
            logger.warning(f"User {user.username} has no organization access")
            return queryset.none()
        
        # Check user's role
        user_roles = user_organizations.values_list('role', flat=True)
        user_org_ids = user_organizations.values_list('organization', flat=True)
        
        logger.info(f"User {user.username} roles: {list(user_roles)}, orgs: {list(user_org_ids)}")
        
        # Admins can see all plans
        if 'ADMIN' in user_roles:
            logger.info(f"Admin {user.username} accessing all plans")
            return queryset
        
        # Evaluators can see all plans for review purposes
        if 'EVALUATOR' in user_roles:
            if show_all:
                logger.info(f"Evaluator {user.username} accessing all plans for statistics")
                return queryset
            else:
                # For individual plan access, evaluators can see all plans
                logger.info(f"Evaluator {user.username} accessing all plans for review")
                return queryset
        
        # Planners can only see plans from their own organizations
        if 'PLANNER' in user_roles:
            filtered_queryset = queryset.filter(organization__in=user_org_ids)
            logger.info(f"Planner {user.username} accessing {filtered_queryset.count()} plans from orgs {list(user_org_ids)}")
            return filtered_queryset
        
        # Default: no access
        logger.warning(f"User {user.username} has no recognized role, denying access")
        return queryset.none()

    def perform_create(self, serializer):
        """Override to save selected objectives when creating plan"""
        try:
            plan = serializer.save()
            
            # Only save objectives that the planner actually selected (have planner_weight set)
            selected_objectives = StrategicObjective.objects.filter(
                planner_weight__isnull=False
            ).distinct()
            
            # If no objectives have planner_weight, fall back to the main strategic_objective
            if not selected_objectives.exists() and plan.strategic_objective:
                selected_objectives = StrategicObjective.objects.filter(id=plan.strategic_objective.id)
            
            # Save all selected objectives to the plan
            plan.selected_objectives.set(selected_objectives)
            
            logger.info(f"Plan {plan.id} created with {selected_objectives.count()} objectives")
        except Exception as e:
            logger.exception("Error creating plan with selected objectives")
            raise

    def perform_update(self, serializer):
        """Override to update selected objectives when updating plan"""
        try:
            plan = serializer.save()
            
            # If plan is being submitted, ensure all selected objectives are saved
            if plan.status == 'SUBMITTED':
                # Only save objectives that the planner actually selected (have planner_weight set)
                selected_objectives = StrategicObjective.objects.filter(
                    planner_weight__isnull=False
                ).distinct()
                
                # If no objectives have planner_weight, fall back to the main strategic_objective
                if not selected_objectives.exists() and plan.strategic_objective:
                    selected_objectives = StrategicObjective.objects.filter(id=plan.strategic_objective.id)
                
                # Update selected objectives
                plan.selected_objectives.set(selected_objectives)
                
                logger.info(f"Plan {plan.id} submitted with {selected_objectives.count()} objectives")
        except Exception as e:
            logger.exception("Error updating plan with selected objectives")
            raise

    @action(detail=True, methods=['post'])
    def submit(self, request, pk=None):
        """Submit plan for review"""
        try:
            plan = self.get_object()
            
            if plan.status != 'DRAFT':
                return Response({'error': 'Only draft plans can be submitted'}, status=status.HTTP_400_BAD_REQUEST)
            
            # Only save objectives that the planner actually selected (have planner_weight set)
            selected_objectives = StrategicObjective.objects.filter(
                planner_weight__isnull=False
            ).distinct()
            
            # If no objectives have planner_weight, fall back to the main strategic_objective
            if not selected_objectives.exists() and plan.strategic_objective:
                selected_objectives = StrategicObjective.objects.filter(id=plan.strategic_objective.id)
            
            plan.selected_objectives.set(selected_objectives)
            plan.status = 'SUBMITTED'
            plan.save()
            
            return Response({'message': 'Plan submitted successfully'}, status=status.HTTP_200_OK)
        except Exception as e:
            logger.exception("Error submitting plan")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        """Approve a submitted plan"""
        try:
            logger.info(f"Attempting to approve plan {pk} by user {request.user.username}")
            plan = self.get_object()
            
            if plan.status != 'SUBMITTED':
                logger.warning(f"Plan {pk} status is {plan.status}, not SUBMITTED")
                return Response({'error': 'Only submitted plans can be approved'}, status=status.HTTP_400_BAD_REQUEST)
            
            # Check if user has evaluator role
            user_organizations = OrganizationUser.objects.filter(user=request.user)
            user_roles = user_organizations.values_list('role', flat=True)
            
            if 'EVALUATOR' not in user_roles and 'ADMIN' not in user_roles:
                logger.warning(f"User {request.user.username} does not have evaluator/admin role")
                return Response({'error': 'Only evaluators can approve plans'}, status=status.HTTP_403_FORBIDDEN)
            
            # Get the evaluator's organization user record
            evaluator_org_user = user_organizations.filter(role__in=['EVALUATOR', 'ADMIN']).first()
            if not evaluator_org_user:
                logger.error(f"No evaluator organization record found for user {request.user.username}")
                return Response({'error': 'Evaluator organization record not found'}, status=status.HTTP_400_BAD_REQUEST)
            
            # Create review record
            review_data = {
                'plan': plan,
                'status': 'APPROVED',
                'feedback': request.data.get('feedback', ''),
                'evaluator': evaluator_org_user
            }
            
            logger.info(f"Creating review record for plan {pk}")
            review = PlanReview.objects.create(**review_data)
            
            # Update plan status
            plan.status = 'APPROVED'
            plan.save()
            
            logger.info(f"Plan {pk} approved successfully by {request.user.username}")
            return Response({'message': 'Plan approved successfully'}, status=status.HTTP_200_OK)
            
        except Exception as e:
            logger.exception(f"Error approving plan {pk}")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        """Reject a submitted plan"""
        try:
            logger.info(f"Attempting to reject plan {pk} by user {request.user.username}")
            plan = self.get_object()
            
            if plan.status != 'SUBMITTED':
                logger.warning(f"Plan {pk} status is {plan.status}, not SUBMITTED")
                return Response({'error': 'Only submitted plans can be rejected'}, status=status.HTTP_400_BAD_REQUEST)
            
            # Check if user has evaluator role
            user_organizations = OrganizationUser.objects.filter(user=request.user)
            user_roles = user_organizations.values_list('role', flat=True)
            
            if 'EVALUATOR' not in user_roles and 'ADMIN' not in user_roles:
                logger.warning(f"User {request.user.username} does not have evaluator/admin role")
                return Response({'error': 'Only evaluators can reject plans'}, status=status.HTTP_403_FORBIDDEN)
            
            # Get the evaluator's organization user record
            evaluator_org_user = user_organizations.filter(role__in=['EVALUATOR', 'ADMIN']).first()
            if not evaluator_org_user:
                logger.error(f"No evaluator organization record found for user {request.user.username}")
                return Response({'error': 'Evaluator organization record not found'}, status=status.HTTP_400_BAD_REQUEST)
            
            # Create review record
            review_data = {
                'plan': plan,
                'status': 'REJECTED',
                'feedback': request.data.get('feedback', ''),
                'evaluator': evaluator_org_user
            }
            
            logger.info(f"Creating review record for plan {pk}")
            review = PlanReview.objects.create(**review_data)
            
            # Update plan status
            plan.status = 'REJECTED'
            plan.save()
            
            logger.info(f"Plan {pk} rejected successfully by {request.user.username}")
            return Response({'message': 'Plan rejected successfully'}, status=status.HTTP_200_OK)
            
        except Exception as e:
            logger.exception(f"Error rejecting plan {pk}")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=False, methods=['get'])
    def pending_reviews(self, request):
        """Get plans pending review"""
        try:
            # Check if user is an evaluator
            user_organizations = OrganizationUser.objects.filter(user=request.user)
            user_roles = user_organizations.values_list('role', flat=True)
            
            if 'EVALUATOR' in user_roles:
                # Evaluators can see all submitted plans for review
                plans = Plan.objects.filter(status='SUBMITTED').select_related(
                    'organization', 'strategic_objective'
                ).prefetch_related('reviews', 'selected_objectives')
                logger.info(f"Evaluator {request.user.username} accessing {plans.count()} pending plans")
            elif 'ADMIN' in user_roles:
                # Admins can also see all submitted plans
                plans = Plan.objects.filter(status='SUBMITTED').select_related(
                    'organization', 'strategic_objective'
                ).prefetch_related('reviews', 'selected_objectives')
                logger.info(f"Admin {request.user.username} accessing {plans.count()} pending plans")
            else:
                # For planners and others, use the normal filtered queryset
                plans = self.get_queryset().filter(status='SUBMITTED')
                logger.info(f"User {request.user.username} accessing {plans.count()} filtered pending plans")
                
            serializer = self.get_serializer(plans, many=True)
            return Response(serializer.data)
        except Exception as e:
            logger.exception("Error fetching pending reviews")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class PlanReviewViewSet(viewsets.ModelViewSet):
    queryset = PlanReview.objects.all().select_related('plan', 'evaluator')
    serializer_class = PlanReviewSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = super().get_queryset()
        plan = self.request.query_params.get('plan', None)
        if plan is not None:
            queryset = queryset.filter(plan=plan)
        return queryset

# Costing Model ViewSets
class LocationViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Location.objects.all().order_by('region', 'name')
    serializer_class = LocationSerializer
    permission_classes = [IsAuthenticated]

class LandTransportViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = LandTransport.objects.all().select_related('origin', 'destination')
    serializer_class = LandTransportSerializer
    permission_classes = [IsAuthenticated]

class AirTransportViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = AirTransport.objects.all().select_related('origin', 'destination')
    serializer_class = AirTransportSerializer
    permission_classes = [IsAuthenticated]

class PerDiemViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = PerDiem.objects.all().select_related('location')
    serializer_class = PerDiemSerializer
    permission_classes = [IsAuthenticated]

class AccommodationViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Accommodation.objects.all().select_related('location')
    serializer_class = AccommodationSerializer
    permission_classes = [IsAuthenticated]

class ParticipantCostViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = ParticipantCost.objects.all()
    serializer_class = ParticipantCostSerializer
    permission_classes = [IsAuthenticated]

class SessionCostViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = SessionCost.objects.all()
    serializer_class = SessionCostSerializer
    permission_classes = [IsAuthenticated]

class PrintingCostViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = PrintingCost.objects.all()
    serializer_class = PrintingCostSerializer
    permission_classes = [IsAuthenticated]

class SupervisorCostViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = SupervisorCost.objects.all()
    serializer_class = SupervisorCostSerializer
    permission_classes = [IsAuthenticated]

class ProcurementItemViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = ProcurementItem.objects.all().order_by('category', 'name')
    serializer_class = ProcurementItemSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = super().get_queryset()
        category = self.request.query_params.get('category', None)
        if category is not None:
            queryset = queryset.filter(category=category)
        return queryset

class DetailActivityViewSet(viewsets.ModelViewSet):
    queryset = DetailActivity.objects.all().select_related('main_activity', 'organization')
    serializer_class = DetailActivitySerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = super().get_queryset()
        main_activity = self.request.query_params.get('main_activity', None)
        if main_activity is not None:
            queryset = queryset.filter(main_activity=main_activity)
        return queryset

    def perform_create(self, serializer):
        # Set organization from user's organization
        user_organizations = OrganizationUser.objects.filter(user=self.request.user)
        if user_organizations.exists():
            serializer.save(organization=user_organizations.first().organization)
        else:
            serializer.save()

class TeamDeskPlanViewSet(viewsets.ModelViewSet):
    queryset = TeamDeskPlan.objects.all().select_related('organization', 'team_desk', 'leo_eo_plan').prefetch_related('reviews')
    serializer_class = TeamDeskPlanSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        """Filter plans based on user's role and organization"""
        queryset = super().get_queryset()
        user = self.request.user
        
        # Get user's organizations and role
        user_organizations = OrganizationUser.objects.filter(user=user)
        
        if not user_organizations.exists():
            return queryset.none()
        
        user_roles = user_organizations.values_list('role', flat=True)
        user_org_ids = user_organizations.values_list('organization', flat=True)
        
        # Admins can see all plans in their organization
        if 'ADMIN' in user_roles:
            return queryset.filter(organization__in=user_org_ids)
        
        # Team/Desk planners can only see their own team/desk plans
        if 'TEAM_DESK_PLANNER' in user_roles:
            return queryset.filter(team_desk__in=user_org_ids)
        
        # Default: no access
        return queryset.none()

    @action(detail=True, methods=['post'])
    def submit(self, request, pk=None):
        """Submit team/desk plan for admin review"""
        try:
            plan = self.get_object()
            
            if plan.status != 'DRAFT':
                return Response({'error': 'Only draft plans can be submitted'}, status=status.HTTP_400_BAD_REQUEST)
            
            plan.status = 'SUBMITTED'
            plan.submitted_at = timezone.now()
            plan.save()
            
            return Response({'message': 'Team/Desk plan submitted successfully'}, status=status.HTTP_200_OK)
        except Exception as e:
            logger.exception("Error submitting team/desk plan")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        """Approve a submitted team/desk plan (Admin only)"""
        try:
            plan = self.get_object()
            
            if plan.status != 'SUBMITTED':
                return Response({'error': 'Only submitted plans can be approved'}, status=status.HTTP_400_BAD_REQUEST)
            
            # Check if user has admin role in the same organization
            user_organizations = OrganizationUser.objects.filter(user=request.user)
            user_roles = user_organizations.values_list('role', flat=True)
            user_org_ids = user_organizations.values_list('organization', flat=True)
            
            if 'ADMIN' not in user_roles or plan.organization.id not in user_org_ids:
                return Response({'error': 'Only admins from the same organization can approve plans'}, status=status.HTTP_403_FORBIDDEN)
            
            # Get the admin's organization user record
            admin_org_user = user_organizations.filter(role='ADMIN', organization=plan.organization).first()
            if not admin_org_user:
                return Response({'error': 'Admin organization record not found'}, status=status.HTTP_400_BAD_REQUEST)
            
            # Create review record
            review = TeamDeskPlanReview.objects.create(
                plan=plan,
                status='APPROVED',
                feedback=request.data.get('feedback', ''),
                reviewer=admin_org_user
            )
            
            # Update plan status
            plan.status = 'APPROVED'
            plan.save()
            
            return Response({'message': 'Team/Desk plan approved successfully'}, status=status.HTTP_200_OK)
            
        except Exception as e:
            logger.exception(f"Error approving team/desk plan {pk}")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        """Reject a submitted team/desk plan (Admin only)"""
        try:
            plan = self.get_object()
            
            if plan.status != 'SUBMITTED':
                return Response({'error': 'Only submitted plans can be rejected'}, status=status.HTTP_400_BAD_REQUEST)
            
            # Check if user has admin role in the same organization
            user_organizations = OrganizationUser.objects.filter(user=request.user)
            user_roles = user_organizations.values_list('role', flat=True)
            user_org_ids = user_organizations.values_list('organization', flat=True)
            
            if 'ADMIN' not in user_roles or plan.organization.id not in user_org_ids:
                return Response({'error': 'Only admins from the same organization can reject plans'}, status=status.HTTP_403_FORBIDDEN)
            
            # Get the admin's organization user record
            admin_org_user = user_organizations.filter(role='ADMIN', organization=plan.organization).first()
            if not admin_org_user:
                return Response({'error': 'Admin organization record not found'}, status=status.HTTP_400_BAD_REQUEST)
            
            # Create review record
            review = TeamDeskPlanReview.objects.create(
                plan=plan,
                status='REJECTED',
                feedback=request.data.get('feedback', ''),
                reviewer=admin_org_user
            )
            
            # Update plan status
            plan.status = 'REJECTED'
            plan.save()
            
            return Response({'message': 'Team/Desk plan rejected successfully'}, status=status.HTTP_200_OK)
            
        except Exception as e:
            logger.exception(f"Error rejecting team/desk plan {pk}")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=False, methods=['get'])
    def approved_leo_eo_plans(self, request):
        """Get approved LEO/EO plans for the user's organization"""
        try:
            user_organizations = OrganizationUser.objects.filter(user=request.user)
            if not user_organizations.exists():
                return Response({'data': []})
            
            user_org_ids = user_organizations.values_list('organization', flat=True)
            
            # Get approved LEO/EO plans from the same organization or parent organization
            approved_plans = Plan.objects.filter(
                Q(organization__in=user_org_ids) | Q(organization__parent__in=user_org_ids),
                status='APPROVED',
                type='LEO/EO Plan'
            ).select_related('organization').prefetch_related('selected_objectives')
            
            logger.info(f"Found {approved_plans.count()} approved LEO/EO plans for user organizations {list(user_org_ids)}")
            
            serializer = PlanSerializer(approved_plans, many=True)
            return Response({'data': serializer.data})
            
        except Exception as e:
            logger.exception("Error fetching approved LEO/EO plans")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class TeamDeskPlanReviewViewSet(viewsets.ModelViewSet):
    queryset = TeamDeskPlanReview.objects.all().select_related('plan', 'reviewer')
    serializer_class = TeamDeskPlanReviewSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = super().get_queryset()
        plan = self.request.query_params.get('plan', None)
        if plan is not None:
            queryset = queryset.filter(plan=plan)
        return queryset