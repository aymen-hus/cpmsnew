from rest_framework.views import exception_handler
from rest_framework.response import Response
import logging
import traceback
import json
from django.http import JsonResponse

# Set up logger
logger = logging.getLogger(__name__)

def custom_exception_handler(exc, context):
    """Custom exception handler for REST framework that adds more detailed error logging"""
    # Call REST framework's default exception handler first to get the standard response
    response = exception_handler(exc, context)

    # Log the error with details
    logger.error(f"Exception occurred in {context['view'].__class__.__name__}.{context['view'].action if hasattr(context['view'], 'action') else 'method'}:")
    logger.exception(exc)
    
    # Print the traceback for debugging
    traceback.print_exc()

    # If the response is not None, it means REST framework handled the exception
    if response is not None:
        # Customize the response if needed
        try:
            error_data = {
                'error': str(exc),
                'detail': response.data if hasattr(response, 'data') else None,
                'status_code': response.status_code
            }
            response.data = error_data
        except Exception as e:
            logger.exception(f"Error customizing exception response: {e}")
            response.data = {'error': 'An error occurred processing the response'}
    else:
        # REST framework didn't handle the exception
        # Log the unhandled exception
        logger.error(f"Unhandled exception: {str(exc)}")
        
        # Return a custom response for the unhandled exception
        response = Response(
            {'error': 'An unexpected error occurred.', 'detail': str(exc)},
            status=500
        )

    return response

def parse_json_request(request):
    """Parse JSON from request body safely"""
    try:
        return json.loads(request.body.decode('utf-8'))
    except json.JSONDecodeError as e:
        logger.error(f"Error parsing JSON: {e}")
        return None
    except Exception as e:
        logger.exception(f"Unexpected error parsing request body: {e}")
        return None

def format_validation_errors(errors):
    """Format validation errors into a readable structure"""
    if isinstance(errors, dict):
        formatted = {}
        for field, error in errors.items():
            if isinstance(error, list):
                formatted[field] = error[0] if error else "Invalid value"
            else:
                formatted[field] = str(error)
        return formatted
    return {"error": str(errors)}