from rest_framework import serializers
from .models import (
    Organization, StrategicObjective, Program, StrategicInitiative,
    PerformanceMeasure, MainActivity, ActivityBudget, ActivityCostingAssumption,
    Plan, PlanReview, InitiativeFeed, Location, LandTransport, AirTransport,
    PerDiem, Accommodation, ParticipantCost, SessionCost, PrintingCost,
    SupervisorCost, ProcurementItem, DetailActivity, TeamDeskPlan, TeamDeskPlanReview
)

class OrganizationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Organization
        fields = '__all__'

class StrategicObjectiveSerializer(serializers.ModelSerializer):
    effective_weight = serializers.SerializerMethodField()
    
    class Meta:
        model = StrategicObjective
        fields = '__all__'
    
    def get_effective_weight(self, obj):
        """Return effective weight (planner_weight if set, otherwise weight)"""
        if obj.planner_weight is not None:
            return obj.planner_weight
        return obj.weight

class ProgramSerializer(serializers.ModelSerializer):
    strategic_objective_title = serializers.CharField(source='strategic_objective.title', read_only=True)
    
    class Meta:
        model = Program
        fields = '__all__'

class StrategicInitiativeSerializer(serializers.ModelSerializer):
    strategic_objective_title = serializers.CharField(source='strategic_objective.title', read_only=True)
    program_name = serializers.CharField(source='program.name', read_only=True)
    organization_name = serializers.CharField(source='organization.name', read_only=True)
    initiative_feed_name = serializers.CharField(source='initiative_feed.name', read_only=True)
    
    class Meta:
        model = StrategicInitiative
        fields = '__all__'

class PerformanceMeasureSerializer(serializers.ModelSerializer):
    initiative_name = serializers.CharField(source='initiative.name', read_only=True)
    organization_name = serializers.CharField(source='organization.name', read_only=True)
    
    class Meta:
        model = PerformanceMeasure
        fields = '__all__'

class MainActivitySerializer(serializers.ModelSerializer):
    initiative_name = serializers.CharField(source='initiative.name', read_only=True)
    organization_name = serializers.CharField(source='organization.name', read_only=True)
    
    class Meta:
        model = MainActivity
        fields = '__all__'

class ActivityBudgetSerializer(serializers.ModelSerializer):
    activity_name = serializers.CharField(source='activity.name', read_only=True)
    
    class Meta:
        model = ActivityBudget
        fields = '__all__'

class ActivityCostingAssumptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ActivityCostingAssumption
        fields = '__all__'

class PlanSerializer(serializers.ModelSerializer):
    organization_name = serializers.CharField(source='organization.name', read_only=True)
    strategic_objective_title = serializers.CharField(source='strategic_objective.title', read_only=True)
    
    class Meta:
        model = Plan
        fields = '__all__'

class PlanReviewSerializer(serializers.ModelSerializer):
    evaluator_name = serializers.CharField(source='evaluator.user.get_full_name', read_only=True)
    plan_organization = serializers.CharField(source='plan.organization.name', read_only=True)
    
    class Meta:
        model = PlanReview
        fields = '__all__'

class InitiativeFeedSerializer(serializers.ModelSerializer):
    strategic_objective_title = serializers.CharField(source='strategic_objective.title', read_only=True)
    
    class Meta:
        model = InitiativeFeed
        fields = '__all__'

class LocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Location
        fields = '__all__'

class LandTransportSerializer(serializers.ModelSerializer):
    origin_name = serializers.CharField(source='origin.name', read_only=True)
    destination_name = serializers.CharField(source='destination.name', read_only=True)
    
    class Meta:
        model = LandTransport
        fields = '__all__'

class AirTransportSerializer(serializers.ModelSerializer):
    origin_name = serializers.CharField(source='origin.name', read_only=True)
    destination_name = serializers.CharField(source='destination.name', read_only=True)
    
    class Meta:
        model = AirTransport
        fields = '__all__'

class PerDiemSerializer(serializers.ModelSerializer):
    location_name = serializers.CharField(source='location.name', read_only=True)
    
    class Meta:
        model = PerDiem
        fields = '__all__'

class AccommodationSerializer(serializers.ModelSerializer):
    location_name = serializers.CharField(source='location.name', read_only=True)
    service_type_display = serializers.CharField(source='get_service_type_display', read_only=True)
    
    class Meta:
        model = Accommodation
        fields = '__all__'

class ParticipantCostSerializer(serializers.ModelSerializer):
    cost_type_display = serializers.CharField(source='get_cost_type_display', read_only=True)
    
    class Meta:
        model = ParticipantCost
        fields = '__all__'

class SessionCostSerializer(serializers.ModelSerializer):
    cost_type_display = serializers.CharField(source='get_cost_type_display', read_only=True)
    
    class Meta:
        model = SessionCost
        fields = '__all__'

class PrintingCostSerializer(serializers.ModelSerializer):
    document_type_display = serializers.CharField(source='get_document_type_display', read_only=True)
    
    class Meta:
        model = PrintingCost
        fields = '__all__'

class SupervisorCostSerializer(serializers.ModelSerializer):
    cost_type_display = serializers.CharField(source='get_cost_type_display', read_only=True)
    
    class Meta:
        model = SupervisorCost
        fields = '__all__'

class ProcurementItemSerializer(serializers.ModelSerializer):
    category_display = serializers.CharField(source='get_category_display', read_only=True)
    unit_display = serializers.CharField(source='get_unit_display', read_only=True)
    
    class Meta:
        model = ProcurementItem
        fields = '__all__'

class DetailActivitySerializer(serializers.ModelSerializer):
    main_activity_name = serializers.CharField(source='main_activity.name', read_only=True)
    organization_name = serializers.CharField(source='organization.name', read_only=True)
    
    class Meta:
        model = DetailActivity
        fields = [
            'id', 'name', 'weight', 'baseline', 'target_type',
            'q1_target', 'q2_target', 'q3_target', 'q4_target', 'annual_target',
            'selected_months', 'selected_quarters',
            'main_activity', 'main_activity_name', 'organization', 'organization_name',
            'created_at', 'updated_at'
        ]
    
    def validate(self, data):
        """Validate detail activity data"""
        # Validate target type consistency
        target_type = data.get('target_type', 'cumulative')
        baseline = data.get('baseline', '')
        q1_target = data.get('q1_target', 0)
        q2_target = data.get('q2_target', 0)
        q3_target = data.get('q3_target', 0)
        q4_target = data.get('q4_target', 0)
        annual_target = data.get('annual_target', 0)
        
        # Validate based on target type
        if target_type == 'cumulative':
            # Sum of quarterly targets should equal annual target
            quarterly_sum = q1_target + q2_target + q3_target + q4_target
            if abs(quarterly_sum - annual_target) > 0.01:
                raise serializers.ValidationError({
                    'annual_target': f'For cumulative targets, sum of quarterly targets ({quarterly_sum}) must equal annual target ({annual_target})'
                })
        elif target_type == 'increasing':
            # Q1 ≤ Q2 ≤ Q3 ≤ Q4 and Q4 = annual target
            if not (q1_target <= q2_target <= q3_target <= q4_target):
                raise serializers.ValidationError({
                    'targets': 'For increasing targets, quarterly targets must be in ascending order (Q1 ≤ Q2 ≤ Q3 ≤ Q4)'
                })
            if q4_target != annual_target:
                raise serializers.ValidationError({
                    'annual_target': f'For increasing targets, Q4 target ({q4_target}) must equal annual target ({annual_target})'
                })
        elif target_type == 'decreasing':
            # Q1 ≥ Q2 ≥ Q3 ≥ Q4 and Q4 = annual target
            if not (q1_target >= q2_target >= q3_target >= q4_target):
                raise serializers.ValidationError({
                    'targets': 'For decreasing targets, quarterly targets must be in descending order (Q1 ≥ Q2 ≥ Q3 ≥ Q4)'
                })
            if q4_target != annual_target:
                raise serializers.ValidationError({
                    'annual_target': f'For decreasing targets, Q4 target ({q4_target}) must equal annual target ({annual_target})'
                })
        elif target_type == 'constant':
            # All quarters must equal annual target
            if not (q1_target == q2_target == q3_target == q4_target == annual_target):
                raise serializers.ValidationError({
                    'targets': f'For constant targets, all quarterly targets must equal annual target ({annual_target})'
                })
        
        return data

class TeamDeskPlanSerializer(serializers.ModelSerializer):
    organization_name = serializers.CharField(source='organization.name', read_only=True)
    team_desk_name = serializers.CharField(source='team_desk.name', read_only=True)
    leo_eo_plan_title = serializers.CharField(source='leo_eo_plan.organization.name', read_only=True)
    
    # Nested relationships for detailed plan view
    objectives = StrategicObjectiveSerializer(many=True, read_only=True)
    initiatives = StrategicInitiativeSerializer(many=True, read_only=True)
    performance_measures = PerformanceMeasureSerializer(many=True, read_only=True)
    main_activities = MainActivitySerializer(many=True, read_only=True)
    detail_activities = DetailActivitySerializer(many=True, read_only=True)
    
    class Meta:
        model = TeamDeskPlan
        fields = [
            'id', 'status', 'organization', 'organization_name',
            'team_desk', 'team_desk_name', 'leo_eo_plan', 'leo_eo_plan_title',
            'objectives', 'initiatives', 'performance_measures', 
            'main_activities', 'detail_activities',
            'submitted_at', 'created_at', 'updated_at'
        ]
    
    def validate(self, data):
        """Validate team/desk plan data"""
        # Ensure team_desk is actually a team or desk organization
        team_desk = data.get('team_desk')
        if team_desk and team_desk.type not in ['TEAM_LEAD', 'DESK']:
            raise serializers.ValidationError({
                'team_desk': 'Selected organization must be a Team Lead or Desk'
            })
        
        # Ensure leo_eo_plan is approved
        leo_eo_plan = data.get('leo_eo_plan')
        if leo_eo_plan and leo_eo_plan.status != 'APPROVED':
            raise serializers.ValidationError({
                'leo_eo_plan': 'LEO/EO plan must be approved before creating team/desk plan'
            })
        
        return data

class TeamDeskPlanReviewSerializer(serializers.ModelSerializer):
    reviewer_name = serializers.CharField(source='reviewer.user.get_full_name', read_only=True)
    plan_organization = serializers.CharField(source='plan.organization.name', read_only=True)
    plan_team_desk = serializers.CharField(source='plan.team_desk.name', read_only=True)
    
    class Meta:
        model = TeamDeskPlanReview
        fields = [
            'id', 'plan', 'plan_organization', 'plan_team_desk',
            'reviewer', 'reviewer_name', 'status', 'feedback',
            'reviewed_at'
        ]
    
    def validate(self, data):
        """Validate team/desk plan review data"""
        # Ensure plan is in submitted status
        plan = data.get('plan')
        if plan and plan.status != 'SUBMITTED':
            raise serializers.ValidationError({
                'plan': 'Only submitted plans can be reviewed'
            })
        
        # Ensure feedback is provided for rejections
        status = data.get('status')
        feedback = data.get('feedback', '')
        if status == 'REJECTED' and not feedback.strip():
            raise serializers.ValidationError({
                'feedback': 'Feedback is required when rejecting a plan'
            })
        
        return data