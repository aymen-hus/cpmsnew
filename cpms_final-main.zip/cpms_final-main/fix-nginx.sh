#!/bin/bash
set -e

echo "=== Fixing Nginx Configuration ==="

# Create backup of existing config
if [ -f /etc/nginx/sites-enabled/moh-planning ]; then
    sudo cp /etc/nginx/sites-enabled/moh-planning /etc/nginx/sites-enabled/moh-planning.backup
    echo "Created backup of current config at /etc/nginx/sites-enabled/moh-planning.backup"
fi

# Copy fixed configuration
echo "Updating Nginx configuration..."
sudo cp moh-planning.nginx.conf /etc/nginx/sites-available/moh-planning

# Create symbolic link if it doesn't exist
if [ ! -f /etc/nginx/sites-enabled/moh-planning ]; then
    sudo ln -s /etc/nginx/sites-available/moh-planning /etc/nginx/sites-enabled/
    echo "Created symlink for Nginx configuration"
fi

# Test Nginx configuration
echo "Testing Nginx configuration..."
sudo nginx -t

# Restart Nginx
echo "Restarting Nginx..."
sudo systemctl restart nginx

echo "=== Configuration update completed ==="
echo "Check if the error is resolved by accessing your server."
echo "If you still have issues, check the error log:"
echo "  sudo tail -f /var/log/nginx/error.log"
echo "  sudo tail -f /var/log/nginx/moh-planning-error.log"