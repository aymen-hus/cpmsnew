#!/bin/bash

# MOH Planning Troubleshooting Script
# This script helps diagnose common issues with the MOH Planning application

echo "==================== MOH Planning Troubleshooter ===================="
echo "Running diagnostics..."

# Check if we're running as root
if [[ $EUID -ne 0 ]]; then
   echo "⚠️  This script should be run as root to access all logs"
   echo "   Please run with: sudo ./troubleshoot.sh"
fi

echo ""
echo "=========== Checking System Status ==========="

# Check if nginx is running
echo "Checking nginx status:"
systemctl is-active --quiet nginx
if [ $? -eq 0 ]; then
    echo "✅ Nginx is running"
else
    echo "❌ Nginx is NOT running"
    echo "   Try starting with: sudo systemctl start nginx"
fi

# Check if our service is running
echo "Checking moh-planning service status:"
systemctl is-active --quiet moh-planning
if [ $? -eq 0 ]; then
    echo "✅ moh-planning service is running"
else
    echo "❌ moh-planning service is NOT running"
    echo "   Check logs with: sudo journalctl -u moh-planning -n 50"
    echo "   Try starting with: sudo systemctl start moh-planning"
fi

echo ""
echo "=========== Checking Configuration Files ==========="

# Check for nginx configuration file
if [ -f /etc/nginx/sites-available/moh-planning ]; then
    echo "✅ Nginx configuration file exists"
    
    # Check if it's enabled
    if [ -f /etc/nginx/sites-enabled/moh-planning ]; then
        echo "✅ Nginx configuration is enabled"
    else
        echo "❌ Nginx configuration is NOT enabled"
        echo "   Enable with: sudo ln -s /etc/nginx/sites-available/moh-planning /etc/nginx/sites-enabled/"
    fi
else
    echo "❌ Nginx configuration file is missing"
    echo "   Copy from: cp moh-planning.nginx.conf /etc/nginx/sites-available/moh-planning"
fi

# Check for systemd service file
if [ -f /etc/systemd/system/moh-planning.service ]; then
    echo "✅ Systemd service file exists"
else
    echo "❌ Systemd service file is missing"
    echo "   Copy from: sudo cp moh-planning.service /etc/systemd/system/"
    echo "   Then run: sudo systemctl daemon-reload"
fi

echo ""
echo "=========== Checking Log Files ==========="

# Check nginx error log
echo "Last 5 lines from nginx error log:"
if [ -f /var/log/nginx/error.log ]; then
    tail -n 5 /var/log/nginx/error.log
else
    echo "❌ Nginx error log not found"
fi

# Check our specific nginx logs
echo "Last 5 lines from moh-planning nginx error log:"
if [ -f /var/log/nginx/moh-planning-error.log ]; then
    tail -n 5 /var/log/nginx/moh-planning-error.log
else
    echo "❌ moh-planning nginx error log not found"
fi

# Check systemd logs
echo "Last 10 lines from systemd service log:"
journalctl -u moh-planning -n 10 --no-pager

echo ""
echo "=========== Checking Network Configuration ==========="

# Check if port 8000 is listening
echo "Checking if gunicorn is listening on port 8000:"
netstat -tlnp | grep 8000 || echo "❌ Nothing is listening on port 8000"

# Check if port 80 is listening
echo "Checking if nginx is listening on port 80:"
netstat -tlnp | grep :80 || echo "❌ Nothing is listening on port 80"

echo ""
echo "=========== Checking Application Files ==========="

# Check if dist directory exists
if [ -d "/var/www/moh-planning/dist" ]; then
    echo "✅ Frontend build (dist) directory exists"
    
    # Check index.html
    if [ -f "/var/www/moh-planning/dist/index.html" ]; then
        echo "✅ Frontend index.html exists"
    else
        echo "❌ Frontend index.html is missing"
        echo "   Run the build process again: npm run build"
    fi
else
    echo "❌ Frontend build directory is missing"
    echo "   Run the build process: npm run build"
fi

# Check if static files exist
if [ -d "/var/www/moh-planning/staticfiles" ]; then
    echo "✅ Django static files directory exists"
    echo "   Contains $(find /var/www/moh-planning/staticfiles -type f | wc -l) files"
else
    echo "❌ Django static files directory is missing"
    echo "   Run: python manage.py collectstatic --noinput"
fi

echo ""
echo "=========== Next Steps ==========="
echo "If you're still having issues:"
echo "1. Try restarting the services:"
echo "   sudo systemctl restart moh-planning nginx"
echo ""
echo "2. Check the systemd service logs for detailed errors:"
echo "   sudo journalctl -u moh-planning -n 50"
echo ""
echo "3. Check the Django logs:"
echo "   sudo cat /var/www/moh-planning/logs/*"
echo ""
echo "4. Make sure your database is running and accessible"
echo ""
echo "5. Test the gunicorn server manually:"
echo "   cd /var/www/moh-planning && venv/bin/gunicorn core.wsgi:application --bind 127.0.0.1:8000"