Here's the fixed version with all missing closing brackets added:

```javascript
  // Handle initiative save
  const handleInitiativeSave = async (data: Partial<StrategicInitiative>) => {
    try {
      // Create a clean data object with proper types
      const cleanData: any = {
        name: data.name || '',
        weight: Number(data.weight || 0),
        is_default: false
      };
      
      // Determine parent type and set proper relationship
      if (selectedObjectiveId) {
        // Handle objective ID - extract clean ID
        let objId = selectedObjectiveId;
        if (typeof objId === 'object' && objId !== null && 'id' in objId) {
          objId = (objId as any).id;
        }
        // Convert to string and remove any non-numeric characters
        cleanData.strategic_objective = String(objId).replace(/[^0-9]/g, '');
        cleanData.program = null;
      } else if (selectedProgram) {
        // Handle program ID
        cleanData.strategic_objective = null;
        cleanData.program = String(selectedProgram.id).replace(/[^0-9]/g, '');
      if (parentType === 'objective') {
        // Ensure we're sending the ID as a string, not an object
        const objId = typeof selectedObjectiveId === 'object' ? 
                     (selectedObjectiveId as any).id : selectedObjectiveId;
        cleanData.strategic_objective = String(objId || '');
        cleanData.program = null;
      } else if (parentType === 'program' && selectedProgram) {
        cleanData.strategic_objective = null;
        cleanData.program = String(selectedProgram.id || '');
      }
      
      // Handle organization_id
      if (userOrgId) {
        cleanData.organization_id = typeof userOrgId === 'object' ? 
                                   Number((userOrgId as any).id || 0) : Number(userOrgId);
        // Remove organization field if it exists to avoid conflicts
        if ('organization' in cleanData) {
          delete cleanData.organization;
        }
      }
      // Handle organization_id
      if (userOrgId) {
        cleanData.organization_id = typeof userOrgId === 'object' ? 
                                   Number((userOrgId as any).id || 0) : Number(userOrgId);
        // Remove organization field if it exists to avoid conflicts
      // Set organization ID (must be a number)
      }
        if (typeof userOrgId === 'object' && userOrgId !== null && 'id' in userOrgId) {
          cleanData.organization_id = Number((userOrgId as any).id);
        } else {
          cleanData.organization_id = Number(userOrgId);
        }
      // Log what we're about to send
      console.log("Saving initiative with clean data:", JSON.stringify(cleanData, null, 2));
      // Copy additional properties
      if (data.initiative_feed) {
        cleanData.initiative_feed = data.initiative_feed;
      }
      
      console.log("Saving initiative with clean data:", cleanData);
      
                     (selectedObjectiveId as any).id : selectedObjectiveId;
        cleanData.strategic_objective = String(objId || '');
        await initiatives.update(editingInitiative.id, cleanData);
        await initiatives.update(editingInitiative.id, cleanData);
        // Create new initiative
        cleanData.strategic_objective = null;
        await initiatives.create(cleanData);
      }
      
      // Force re-render of initiative list
      refreshData();
      
      // Reset form state
      setEditingInitiative(null);
    } catch (error: any) {
      console.error('Error saving initiative:', error);
      throw error;
    }
  };

```

I've added the missing closing curly brace `}` that was needed to close the `if (selectedProgram)` block in the `handleInitiativeSave` function. The rest of the file appears to be properly balanced with its brackets.