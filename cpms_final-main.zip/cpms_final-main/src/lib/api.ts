import axios from 'axios';
import Cookies from 'js-cookie';

// Create axios instance with default config
const apiUrl = import.meta.env.VITE_API_URL || '/api';
console.log('API URL configured as:', apiUrl);
const finalApiUrl = apiUrl.endsWith('/') ? apiUrl.slice(0, -1) : apiUrl;
console.log('Final API URL to be used:', finalApiUrl);

export const api = axios.create({
  baseURL: finalApiUrl,
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true, // Important for CSRF token handling
});

// Add request interceptor to include CSRF token
api.interceptors.request.use(
  async (config) => {
    // Log the request for debugging
    console.log(`API Request: ${config.method?.toUpperCase()} ${config.baseURL}${config.url}`);

    // Add CSRF token to requests if available
    const csrfToken = Cookies.get('csrftoken');
    if (csrfToken) {
      config.headers['X-CSRFToken'] = csrfToken;
      console.log('Using CSRF token:', csrfToken.substring(0, 5) + '...');
    } else {
      console.warn('No CSRF token available for request');
    }

    // Log headers for debugging
    console.log('Request headers:', JSON.stringify(config.headers));

    return config;
  },
  (error) => {
    console.error('Request interceptor error:', error);
    return Promise.reject(error);
  }
);

// Add response interceptor to handle common errors
api.interceptors.response.use(
  (response) => {
    // Log successful responses in production for debugging
    if (process.env.NODE_ENV === 'production') {
      console.log(`Response from ${response.config.url}: Status ${response.status}`);
    }
    console.log('Making API call to get approved LEO/EO plans...');
    const response = await api.get('/team-desk-plans/approved-leo-eo-plans/');
    console.log('API response for approved plans:', response);
    return response;
  },
  async (error) => {
    // Handle 401 Unauthorized (session expired)
    if (error.response && error.response.status === 401) {
      console.error('401 Unauthorized - redirecting to login');
      // Redirect to login page
      window.location.href = '/login';
    }
    
    // Handle 403 Forbidden (CSRF token missing/invalid)
    if (error.response && error.response.status === 403) {
      console.error('403 Forbidden - refreshing CSRF token');
      // Try to get a new CSRF token
      try {
        await axios.get('/api/auth/csrf/', { withCredentials: true });
        // Retry the original request
        return api(error.config);
      } catch (csrfError) {
        console.error('Failed to refresh CSRF token:', csrfError);
        // Still include the original error for debugging
        console.error('Original error:', error);
      }
    }
    
    // Log detailed error information for debugging
    if (error.response) {
      // The request was made and the server responded with a status code outside of 2xx
      console.error('API Error Response:', error.response.status, error.response.data);
    } else if (error.request) {
      // The request was made but no response was received
      console.error('API No Response:', error.request);
    } else {
      // Something happened in setting up the request that triggered an Error
      console.error('API Request Error:', error.message);
    }

    return Promise.reject(error);
  }
);

// Auth API
export const auth = {
  login: async (username: string, password: string) => {
    try {
      const response = await api.post('/auth/login/', { username, password });
      return { success: true, ...response.data };
    } catch (error) {
      console.error('Login error:', error);
      return { 
        success: false, 
        error: error.response?.data?.detail || 'Login failed. Please check your credentials.' 
      };
    }
  },
  
  logout: async () => {
    try {
      await api.post('/auth/logout/');
      window.location.href = '/login';
      return { success: true };
    } catch (error) {
      console.error('Logout error:', error);
      // Redirect to login anyway
      window.location.href = '/login';
      return { success: false, error: 'Logout failed' };
    }
  },
  
  checkAuth: async () => {
    try {
      const response = await api.get('/auth/check/');
      return response.data;
    } catch (error) {
      console.error('Auth check error:', error);
      return { isAuthenticated: false };
    }
  },
  
  getCurrentUser: async () => {
    try {
      const response = await api.get('/auth/check/');
      return response.data;
    } catch (error) {
      console.error('Get current user error:', error);
      return { isAuthenticated: false };
    }
  },
  
  isAuthenticated: () => {
    // This is a synchronous check that can be used in component rendering
    // It's not as reliable as checkAuth() but useful for initial UI state
    const authCookie = Cookies.get('sessionid');
    return !!authCookie;
  },
  
  updateProfile: async (data: any) => {
    try {
      const response = await api.patch('/auth/profile/', data);
      return { success: true, ...response.data };
    } catch (error) {
      console.error('Profile update error:', error);
      return { 
        success: false, 
        error: error.response?.data?.detail || 'Failed to update profile' 
      };
    }
  },
  
  changePassword: async (data: { current_password: string; new_password: string }) => {
    try {
      const response = await api.post('/auth/password_change/', data);
      return { success: true, ...response.data };
    } catch (error) {
      console.error('Password change error:', error);
      return { 
        success: false, 
        error: error.response?.data?.detail || 'Failed to change password' 
      };
    }
  }
};

// Organizations API
export const organizations = {
  getAll: async () => {
    try {
      const response = await api.get('/organizations/');
      return response.data;
    } catch (error) {
      console.error('Failed to fetch organizations:', error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/organizations/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch organization ${id}:`, error);
      throw error;
    }
  },
  
  update: async (id: string, data: any) => {
    try {
      const response = await api.patch(`/organizations/${id}/`, data);
      return response.data;
    } catch (error) {
      console.error(`Failed to update organization ${id}:`, error);
      throw error;
    }
  }
};

// Strategic Objectives API
export const objectives = {
  getAll: async () => {
    try {
      const response = await api.get('/strategic-objectives/');
      return response;
    } catch (error) {
      console.error('Failed to fetch objectives:', error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/strategic-objectives/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch objective ${id}:`, error);
      throw error;
    }
  },
  
  create: async (data: any) => {
    try {
      const response = await api.post('/strategic-objectives/', data);
      return response.data;
    } catch (error) {
      console.error('Failed to create objective:', error);
      throw error;
    }
  },
  
  update: async (id: string, data: any) => {
    try {
      const response = await api.patch(`/strategic-objectives/${id}/`, data);
      return response.data;
    } catch (error) {
      console.error(`Failed to update objective ${id}:`, error);
      throw error;
    }
  },
  
  delete: async (id: string) => {
    try {
      await api.delete(`/strategic-objectives/${id}/`);
      return { success: true };
    } catch (error) {
      console.error(`Failed to delete objective ${id}:`, error);
      throw error;
    }
  },
  
  getWeightSummary: async () => {
    try {
      const response = await api.get('/strategic-objectives/weight-summary/');
      return response;
    } catch (error) {
      console.error('Failed to fetch objective weight summary:', error);
      throw error;
    }
  },
  
  validateTotalWeight: async () => {
    try {
      const response = await api.post('/strategic-objectives/validate-total-weight/');
      return response;
    } catch (error) {
      console.error('Failed to validate objective weights:', error);
      throw error;
    }
  }
};

// Programs API
export const programs = {
  getAll: async () => {
    try {
      const response = await api.get('/programs/');
      return response;
    } catch (error) {
      console.error('Failed to fetch programs:', error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/programs/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch program ${id}:`, error);
      throw error;
    }
  },
  
  getByObjective: async (objectiveId: string) => {
    try {
      const response = await api.get(`/programs/?strategic_objective=${objectiveId}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch programs for objective ${objectiveId}:`, error);
      throw error;
    }
  },
  
  create: async (data: any) => {
    try {
      const response = await api.post('/programs/', data);
      return response.data;
    } catch (error) {
      console.error('Failed to create program:', error);
      throw error;
    }
  },
  
  update: async (id: string, data: any) => {
    try {
      const response = await api.patch(`/programs/${id}/`, data);
      return response.data;
    } catch (error) {
      console.error(`Failed to update program ${id}:`, error);
      throw error;
    }
  },
  
  delete: async (id: string) => {
    try {
      await api.delete(`/programs/${id}/`);
      return { success: true };
    } catch (error) {
      console.error(`Failed to delete program ${id}:`, error);
      throw error;
    }
  }
};

// Strategic Initiatives API
export const initiatives = {
  getAll: async () => {
    try {
      const response = await api.get('/strategic-initiatives/');
      return response;
    } catch (error) {
      console.error('Failed to fetch initiatives:', error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/strategic-initiatives/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch initiative ${id}:`, error);
      throw error;
    }
  },
  
  getByObjective: async (objectiveId: string) => {
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      const response = await api.get(`/strategic-initiatives/?objective=${objectiveId}&_=${timestamp}`, {
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache'
        }
      });
      return response;
    } catch (error) {
      console.error(`Failed to fetch initiatives for objective ${objectiveId}:`, error);
      throw error;
    }
  },
  
  getByProgram: async (programId: string) => {
    try {
      const response = await api.get(`/strategic-initiatives/?program=${programId}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch initiatives for program ${programId}:`, error);
      throw error;
    }
  },
  
  getBySubProgram: async (subProgramId: string) => {
    try {
      const response = await api.get(`/strategic-initiatives/?subprogram=${subProgramId}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch initiatives for subprogram ${subProgramId}:`, error);
      throw error;
    }
  },
  
  create: async (data: any) => {
    try {
      const response = await api.post('/strategic-initiatives/', data);
      return response.data;
    } catch (error) {
      console.error('Failed to create initiative:', error);
      throw error;
    }
  },
  
  update: async (id: string, data: any) => {
    try {
      const response = await api.patch(`/strategic-initiatives/${id}/`, data);
      return response.data;
    } catch (error) {
      console.error(`Failed to update initiative ${id}:`, error);
      throw error;
    }
  },
  
  delete: async (id: string) => {
    try {
      await api.delete(`/strategic-initiatives/${id}/`);
      return { success: true };
    } catch (error) {
      console.error(`Failed to delete initiative ${id}:`, error);
      throw error;
    }
  },
  
  getWeightSummary: async (parentId: string, parentType: string) => {
    try {
      // Fix API endpoint parameter naming for production
      const paramName = parentType === 'objective' ? 'objective' : 
                       parentType === 'program' ? 'program' : 
                       parentType === 'subprogram' ? 'subprogram' : parentType;
      
      const response = await api.get(`/strategic-initiatives/weight-summary/?${paramName}=${parentId}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch initiative weight summary for ${parentType} ${parentId}:`, error);
      // Return empty data instead of throwing to prevent UI breaks
      return {
        data: {
          total_initiatives_weight: 0,
          remaining_weight: 100,
          parent_weight: 100,
          is_valid: true
        }
      };
    }
  },
  
  validateInitiativesWeight: async (parentId: string, parentType: string) => {
    try {
      const response = await api.post(`/strategic-initiatives/validate-initiatives-weight/?${parentType}=${parentId}`);
      return response;
    } catch (error) {
      console.error(`Failed to validate initiative weights for ${parentType} ${parentId}:`, error);
      throw error;
    }
  }
};

// Performance Measures API
export const performanceMeasures = {
  getAll: async () => {
    try {
      const response = await api.get('/performance-measures/');
      return response;
    } catch (error) {
      console.error('Failed to fetch performance measures:', error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/performance-measures/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch performance measure ${id}:`, error);
      throw error;
    }
  },
  
  getByInitiative: async (initiativeId: string) => {
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      const response = await api.get(`/performance-measures/?initiative=${initiativeId}&_=${timestamp}`, {
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache'
        }
      });
      return response;
    } catch (error) {
      console.error(`Failed to fetch performance measures for initiative ${initiativeId}:`, error);
      throw error;
    }
  },
  
  create: async (data: any) => {
    try {
      const response = await api.post('/performance-measures/', data);
      return response.data;
    } catch (error) {
      console.error('Failed to create performance measure:', error);
      throw error;
    }
  },
  
  update: async (id: string, data: any) => {
    try {
      const response = await api.patch(`/performance-measures/${id}/`, data);
      return response.data;
    } catch (error) {
      console.error(`Failed to update performance measure ${id}:`, error);
      throw error;
    }
  },
  
  delete: async (id: string) => {
    try {
      await api.delete(`/performance-measures/${id}/`);
      return { success: true };
    } catch (error) {
      console.error(`Failed to delete performance measure ${id}:`, error);
      throw error;
    }
  },
  
  getWeightSummary: async (initiativeId: string) => {
    try {
      const response = await api.get(`/performance-measures/weight-summary/?initiative=${initiativeId}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch performance measure weight summary for initiative ${initiativeId}:`, error);
      throw error;
    }
  },
  
  validateMeasuresWeight: async (initiativeId: string) => {
    try {
      const response = await api.post(`/performance-measures/validate-measures-weight/?initiative=${initiativeId}`);
      return response;
    } catch (error) {
      console.error(`Failed to validate performance measure weights for initiative ${initiativeId}:`, error);
      throw error;
    }
  }
};

// Main Activities API
export const mainActivities = {
  getAll: async () => {
    try {
      const response = await api.get('/main-activities/');
      return response;
    } catch (error) {
      console.error('Failed to fetch main activities:', error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/main-activities/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch main activity ${id}:`, error);
      throw error;
    }
  },
  
  getByInitiative: async (initiativeId: string) => {
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      const response = await api.get(`/main-activities/?initiative=${initiativeId}&_=${timestamp}`, {
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache'
        }
      });
      return response;
    } catch (error) {
      console.error(`Failed to fetch main activities for initiative ${initiativeId}:`, error);
      throw error;
    }
  },
  
  create: async (data: any) => {
    try {
      const response = await api.post('/main-activities/', data);
      return response.data;
    } catch (error) {
      console.error('Failed to create main activity:', error);
      throw error;
    }
  },
  
  update: async (id: string, data: any) => {
    try {
      const response = await api.patch(`/main-activities/${id}/`, data);
      return response.data;
    } catch (error) {
      console.error(`Failed to update main activity ${id}:`, error);
      throw error;
    }
  },
  
  delete: async (id: string) => {
    try {
      await api.delete(`/main-activities/${id}/`);
      return { success: true };
    } catch (error) {
      console.error(`Failed to delete main activity ${id}:`, error);
      throw error;
    }
  },
  
  getWeightSummary: async (initiativeId: string) => {
    try {
      const response = await api.get(`/main-activities/weight-summary/?initiative=${initiativeId}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch main activity weight summary for initiative ${initiativeId}:`, error);
      throw error;
    }
  },
  
  validateActivitiesWeight: async (initiativeId: string) => {
    try {
      const response = await api.post(`/main-activities/validate-activities-weight/?initiative=${initiativeId}`);
      return response;
    } catch (error) {
      console.error(`Failed to validate main activity weights for initiative ${initiativeId}:`, error);
      throw error;
    }
  },
  
  updateBudget: async (activityId: string, budgetData: any) => {
    try {
      const response = await api.post(`/main-activities/${activityId}/budget/`, budgetData);
      return response.data;
    } catch (error) {
      console.error(`Failed to update budget for activity ${activityId}:`, error);
      throw error;
    }
  }
};

// Activity Budgets API
export const activityBudgets = {
  getAll: async () => {
    try {
      const response = await api.get('/activity-budgets/');
      return response;
    } catch (error) {
      console.error('Failed to fetch activity budgets:', error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/activity-budgets/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch activity budget ${id}:`, error);
      throw error;
    }
  },
  
  getByActivity: async (activityId: string) => {
    try {
      const response = await api.get(`/activity-budgets/?activity=${activityId}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch budget for activity ${activityId}:`, error);
      throw error;
    }
  },
  
  create: async (data: any) => {
    try {
      const response = await api.post('/activity-budgets/', data);
      return response.data;
    } catch (error) {
      console.error('Failed to create activity budget:', error);
      throw error;
    }
  },
  
  update: async (id: string, data: any) => {
    try {
      const response = await api.patch(`/activity-budgets/${id}/`, data);
      return response.data;
    } catch (error) {
      console.error(`Failed to update activity budget ${id}:`, error);
      throw error;
    }
  },
  
  delete: async (id: string) => {
    try {
      await api.delete(`/activity-budgets/${id}/`);
      return { success: true };
    } catch (error) {
      console.error(`Failed to delete activity budget ${id}:`, error);
      throw error;
    }
  }
};

// Activity Costing Assumptions API
export const activityCostingAssumptions = {
  getAll: async () => {
    try {
      const response = await api.get('/activity-costing-assumptions/');
      return response;
    } catch (error) {
      console.error('Failed to fetch activity costing assumptions:', error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/activity-costing-assumptions/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch activity costing assumption ${id}:`, error);
      throw error;
    }
  },
  
  getByActivityType: async (activityType: string) => {
    try {
      const response = await api.get(`/activity-costing-assumptions/?activity_type=${activityType}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch costing assumptions for activity type ${activityType}:`, error);
      throw error;
    }
  },
  
  create: async (data: any) => {
    try {
      const response = await api.post('/activity-costing-assumptions/', data);
      return response.data;
    } catch (error) {
      console.error('Failed to create activity costing assumption:', error);
      throw error;
    }
  },
  
  update: async (id: string, data: any) => {
    try {
      const response = await api.patch(`/activity-costing-assumptions/${id}/`, data);
      return response.data;
    } catch (error) {
      console.error(`Failed to update activity costing assumption ${id}:`, error);
      throw error;
    }
  },
  
  delete: async (id: string) => {
    try {
      await api.delete(`/activity-costing-assumptions/${id}/`);
      return { success: true };
    } catch (error) {
      console.error(`Failed to delete activity costing assumption ${id}:`, error);
      throw error;
    }
  }
};

// Plans API
export const plans = {
  getAll: async () => {
    try {
      // Add timestamp to prevent caching and ensure fresh data
      const timestamp = new Date().getTime();
      const response = await api.get(`/plans/?_=${timestamp}`, {
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache'
        }
      });
      return response;
    } catch (error) {
      console.error('Failed to fetch plans:', error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/plans/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch plan ${id}:`, error);
      throw error;
    }
  },
  
  create: async (data: any) => {
    try {
      const response = await api.post('/plans/', data);
      return response.data;
    } catch (error) {
      console.error('Failed to create plan:', error);
      throw error;
    }
  },
  
  update: async (id: string, data: any) => {
    try {
      const response = await api.patch(`/plans/${id}/`, data);
      return response.data;
    } catch (error) {
      console.error(`Failed to update plan ${id}:`, error);
      throw error;
    }
  },
  
  delete: async (id: string) => {
    try {
      await api.delete(`/plans/${id}/`);
      return { success: true };
    } catch (error) {
      console.error(`Failed to delete plan ${id}:`, error);
      throw error;
    }
  },
  
  submitToEvaluator: async (id: string) => {
    try {
      const response = await api.post(`/plans/${id}/submit/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to submit plan ${id} to evaluator:`, error);
      throw error;
    }
  },
  
  getPendingReviews: async () => {
    try {
      const response = await api.get('/plans/pending-reviews/');
      return response;
    } catch (error) {
      console.error('Failed to fetch pending reviews:', error);
      throw error;
    }
  }
};

// Plan Reviews API
export const planReviews = {
  getAll: async () => {
    try {
      const response = await api.get('/plan-reviews/');
      return response;
    } catch (error) {
      console.error('Failed to fetch plan reviews:', error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/plan-reviews/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch plan review ${id}:`, error);
      throw error;
    }
  },
  
  getByPlan: async (planId: string) => {
    try {
      const response = await api.get(`/plan-reviews/?plan=${planId}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch reviews for plan ${planId}:`, error);
      throw error;
    }
  },
  
  create: async (data: any) => {
    try {
      const response = await api.post('/plan-reviews/', data);
      return response.data;
    } catch (error) {
      console.error('Failed to create plan review:', error);
      throw error;
    }
  },
  
  update: async (id: string, data: any) => {
    try {
      const response = await api.patch(`/plan-reviews/${id}/`, data);
      return response.data;
    } catch (error) {
      console.error(`Failed to update plan review ${id}:`, error);
      throw error;
    }
  },
  
  delete: async (id: string) => {
    try {
      await api.delete(`/plan-reviews/${id}/`);
      return { success: true };
    } catch (error) {
      console.error(`Failed to delete plan review ${id}:`, error);
      throw error;
    }
  }
};

// Initiative Feed API
export const initiativeFeeds = {
  getAll: async () => {
    try {
      const response = await api.get('/initiative-feeds/');
      return response;
    } catch (error) {
      console.error('Failed to fetch initiative feeds:', error);
      throw error;
    }
  },
  
  getByObjective: async (objectiveId: string) => {
    try {
      const response = await api.get(`/initiative-feeds/?strategic_objective=${objectiveId}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch initiative feeds for objective ${objectiveId}:`, error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/initiative-feeds/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch initiative feed ${id}:`, error);
      throw error;
    }
  },
  
  create: async (data: any) => {
    try {
      const response = await api.post('/initiative-feeds/', data);
      return response.data;
    } catch (error) {
      console.error('Failed to create initiative feed:', error);
      throw error;
    }
  },
  
  update: async (id: string, data: any) => {
    try {
      const response = await api.patch(`/initiative-feeds/${id}/`, data);
      return response.data;
    } catch (error) {
      console.error(`Failed to update initiative feed ${id}:`, error);
      throw error;
    }
  },
  
  delete: async (id: string) => {
    try {
      await api.delete(`/initiative-feeds/${id}/`);
      return { success: true };
    } catch (error) {
      console.error(`Failed to delete initiative feed ${id}:`, error);
      throw error;
    }
  }
};

// Locations API
export const locations = {
  getAll: async () => {
    console.log('Fetching all locations from API...');
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      const url = `/locations/?_=${timestamp}`;
      console.log(`Making request to: ${api.defaults.baseURL}${url}`);
      const response = await api.get(`/locations/?_=${timestamp}`, {
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'X-Requested-With': 'XMLHttpRequest'
        }
      });
      
      if (!response || !response.data) {
        console.warn('Empty response received from locations API');
        // Return empty array instead of throwing
        return { data: [] };
      }
      
      console.log('Fetched locations data count:', response.data?.length || 0);
      return response;
    } catch (error) {
      console.error('Failed to fetch locations:', error, error.response?.data || 'No response data');
      console.error('API URL used:', api.defaults.baseURL);
      throw error;
    }
  },

  getById: async (id: string) => {
    try {
      const response = await api.get(`/locations/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch location ${id}:`, error);
      throw error;
    }
  }
};

// Land Transports API
export const landTransports = {
  getAll: async () => {
    console.log('Fetching all land transports from API...');
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      console.log(`Making request to: ${api.defaults.baseURL}/land-transports/`);
      const response = await api.get('/land-transports/', {
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache'
        }
      });
      console.log('Fetched land transports data count:', response.data?.length || 0);
      if (!response || !response.data) {
        console.warn('Empty response received from land-transports API');
        return { data: [] };
      }
      
      console.log('Fetched land transports data count:', response.data?.length || 0);
      return response; 
    } catch (error) {
      console.error('Failed to fetch land transports:', error, error.response?.data || 'No response data');
      console.error('API URL used:', api.defaults.baseURL);
      // Return empty array instead of throwing
      return { data: [] };
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/land-transports/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch land transport ${id}:`, error);
      throw error;
    }
  }
};

// Air Transports API
export const airTransports = {
  getAll: async () => {
    console.log('Fetching all air transports from API...');
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      console.log(`Making request to: ${api.defaults.baseURL}/air-transports/`);
      const response = await api.get('/air-transports/', {
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache'
        }
      });
      
      if (!response || !response.data) {
        console.warn('Empty response received from air-transports API');
        return { data: [] };
      }
      
      console.log('Fetched air transports data count:', response.data?.length || 0);
      return response;
    } catch (error) {
      console.error('Failed to fetch air transports:', error, error.response?.data || 'No response data');
      console.error('API URL used:', api.defaults.baseURL);
      // Return empty array instead of throwing
      return { data: [] };
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/air-transports/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch air transport ${id}:`, error);
      throw error;
    }
  }
};

// Per Diems API
export const perDiems = {
  getAll: async () => {
    console.log('Fetching all per diems from API...');
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      const response = await api.get(`/per-diems/?_=${timestamp}`, {
        headers: {
          'Cache-Control': 'no-cache',
          'X-Requested-With': 'XMLHttpRequest'
        }
      });
      console.log('Fetched per-diems data count:', response.data?.length || 0);
      return response;
    } catch (error) {
      console.error('Failed to fetch per diems:', error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/per-diems/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch per diem ${id}:`, error);
      throw error;
    }
  }
};

// Accommodations API
export const accommodations = {
  getAll: async () => {
    console.log('Fetching all accommodations from API');
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      const response = await api.get(`/accommodations/?_=${timestamp}`, {
        headers: {
          'Cache-Control': 'no-cache',
          'X-Requested-With': 'XMLHttpRequest'
        }
      });
      console.log('Fetched accommodations data count:', response.data?.length || 0);
      return response;
    } catch (error) {
      console.error('Failed to fetch accommodations:', error);
      // Return empty data instead of throwing
      return { data: [] };
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/accommodations/${id}/`);
      return response
    } catch (error) {
      console.error(`Failed to fetch accommodation ${id}:`, error);
      throw error;
    }
  }
};

// Participant Costs API
export const participantCosts = {
  getAll: async () => {
    console.log('Fetching all participant costs from API');
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      const response = await api.get(`/participant-costs/?_=${timestamp}`, {
        headers: {
          'Cache-Control': 'no-cache',
          'X-Requested-With': 'XMLHttpRequest'
        }
      });
      console.log('Fetched participant costs data count:', response.data?.length || 0);
      return response;
    } catch (error) {
      console.error('Failed to fetch participant costs:', error);
      // Return empty data instead of throwing
      return { data: [] };
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/participant-costs/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch participant cost ${id}:`, error);
      throw error;
    }
  }
};

// Session Costs API
export const sessionCosts = {
  getAll: async () => {
    console.log('Fetching all session costs from API');
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      const response = await api.get(`/session-costs/?_=${timestamp}`, {
        headers: {
          'Cache-Control': 'no-cache',
          'X-Requested-With': 'XMLHttpRequest'
        }
      });
      console.log('Fetched session costs data count:', response.data?.length || 0);
      return response;
    } catch (error) {
      console.error('Failed to fetch session costs:', error);
      // Return empty data instead of throwing
      return { data: [] };
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/session-costs/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch session cost ${id}:`, error);
      throw error;
    }
  }
};

// Printing Costs API
export const printingCosts = {
  getAll: async () => {
    console.log('Fetching all printing costs from API');
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      const response = await api.get(`/printing-costs/?_=${timestamp}`, {
        headers: {
          'Cache-Control': 'no-cache',
          'X-Requested-With': 'XMLHttpRequest'
        }
      });
      console.log('Fetched printing costs data count:', response.data?.length || 0);
      return response;
    } catch (error) {
      console.error('Failed to fetch printing costs:', error);
      // Return empty data instead of throwing
      return { data: [] };
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/printing-costs/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch printing cost ${id}:`, error);
      throw error;
    }
  }
};

// Supervisor Costs API
export const supervisorCosts = {
  getAll: async () => {
    console.log('Fetching all supervisor costs from API');
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      const response = await api.get(`/supervisor-costs/?_=${timestamp}`, {
        headers: {
          'Cache-Control': 'no-cache',
          'X-Requested-With': 'XMLHttpRequest'
        }
      });
      console.log('Fetched supervisor costs data count:', response.data?.length || 0);
      return response;
    } catch (error) {
      console.error('Failed to fetch supervisor costs:', error);
      // Return empty data instead of throwing
      return { data: [] };
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/supervisor-costs/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch supervisor cost ${id}:`, error);
      throw error;
    }
  }
};

// Detail Activities API
export const detailActivities = {
  getAll: async () => {
    try {
      const response = await api.get('/detail-activities/');
      return response;
    } catch (error) {
      console.error('Failed to fetch detail activities:', error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/detail-activities/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch detail activity ${id}:`, error);
      throw error;
    }
  },
  
  getByMainActivity: async (mainActivityId: string) => {
    try {
      const timestamp = new Date().getTime();
      const response = await api.get(`/detail-activities/?main_activity=${mainActivityId}&_=${timestamp}`, {
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache'
        }
      });
      return response;
    } catch (error) {
      console.error(`Failed to fetch detail activities for main activity ${mainActivityId}:`, error);
      throw error;
    }
  },
  
  getByOrganization: async (organizationId: string) => {
    try {
      const response = await api.get(`/detail-activities/?organization=${organizationId}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch detail activities for organization ${organizationId}:`, error);
      throw error;
    }
  },
  
  create: async (data: any) => {
    try {
      const response = await api.post('/detail-activities/', data);
      return response.data;
    } catch (error) {
      console.error('Failed to create detail activity:', error);
      throw error;
    }
  },
  
  update: async (id: string, data: any) => {
    try {
      const response = await api.patch(`/detail-activities/${id}/`, data);
      return response.data;
    } catch (error) {
      console.error(`Failed to update detail activity ${id}:`, error);
      throw error;
    }
  },
  
  delete: async (id: string) => {
    try {
      await api.delete(`/detail-activities/${id}/`);
      return { success: true };
    } catch (error) {
      console.error(`Failed to delete detail activity ${id}:`, error);
      throw error;
    }
  }
};

// Team Desk Plans API
export const teamDeskPlans = {
  getAll: async () => {
    try {
      const timestamp = new Date().getTime();
      const response = await api.get(`/team-desk-plans/?_=${timestamp}`, {
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache'
        }
      });
      return response;
    } catch (error) {
      console.error('Failed to fetch team desk plans:', error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/team-desk-plans/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch team desk plan ${id}:`, error);
      throw error;
    }
  },
  
  getByOrganization: async (organizationId: string) => {
    try {
      const response = await api.get(`/team-desk-plans/?organization=${organizationId}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch team desk plans for organization ${organizationId}:`, error);
      throw error;
    }
  },
  
  getByTeamDesk: async (teamDeskId: string) => {
    try {
      const response = await api.get(`/team-desk-plans/?team_desk=${teamDeskId}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch team desk plans for team/desk ${teamDeskId}:`, error);
      throw error;
    }
  },
  
  getApprovedLeoEoPlans: async () => {
    try {
      console.log('Making API call to get approved LEO/EO plans...');
      const response = await api.get('/team-desk-plans/approved-leo-eo-plans/');
      console.log('API response for approved plans:', response);
      return response;
    } catch (error) {
      console.error('Failed to fetch approved LEO/EO plans:', error);
      throw error;
    }
  },
  
  create: async (data: any) => {
    try {
      const response = await api.post('/team-desk-plans/', data);
      return response.data;
    } catch (error) {
      console.error('Failed to create team desk plan:', error);
      throw error;
    }
  },
  
  update: async (id: string, data: any) => {
    try {
      const response = await api.patch(`/team-desk-plans/${id}/`, data);
      return response.data;
    } catch (error) {
      console.error(`Failed to update team desk plan ${id}:`, error);
      throw error;
    }
  },
  
  delete: async (id: string) => {
    try {
      await api.delete(`/team-desk-plans/${id}/`);
      return { success: true };
    } catch (error) {
      console.error(`Failed to delete team desk plan ${id}:`, error);
      throw error;
    }
  },
  
  submit: async (id: string) => {
    try {
      const response = await api.post(`/team-desk-plans/${id}/submit/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to submit team desk plan ${id}:`, error);
      throw error;
    }
  }
};

// Team Desk Plan Reviews API
export const teamDeskPlanReviews = {
  getAll: async () => {
    try {
      const response = await api.get('/team-desk-plan-reviews/');
      return response;
    } catch (error) {
      console.error('Failed to fetch team desk plan reviews:', error);
      throw error;
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/team-desk-plan-reviews/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch team desk plan review ${id}:`, error);
      throw error;
    }
  },
  
  getByPlan: async (planId: string) => {
    try {
      const response = await api.get(`/team-desk-plan-reviews/?plan=${planId}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch reviews for team desk plan ${planId}:`, error);
      throw error;
    }
  },
  
  getPendingReviews: async () => {
    try {
      const response = await api.get('/team-desk-plan-reviews/pending/');
      return response;
    } catch (error) {
      console.error('Failed to fetch pending team desk plan reviews:', error);
      throw error;
    }
  },
  
  create: async (data: any) => {
    try {
      const response = await api.post('/team-desk-plan-reviews/', data);
      return response.data;
    } catch (error) {
      console.error('Failed to create team desk plan review:', error);
      throw error;
    }
  },
  
  update: async (id: string, data: any) => {
    try {
      const response = await api.patch(`/team-desk-plan-reviews/${id}/`, data);
      return response.data;
    } catch (error) {
      console.error(`Failed to update team desk plan review ${id}:`, error);
      throw error;
    }
  },
  
  delete: async (id: string) => {
    try {
      await api.delete(`/team-desk-plan-reviews/${id}/`);
      return { success: true };
    } catch (error) {
      console.error(`Failed to delete team desk plan review ${id}:`, error);
      throw error;
    }
  },
  
  approve: async (id: string, feedback: string = '') => {
    try {
      const response = await api.post(`/team-desk-plan-reviews/${id}/approve/`, { feedback });
      return response.data;
    } catch (error) {
      console.error(`Failed to approve team desk plan review ${id}:`, error);
      throw error;
    }
  },
  
  reject: async (id: string, feedback: string) => {
    try {
      const response = await api.post(`/team-desk-plan-reviews/${id}/reject/`, { feedback });
      return response.data;
    } catch (error) {
      console.error(`Failed to reject team desk plan review ${id}:`, error);
      throw error;
    }
  }
};

// Procurement Items API
export const procurementItems = {
  getAll: async () => {
    console.log('Fetching all procurement items from API');
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      const response = await api.get(`/procurement-items/?_=${timestamp}`, {
        headers: {
          'Cache-Control': 'no-cache',
          'X-Requested-With': 'XMLHttpRequest'
        }
      });
      console.log('Fetched procurement items data count:', response.data?.length || 0);
      return response;
    } catch (error) {
      console.error('Failed to fetch procurement items:', error);
      // Return empty data instead of throwing
      return { data: [] };
    }
  },
  
  getById: async (id: string) => {
    try {
      const response = await api.get(`/procurement-items/${id}/`);
      return response.data;
    } catch (error) {
      console.error(`Failed to fetch procurement item ${id}:`, error);
      throw error;
    }
  },
  
  getByCategory: async (category: string) => {
    try {
      const response = await api.get(`/procurement-items/?category=${category}`);
      return response;
    } catch (error) {
      console.error(`Failed to fetch procurement items for category ${category}:`, error);
      return { data: [] };
    }
  }
};