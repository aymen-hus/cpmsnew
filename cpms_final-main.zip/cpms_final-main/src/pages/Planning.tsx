import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Calendar, Building2, User, FileType, Target, Plus, Edit, Trash2, AlertCircle, CheckCircle, Info, Loader, ArrowRight, Save, Eye } from 'lucide-react';
import { useLanguage } from '../lib/i18n/LanguageContext';
import { organizations, objectives, initiatives, performanceMeasures, mainActivities, plans, auth } from '../lib/api';
import { format } from 'date-fns';
import type { Organization, StrategicObjective, StrategicInitiative, Program } from '../types/organization';
import type { PlanType } from '../types/plan';
import { isPlanner, isAdmin, isTeamDeskPlanner } from '../types/user';

// Import components
import PlanTypeSelector from '../components/PlanTypeSelector';
import HorizontalObjectiveSelector from '../components/HorizontalObjectiveSelector';
import InitiativeForm from '../components/InitiativeForm';
import PerformanceMeasureForm from '../components/PerformanceMeasureForm';
import PerformanceMeasureList from '../components/PerformanceMeasureList';
import MainActivityForm from '../components/MainActivityForm';
import MainActivityList from '../components/MainActivityList';
import ActivityBudgetForm from '../components/ActivityBudgetForm';
import PlanPreviewModal from '../components/PlanPreviewModal';
import PlanSubmitForm from '../components/PlanSubmitForm';
import TrainingCostingTool from '../components/TrainingCostingTool';
import MeetingWorkshopCostingTool from '../components/MeetingWorkshopCostingTool';
import PrintingCostingTool from '../components/PrintingCostingTool';
import ProcurementCostingTool from '../components/ProcurementCostingTool';
import SupervisionCostingTool from '../components/SupervisionCostingTool';

const Planning: React.FC = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  // Main state
  const [currentStep, setCurrentStep] = useState<'plan-type' | 'objectives' | 'planning'>('plan-type');
  const [planType, setPlanType] = useState<PlanType>('LEO/EO Plan');
  const [selectedOrganization, setSelectedOrganization] = useState<Organization | null>(null);
  const [selectedObjectives, setSelectedObjectives] = useState<StrategicObjective[]>([]);
  const [selectedObjectiveId, setSelectedObjectiveId] = useState<string | null>(null);
  const [selectedProgram, setSelectedProgram] = useState<Program | null>(null);
  const [selectedInitiativeId, setSelectedInitiativeId] = useState<string | null>(null);
  
  // Form states
  const [showInitiativeForm, setShowInitiativeForm] = useState(false);
  const [editingInitiative, setEditingInitiative] = useState<StrategicInitiative | null>(null);
  const [showMeasureForm, setShowMeasureForm] = useState(false);
  const [editingMeasure, setEditingMeasure] = useState<any>(null);
  const [showActivityForm, setShowActivityForm] = useState(false);
  const [editingActivity, setEditingActivity] = useState<any>(null);
  const [showBudgetForm, setShowBudgetForm] = useState(false);
  const [editingBudget, setEditingBudget] = useState<any>(null);
  
  // Costing tool states
  const [showCostingTool, setShowCostingTool] = useState(false);
  const [costingToolType, setCostingToolType] = useState<string>('');
  const [costingActivity, setCostingActivity] = useState<any>(null);
  
  // Plan states
  const [showPreview, setShowPreview] = useState(false);
  const [showSubmitForm, setShowSubmitForm] = useState(false);
  const [isSubmittingPlan, setIsSubmittingPlan] = useState(false);
  
  // User and organization data
  const [userOrgId, setUserOrgId] = useState<number | null>(null);
  const [isUserPlanner, setIsUserPlanner] = useState(false);
  const [isUserTeamDeskPlanner, setIsUserTeamDeskPlanner] = useState(false);
  const [plannerName, setPlannerName] = useState('');
  const [authState, setAuthState] = useState<any>(null);
  
  // Planning period
  const [fromDate, setFromDate] = useState(() => {
    const now = new Date();
    const fiscalYearStart = new Date(now.getFullYear(), 6, 1); // July 1st
    if (now < fiscalYearStart) {
      fiscalYearStart.setFullYear(now.getFullYear() - 1);
    }
    return format(fiscalYearStart, 'yyyy-MM-dd');
  });
  
  const [toDate, setToDate] = useState(() => {
    const now = new Date();
    const fiscalYearEnd = new Date(now.getFullYear() + 1, 5, 30); // June 30th next year
    if (now < new Date(now.getFullYear(), 6, 1)) {
      fiscalYearEnd.setFullYear(now.getFullYear());
    }
    return format(fiscalYearEnd, 'yyyy-MM-dd');
  });

  // Error and loading states
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  // Fetch current user and organization data
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const authData = await auth.getCurrentUser();
        if (!authData.isAuthenticated) {
          navigate('/login');
          return;
        }
        
        setAuthState(authData);
        setIsUserPlanner(isPlanner(authData.userOrganizations));
        setIsUserTeamDeskPlanner(isTeamDeskPlanner(authData.userOrganizations));
        
        // If user is team/desk planner only (not regular planner), redirect to team/desk planning page
        if (isTeamDeskPlanner(authData.userOrganizations) && !isPlanner(authData.userOrganizations)) {
          navigate('/team-desk-planning');
          return;
        }
        
        if (authData.userOrganizations && authData.userOrganizations.length > 0) {
          const userOrg = authData.userOrganizations[0];
          setUserOrgId(userOrg.organization);
          
          // Set planner name from user data
          const fullName = `${authData.user.first_name || ''} ${authData.user.last_name || ''}`.trim();
          setPlannerName(fullName || authData.user.username);
        }
      } catch (error) {
        console.error('Failed to fetch user data:', error);
        setError('Failed to load user information');
      }
    };
    
    fetchUserData();
  }, [navigate]);

  // Fetch organizations
  const { data: organizationsData } = useQuery({
    queryKey: ['organizations'],
    queryFn: () => organizations.getAll(),
    enabled: isUserPlanner
  });

  // Set selected organization based on user's organization
  useEffect(() => {
    if (organizationsData && userOrgId) {
      const userOrganization = organizationsData.find((org: Organization) => org.id === userOrgId);
      if (userOrganization) {
        setSelectedOrganization(userOrganization);
      }
    }
  }, [organizationsData, userOrgId]);

  // Force refresh data
  const refreshData = () => {
    setRefreshKey(prev => prev + 1);
    queryClient.invalidateQueries({ queryKey: ['initiatives'] });
    queryClient.invalidateQueries({ queryKey: ['performance-measures'] });
    queryClient.invalidateQueries({ queryKey: ['main-activities'] });
  };

  // Handle plan type selection
  const handlePlanTypeSelect = (type: PlanType) => {
    // Regular planners can only create LEO/EO plans
    if (isUserPlanner && !isUserTeamDeskPlanner && type !== 'LEO/EO Plan') {
      setError('Regular planners can only create LEO/EO plans');
      return;
    }
    
    setPlanType(type);
    
    // Redirect to Team/Desk Planning page if that type is selected
    if (type === 'Desk/Team Plan') {
      navigate('/team-desk-planning');
      return;
    }
    
    setCurrentStep('objectives');
  };

  // Handle objectives selection
  const handleObjectivesSelected = (objectives: StrategicObjective[]) => {
    setSelectedObjectives(objectives);
  };

  // Handle proceed to planning
  const handleProceedToPlanning = () => {
    if (selectedObjectives.length === 0) {
      setError('Please select at least one objective before proceeding');
      return;
    }
    
    setCurrentStep('planning');
    
    // Auto-select first objective if only one is selected
    if (selectedObjectives.length === 1) {
      setSelectedObjectiveId(selectedObjectives[0].id.toString());
      setSelectedProgram(null);
      setSelectedInitiativeId(null);
    }
  };

  // Handle objective selection in planning view
  const handleSelectObjective = (objective: StrategicObjective) => {
    setSelectedObjectiveId(objective.id.toString());
    setSelectedProgram(null);
    setSelectedInitiativeId(null);
    setShowInitiativeForm(false);
    setEditingInitiative(null);
    refreshData();
  };

  // Handle program selection
  const handleSelectProgram = (program: Program) => {
    setSelectedProgram(program);
    setSelectedObjectiveId(null);
    setSelectedInitiativeId(null);
    setShowInitiativeForm(false);
    setEditingInitiative(null);
    refreshData();
  };

  // Handle initiative selection
  const handleSelectInitiative = (initiative: StrategicInitiative) => {
    setSelectedInitiativeId(initiative.id);
    setShowMeasureForm(false);
    setShowActivityForm(false);
    setEditingMeasure(null);
    setEditingActivity(null);
  };

  // Initiative management
  const handleCreateInitiative = () => {
    setEditingInitiative(null);
    setShowInitiativeForm(true);
  };

  const handleEditInitiative = (initiative: StrategicInitiative) => {
    setEditingInitiative(initiative);
    setShowInitiativeForm(true);
  };

  const handleCancelInitiativeForm = () => {
    setShowInitiativeForm(false);
    setEditingInitiative(null);
  };

  // Handle initiative save
  const handleInitiativeSave = async (data: Partial<StrategicInitiative>) => {
    try {
      const cleanData: any = {
        name: data.name || '',
        weight: Number(data.weight || 0),
        is_default: false
      };
      
      // Set parent relationship
      if (selectedObjectiveId) {
        cleanData.strategic_objective = selectedObjectiveId;
        cleanData.program = null;
      } else if (selectedProgram) {
        cleanData.strategic_objective = null;
        cleanData.program = selectedProgram.id.toString();
      }
      
      // Set organization ID
      if (userOrgId) {
        cleanData.organization_id = userOrgId;
      }
      
      // Set initiative feed if selected
      if (data.initiative_feed) {
        cleanData.initiative_feed = data.initiative_feed;
      }
      
      console.log('Saving initiative with data:', cleanData);
      
      if (editingInitiative) {
        await initiatives.update(editingInitiative.id, cleanData);
      } else {
        await initiatives.create(cleanData);
      }
      
      refreshData();
      setShowInitiativeForm(false);
      setEditingInitiative(null);
      setSuccess('Initiative saved successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (error: any) {
      console.error('Error saving initiative:', error);
      setError(error.message || 'Failed to save initiative');
      setTimeout(() => setError(null), 5000);
    }
  };

  // Performance measure management
  const handleCreateMeasure = (initiativeId: string) => {
    setEditingMeasure({ initiative: initiativeId });
    setShowMeasureForm(true);
  };

  const handleEditMeasure = (measure: any) => {
    setEditingMeasure(measure);
    setShowMeasureForm(true);
  };

  const handleMeasureSave = async (data: any) => {
    try {
      if (editingMeasure?.id) {
        await performanceMeasures.update(editingMeasure.id, data);
      } else {
        await performanceMeasures.create(data);
      }
      
      refreshData();
      setShowMeasureForm(false);
      setEditingMeasure(null);
      setSuccess('Performance measure saved successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (error: any) {
      console.error('Error saving performance measure:', error);
      setError(error.message || 'Failed to save performance measure');
      setTimeout(() => setError(null), 5000);
    }
  };

  const handleDeleteMeasure = async (measureId: string) => {
    if (window.confirm('Are you sure you want to delete this performance measure?')) {
      try {
        await performanceMeasures.delete(measureId);
        refreshData();
        setSuccess('Performance measure deleted successfully');
        setTimeout(() => setSuccess(null), 3000);
      } catch (error: any) {
        console.error('Error deleting performance measure:', error);
        setError(error.message || 'Failed to delete performance measure');
        setTimeout(() => setError(null), 5000);
      }
    }
  };

  // Main activity management
  const handleCreateActivity = (initiativeId: string) => {
    setEditingActivity({ initiative: initiativeId });
    setShowActivityForm(true);
  };

  const handleEditActivity = (activity: any) => {
    setEditingActivity(activity);
    setShowActivityForm(true);
  };

  const handleActivitySave = async (data: any) => {
    try {
      if (editingActivity?.id) {
        await mainActivities.update(editingActivity.id, data);
      } else {
        await mainActivities.create(data);
      }
      
      refreshData();
      setShowActivityForm(false);
      setEditingActivity(null);
      setSuccess('Main activity saved successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (error: any) {
      console.error('Error saving main activity:', error);
      setError(error.message || 'Failed to save main activity');
      setTimeout(() => setError(null), 5000);
    }
  };

  const handleDeleteActivity = async (activityId: string) => {
    if (window.confirm('Are you sure you want to delete this main activity?')) {
      try {
        await mainActivities.delete(activityId);
        refreshData();
        setSuccess('Main activity deleted successfully');
        setTimeout(() => setSuccess(null), 3000);
      } catch (error: any) {
        console.error('Error deleting main activity:', error);
        setError(error.message || 'Failed to delete main activity');
        setTimeout(() => setError(null), 5000);
      }
    }
  };

  // Budget management
  const handleEditBudget = (activity: any, budgetCalculationType: string, activityType: string) => {
    setEditingBudget({
      activity,
      budgetCalculationType,
      activityType,
      initialData: activity.budget
    });
    setShowBudgetForm(true);
  };

  const handleBudgetSave = async (budgetData: any) => {
    try {
      if (!editingBudget?.activity?.id) {
        throw new Error('Activity ID is missing');
      }

      await mainActivities.updateBudget(editingBudget.activity.id, budgetData);
      
      refreshData();
      setShowBudgetForm(false);
      setEditingBudget(null);
      setSuccess('Budget saved successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (error: any) {
      console.error('Error saving budget:', error);
      setError(error.message || 'Failed to save budget');
      setTimeout(() => setError(null), 5000);
    }
  };

  // Costing tool management
  const handleOpenCostingTool = (activity: any, toolType: string, activityType: string) => {
    setCostingActivity(activity);
    setCostingToolType(toolType);
    setShowCostingTool(true);
  };

  const handleCostingCalculate = async (costingData: any) => {
    try {
      if (!costingActivity?.id) {
        throw new Error('Activity ID is missing');
      }

      await mainActivities.updateBudget(costingActivity.id, costingData);
      
      refreshData();
      setShowCostingTool(false);
      setCostingActivity(null);
      setCostingToolType('');
      setSuccess('Costing calculated and budget updated successfully');
      setTimeout(() => setSuccess(null), 3000);
    } catch (error: any) {
      console.error('Error calculating costing:', error);
      setError(error.message || 'Failed to calculate costing');
      setTimeout(() => setError(null), 5000);
    }
  };

  // Plan management
  const handlePreviewPlan = () => {
    setShowPreview(true);
  };

  const handleSubmitPlan = () => {
    setShowSubmitForm(true);
  };

  const handlePlanSubmit = async () => {
    try {
      setIsSubmittingPlan(true);
      
      if (!selectedOrganization || selectedObjectives.length === 0) {
        throw new Error('Organization and objectives are required');
      }

      const planData = {
        organization: selectedOrganization.id,
        planner_name: plannerName,
        type: planType,
        strategic_objective: selectedObjectives[0].id,
        fiscal_year: new Date(fromDate).getFullYear().toString(),
        from_date: fromDate,
        to_date: toDate,
        status: 'SUBMITTED'
      };

      await plans.create(planData);
      
      setSuccess('Plan submitted successfully!');
      setTimeout(() => {
        navigate('/dashboard');
      }, 2000);
    } catch (error: any) {
      console.error('Error submitting plan:', error);
      setError(error.message || 'Failed to submit plan');
      setTimeout(() => setError(null), 5000);
    } finally {
      setIsSubmittingPlan(false);
      setShowSubmitForm(false);
    }
  };

  // Get current parent info for initiative creation
  const getCurrentParentInfo = () => {
    if (selectedObjectiveId) {
      const objective = selectedObjectives.find(obj => obj.id.toString() === selectedObjectiveId);
      return {
        parentId: selectedObjectiveId,
        parentType: 'objective' as const,
        parentWeight: objective?.effective_weight || objective?.weight || 0
      };
    } else if (selectedProgram) {
      return {
        parentId: selectedProgram.id.toString(),
        parentType: 'program' as const,
        parentWeight: selectedProgram.strategic_objective?.effective_weight || selectedProgram.strategic_objective?.weight || 0
      };
    }
    return null;
  };

  // Check if user has permission to plan
  if (!isUserPlanner && !isAdmin(authState?.userOrganizations)) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center p-8 bg-yellow-50 rounded-lg border border-yellow-200">
          <AlertCircle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-yellow-800 mb-2">Access Restricted</h3>
          <p className="text-yellow-600">You need planner permissions to access the LEO/EO planning module.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 py-6 sm:px-0">
      {/* Error and Success Messages */}
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center text-red-700">
          <AlertCircle className="h-5 w-5 mr-2" />
          {error}
        </div>
      )}

      {success && (
        <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center text-green-700">
          <CheckCircle className="h-5 w-5 mr-2" />
          {success}
        </div>
      )}

      {/* Step 1: Plan Type Selection */}
      {currentStep === 'plan-type' && (
        <PlanTypeSelector 
          onSelectPlanType={handlePlanTypeSelect} 
          userRole={authState?.userOrganizations?.map(org => org.role) || []}
        />
      )}

      {/* Step 2: Objective Selection */}
      {currentStep === 'objectives' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Select Strategic Objectives</h2>
            <HorizontalObjectiveSelector
              onObjectivesSelected={handleObjectivesSelected}
              onProceed={handleProceedToPlanning}
              initialObjectives={selectedObjectives}
            />
          </div>
        </div>
      )}

      {/* Step 3: Planning - Column Layout */}
      {currentStep === 'planning' && (
        <div className="space-y-6">
          {/* Planning Header */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4 text-gray-500" />
                    Organization
                  </div>
                </label>
                <div className="mt-1 block w-full px-3 py-2 text-base border border-gray-300 rounded-md bg-gray-50">
                  {selectedOrganization?.name || 'Loading...'}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-gray-500" />
                    Planner Name
                  </div>
                </label>
                <div className="mt-1 block w-full px-3 py-2 text-base border border-gray-300 rounded-md bg-gray-50">
                  {plannerName}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <div className="flex items-center gap-2">
                    <FileType className="h-4 w-4 text-gray-500" />
                    Plan Type
                  </div>
                </label>
                <div className="mt-1 block w-full px-3 py-2 text-base border border-gray-300 rounded-md bg-gray-50">
                  {planType}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    Planning Period
                  </div>
                </label>
                <div className="mt-1 block w-full px-3 py-2 text-base border border-gray-300 rounded-md bg-gray-50">
                  {format(new Date(fromDate), 'MMM yyyy')} - {format(new Date(toDate), 'MMM yyyy')}
                </div>
              </div>
            </div>
          </div>

          {/* Main Planning Grid - 4 Columns */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            
            {/* Column 1: Strategic Objectives */}
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
              <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                <Target className="h-5 w-5 text-blue-600 mr-2" />
                Strategic Objectives
              </h3>
              <div className="space-y-3">
                {selectedObjectives.map((objective) => (
                  <div
                    key={objective.id}
                    onClick={() => handleSelectObjective(objective)}
                    className={`p-3 rounded-lg border-2 cursor-pointer transition-colors ${
                      selectedObjectiveId === objective.id.toString()
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-blue-300'
                    }`}
                  >
                    <h4 className="font-medium text-gray-900 text-sm">{objective.title}</h4>
                    <p className="text-xs text-gray-500 mt-1 line-clamp-2">{objective.description}</p>
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                        Weight: {objective.effective_weight || objective.weight}%
                      </span>
                      {selectedObjectiveId === objective.id.toString() && (
                        <CheckCircle className="h-4 w-4 text-blue-600" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Column 2: Strategic Initiatives */}
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900 flex items-center">
                  <Plus className="h-5 w-5 text-green-600 mr-2" />
                  Strategic Initiatives
                </h3>
                {isUserPlanner && (selectedObjectiveId || selectedProgram) && !showInitiativeForm && (
                  <button
                    onClick={handleCreateInitiative}
                    className="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
                  >
                    <Plus className="h-3 w-3 mr-1" />
                    Create
                  </button>
                )}
              </div>

              {!selectedObjectiveId && !selectedProgram ? (
                <div className="text-center p-4 text-gray-500 text-sm">
                  Select an objective to view initiatives
                </div>
              ) : showInitiativeForm && getCurrentParentInfo() ? (
                <div className="space-y-4">
                  <h4 className="text-sm font-medium text-gray-900">
                    {editingInitiative ? 'Edit Initiative' : 'Create New Initiative'}
                  </h4>
                  <InitiativeForm
                    parentId={getCurrentParentInfo()!.parentId}
                    parentType={getCurrentParentInfo()!.parentType}
                    parentWeight={getCurrentParentInfo()!.parentWeight}
                    currentTotal={0}
                    onSubmit={handleInitiativeSave}
                    initialData={editingInitiative}
                    onCancel={handleCancelInitiativeForm}
                    userOrgId={userOrgId}
                  />
                </div>
              ) : (
                <InitiativesList 
                  selectedObjectiveId={selectedObjectiveId}
                  selectedProgram={selectedProgram}
                  onSelectInitiative={handleSelectInitiative}
                  onEditInitiative={handleEditInitiative}
                  selectedInitiativeId={selectedInitiativeId}
                  userOrgId={userOrgId}
                  refreshKey={refreshKey}
                />
              )}
            </div>

            {/* Column 3: Performance Measures */}
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900 flex items-center">
                  <CheckCircle className="h-5 w-5 text-purple-600 mr-2" />
                  Performance Measures
                </h3>
                {isUserPlanner && selectedInitiativeId && !showMeasureForm && (
                  <button
                    onClick={() => handleCreateMeasure(selectedInitiativeId)}
                    className="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700"
                  >
                    <Plus className="h-3 w-3 mr-1" />
                    Create
                  </button>
                )}
              </div>

              {!selectedInitiativeId ? (
                <div className="text-center p-4 text-gray-500 text-sm">
                  Select an initiative to view performance measures
                </div>
              ) : showMeasureForm && editingMeasure ? (
                <div className="space-y-4">
                  <h4 className="text-sm font-medium text-gray-900">
                    {editingMeasure.id ? 'Edit Performance Measure' : 'Create Performance Measure'}
                  </h4>
                  <PerformanceMeasureForm
                    initiativeId={editingMeasure.initiative}
                    currentTotal={0}
                    onSubmit={handleMeasureSave}
                    initialData={editingMeasure.id ? editingMeasure : null}
                    onCancel={() => {
                      setShowMeasureForm(false);
                      setEditingMeasure(null);
                    }}
                  />
                </div>
              ) : (
                <PerformanceMeasureList
                  initiativeId={selectedInitiativeId}
                  initiativeWeight={100}
                  onEditMeasure={handleEditMeasure}
                  onDeleteMeasure={handleDeleteMeasure}
                />
              )}
            </div>

            {/* Column 4: Main Activities */}
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900 flex items-center">
                  <ArrowRight className="h-5 w-5 text-orange-600 mr-2" />
                  Main Activities
                </h3>
                {isUserPlanner && selectedInitiativeId && !showActivityForm && (
                  <button
                    onClick={() => handleCreateActivity(selectedInitiativeId)}
                    className="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md text-white bg-orange-600 hover:bg-orange-700"
                  >
                    <Plus className="h-3 w-3 mr-1" />
                    Create
                  </button>
                )}
              </div>

              {!selectedInitiativeId ? (
                <div className="text-center p-4 text-gray-500 text-sm">
                  Select an initiative to view main activities
                </div>
              ) : showActivityForm && editingActivity ? (
                <div className="space-y-4">
                  <h4 className="text-sm font-medium text-gray-900">
                    {editingActivity.id ? 'Edit Main Activity' : 'Create Main Activity'}
                  </h4>
                  <MainActivityForm
                    initiativeId={editingActivity.initiative}
                    currentTotal={0}
                    onSubmit={handleActivitySave}
                    initialData={editingActivity.id ? editingActivity : null}
                    onCancel={() => {
                      setShowActivityForm(false);
                      setEditingActivity(null);
                    }}
                  />
                </div>
              ) : (
                <MainActivityList
                  initiativeId={selectedInitiativeId}
                  initiativeWeight={100}
                  onEditActivity={handleEditActivity}
                  onDeleteActivity={handleDeleteActivity}
                  onEditBudget={handleEditBudget}
                  onOpenCostingTool={handleOpenCostingTool}
                />
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-between items-center">
            <button
              onClick={() => setCurrentStep('objectives')}
              className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              Back to Objectives
            </button>

            <div className="flex space-x-3">
              <button
                onClick={handlePreviewPlan}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
              >
                <Eye className="h-4 w-4 mr-2" />
                Preview Plan
              </button>
              
              <button
                onClick={handleSubmitPlan}
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
              >
                <Save className="h-4 w-4 mr-2" />
                Submit Plan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Budget Form Modal */}
      {showBudgetForm && editingBudget && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Activity Budget</h3>
            <ActivityBudgetForm
              activity={editingBudget.activity}
              budgetCalculationType={editingBudget.budgetCalculationType}
              activityType={editingBudget.activityType}
              onSubmit={handleBudgetSave}
              initialData={editingBudget.initialData}
              onCancel={() => {
                setShowBudgetForm(false);
                setEditingBudget(null);
              }}
            />
          </div>
        </div>
      )}

      {/* Costing Tool Modals */}
      {showCostingTool && costingActivity && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            {costingToolType === 'Training' && (
              <TrainingCostingTool
                onCalculate={handleCostingCalculate}
                onCancel={() => {
                  setShowCostingTool(false);
                  setCostingActivity(null);
                  setCostingToolType('');
                }}
                initialData={costingActivity.budget?.training_details}
              />
            )}
            {costingToolType === 'Meeting' && (
              <MeetingWorkshopCostingTool
                onCalculate={handleCostingCalculate}
                onCancel={() => {
                  setShowCostingTool(false);
                  setCostingActivity(null);
                  setCostingToolType('');
                }}
                initialData={costingActivity.budget?.meeting_workshop_details}
              />
            )}
            {costingToolType === 'Workshop' && (
              <MeetingWorkshopCostingTool
                onCalculate={handleCostingCalculate}
                onCancel={() => {
                  setShowCostingTool(false);
                  setCostingActivity(null);
                  setCostingToolType('');
                }}
                initialData={costingActivity.budget?.meeting_workshop_details}
              />
            )}
            {costingToolType === 'Printing' && (
              <PrintingCostingTool
                onCalculate={handleCostingCalculate}
                onCancel={() => {
                  setShowCostingTool(false);
                  setCostingActivity(null);
                  setCostingToolType('');
                }}
                initialData={costingActivity.budget?.printing_details}
              />
            )}
            {costingToolType === 'Procurement' && (
              <ProcurementCostingTool
                onCalculate={handleCostingCalculate}
                onCancel={() => {
                  setShowCostingTool(false);
                  setCostingActivity(null);
                  setCostingToolType('');
                }}
                initialData={costingActivity.budget?.procurement_details}
              />
            )}
            {costingToolType === 'Supervision' && (
              <SupervisionCostingTool
                onCalculate={handleCostingCalculate}
                onCancel={() => {
                  setShowCostingTool(false);
                  setCostingActivity(null);
                  setCostingToolType('');
                }}
                initialData={costingActivity.budget?.supervision_details}
              />
            )}
          </div>
        </div>
      )}

      {/* Plan Preview Modal */}
      {showPreview && (
        <PlanPreviewModal
          isOpen={showPreview}
          onClose={() => setShowPreview(false)}
          objectives={selectedObjectives}
          organizationName={selectedOrganization?.name || ''}
          plannerName={plannerName}
          fromDate={fromDate}
          toDate={toDate}
          planType={planType}
          refreshKey={refreshKey}
        />
      )}

      {/* Plan Submit Modal */}
      {showSubmitForm && selectedOrganization && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <PlanSubmitForm
              plan={{
                id: '',
                organization: selectedOrganization.id.toString(),
                planner_name: plannerName,
                type: planType,
                strategic_objective: selectedObjectives[0]?.id.toString() || '',
                fiscal_year: new Date(fromDate).getFullYear().toString(),
                from_date: fromDate,
                to_date: toDate,
                status: 'DRAFT',
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
              }}
              onSubmit={handlePlanSubmit}
              onCancel={() => setShowSubmitForm(false)}
              isSubmitting={isSubmittingPlan}
            />
          </div>
        </div>
      )}
    </div>
  );
};

// Initiative List Component
interface InitiativesListProps {
  selectedObjectiveId: string | null;
  selectedProgram: Program | null;
  onSelectInitiative: (initiative: StrategicInitiative) => void;
  onEditInitiative: (initiative: StrategicInitiative) => void;
  selectedInitiativeId: string | null;
  userOrgId: number | null;
  refreshKey: number;
  showCreateButton?: boolean;
  isUserPlanner?: boolean;
}

const InitiativesList: React.FC<InitiativesListProps> = ({
  selectedObjectiveId,
  selectedProgram,
  onSelectInitiative,
  onEditInitiative,
  selectedInitiativeId,
  userOrgId,
  refreshKey,
  showCreateButton = true,
  isUserPlanner = false
}) => {
  // Get parent weight for initiatives
  const getParentWeight = () => {
    if (selectedObjectiveId && selectedProgram?.strategic_objective) {
      return selectedProgram.strategic_objective.effective_weight || selectedProgram.strategic_objective.weight;
    }
    // If we don't have program context, assume 100% for calculation
    return 100;
  };

  const { data: initiativesList, isLoading } = useQuery({
    queryKey: ['initiatives', selectedObjectiveId, selectedProgram?.id, refreshKey],
    queryFn: async () => {
      if (selectedObjectiveId) {
        return await initiatives.getByObjective(selectedObjectiveId);
      } else if (selectedProgram) {
        return await initiatives.getByProgram(selectedProgram.id.toString());
      }
      return { data: [] };
    },
    enabled: !!(selectedObjectiveId || selectedProgram),
    staleTime: 0,
    cacheTime: 0
  });

  if (isLoading) {
    return <div className="text-center p-4 text-sm">Loading initiatives...</div>;
  }

  if (!initiativesList?.data || initiativesList.data.length === 0) {
    return (
      <div className="text-center p-4 text-gray-500 text-sm">
        <p className="mb-4">No initiatives found for this {selectedObjectiveId ? 'objective' : 'program'}.</p>
        {showCreateButton && isUserPlanner && (
          <button 
            onClick={() => onEditInitiative({} as StrategicInitiative)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Create First Initiative
          </button>
        )}
      </div>
    );
  }

  // Filter initiatives based on user organization
  const filteredInitiatives = initiativesList.data.filter(initiative => 
    initiative.is_default || 
    !initiative.organization || 
    initiative.organization === userOrgId
  );

  return (
    <div className="space-y-2">
      {filteredInitiatives.map((initiative) => (
        <div
          key={initiative.id}
          onClick={() => onSelectInitiative(initiative)}
          className={`p-3 rounded-lg border cursor-pointer transition-colors ${
            selectedInitiativeId === initiative.id
              ? 'border-green-500 bg-green-50'
              : 'border-gray-200 hover:border-green-300'
          }`}
        >
          <div className="flex justify-between items-start mb-2">
            <h4 className="font-medium text-gray-900 text-sm">{initiative.name}</h4>
            <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
              {initiative.weight}%
            </span>
          </div>
          
          {initiative.organization_name && (
            <p className="text-xs text-gray-500 mb-2">{initiative.organization_name}</p>
          )}
          
          <div className="flex justify-between items-center">
            {selectedInitiativeId === initiative.id && (
              <CheckCircle className="h-4 w-4 text-green-600" />
            )}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onEditInitiative(initiative);
              }}
              className="text-xs text-blue-600 hover:text-blue-800"
            >
              <Edit className="h-3 w-3" />
            </button>
          </div>
        </div>
      ))}

      {/* Add initiative button at bottom */}
      {showCreateButton && isUserPlanner && (
        <div className="mt-4 text-center">
          <button 
            onClick={() => onEditInitiative({} as StrategicInitiative)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Another Initiative
          </button>
        </div>
      )}
    </div>
  );
};

export default Planning;