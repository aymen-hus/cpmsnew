export const formatDataForExport = (objectives: any[]) => {
    const data: any[] = [];
    
    // Check if objectives is an array before iterating
    if (!Array.isArray(objectives)) {
      console.error('objectives is not an array:', objectives);
      return data;
    }
    
    objectives.forEach((objective, objIndex) => {
      if (!objective) return; // Skip null/undefined objectives
      
      const initiatives = Array.isArray(objective.initiatives) ? objective.initiatives : [];
      
      if (initiatives.length === 0) {
        // Add at least one row for the objective
        data.push({
          'No': (objIndex + 1).toString(),
          'Strategic Objective': objective.title || 'Untitled Objective',
          'Initiative': '',
          'Performance Measure/Main Activity': '',
          'Type': '',
          'Weight': `${objective.weight || 0}%`,
          'Baseline': 'N/A',
          'Target': 'N/A',
          'Period': 'N/A',
          'Implementor Team/Desk': 'N/A',
          'Budget': 'N/A'
        });
        return;
      }
      
      initiatives.forEach((initiative: any) => {
        if (!initiative) return; // Skip null/undefined initiatives
        
        const measures = Array.isArray(initiative.performance_measures) ? initiative.performance_measures : [];
        const activities = Array.isArray(initiative.main_activities) ? initiative.main_activities : [];
        
        if (measures.length === 0 && activities.length === 0) {
          // Add a row for an initiative without measures or activities
          data.push({
            'No': (objIndex + 1).toString(),
            'Strategic Objective': objective.title || 'Untitled Objective',
            'Initiative': initiative.name || 'Untitled Initiative',
            'Performance Measure/Main Activity': '',
            'Type': '',
            'Weight': `${initiative.weight || 0}%`,
            'Baseline': 'N/A',
            'Target': 'N/A',
            'Period': 'N/A',
            'Implementor Team/Desk': initiative.organization_name || 'N/A',
            'Budget': 'N/A'
          });
          return;
        }
        
        // Process measures
        measures.forEach((measure: any, measureIndex: number) => {
          if (!measure) return;
          
          data.push({
            'No': measureIndex === 0 ? (objIndex + 1).toString() : '',
            'Strategic Objective': measureIndex === 0 ? objective.title || 'Untitled Objective' : '',
            'Initiative': measureIndex === 0 ? initiative.name : '',
            'Performance Measure/Main Activity': measure.name,
            'Type': 'Performance Measure',
            'Weight': `${measure.weight || 0}%`,
            'Baseline': measure.baseline || 'N/A',
            'Target': {
              annual: measure.annual_target,
              q1: measure.q1_target,
              q2: measure.q2_target,
              q3: measure.q3_target,
              q4: measure.q4_target
            },
            'Period': measure.selected_quarters && measure.selected_quarters.length > 0 
              ? measure.selected_quarters.join(', ')
              : Array.isArray(measure.selected_months) && measure.selected_months.length > 0
                ? measure.selected_months.join(', ') 
                : 'N/A',
            'Implementor Team/Desk': initiative.organization_name || 'N/A',
            'Budget': 'N/A'
          });
        });
      });
    });
    
    return data;
};