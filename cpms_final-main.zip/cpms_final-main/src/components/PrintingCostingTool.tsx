import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Calculator, DollarSign, Info, AlertCircle } from 'lucide-react';
import type { PrintingCost } from '../types/costing';
import { printingCosts } from '../lib/api';

// Fallback data for document types if API fails
const DEFAULT_DOCUMENT_TYPES = [
  { value: 'MANUAL', label: 'Manual/Guidelines', costPerPage: 50 },
  { value: 'BOOKLET', label: 'Booklet', costPerPage: 40 },
  { value: 'LEAFLET', label: 'Leaflet', costPerPage: 30 },
  { value: 'BROCHURE', label: 'Brochure', costPerPage: 35 }
];

interface PrintingCostingToolProps {
  onCalculate: (costs: PrintingCost) => void;
  onCancel: () => void;
  initialData?: PrintingCost;
}

const PrintingCostingTool: React.FC<PrintingCostingToolProps> = ({ 
  onCalculate, 
  onCancel,
  initialData 
}) => {
  const [isCalculating, setIsCalculating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [documentTypes, setDocumentTypes] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [apiBaseUrl, setApiBaseUrl] = useState<string>('');
  
  const { register, watch, setValue, handleSubmit, formState: { errors } } = useForm<PrintingCost>({
    defaultValues: initialData || {
      description: '',
      documentType: 'Manual',
      numberOfPages: 1,
      numberOfCopies: 1,
      otherCosts: 0
    }
  });

  const watchDocumentType = watch('documentType');
  const watchNumberOfPages = watch('numberOfPages');
  const watchNumberOfCopies = watch('numberOfCopies');
  const watchOtherCosts = watch('otherCosts');

  // Get API base URL
  useEffect(() => {
    const apiUrl = import.meta.env.VITE_API_URL || '';
    setApiBaseUrl(apiUrl.endsWith('/') ? apiUrl.slice(0, -1) : apiUrl);
    console.log('API Base URL for printing tool:', apiUrl);
  }, []);

  // Fetch document types from the database
  useEffect(() => {
    const fetchDocumentTypes = async () => {
      try {
        setIsLoading(true);
        console.log('Fetching printing costs data...');
        setError(null);
        
        // Add timestamp to prevent caching
        const timestamp = new Date().getTime();
        const response = await printingCosts.getAll();
        
        console.log('Printing costs response received:', response?.data ? 'yes, with data' : 'no data');
        
        if (!response?.data || !Array.isArray(response.data)) {
          console.error('Invalid printing costs data received in PrintingCostingTool', 
            response?.data ? typeof response.data : 'no data received');
          console.log('Using fallback document types');
          // Use fallback data instead of throwing error
          setDocumentTypes(DEFAULT_DOCUMENT_TYPES);
          setIsLoading(false);
          return;
        }
        
        const printingCostsData = response?.data || [];
        
        // Transform the data into the format we need
        const types = printingCostsData.map(cost => ({
          value: cost.document_type,
          label: cost.document_type_display || cost.document_type,
          costPerPage: Number(cost.price_per_page) || 0
        }));
        
        setDocumentTypes(types);
        
        // Set default document type if available
        if (types.length > 0 && !initialData?.documentType) {
          setValue('documentType', types[0].value);
        }
      } catch (error) {
        console.error('Failed to fetch printing costs data:', error, 
          error.response?.data || 'No response data');
        console.error('API URL used:', apiBaseUrl || 'Not defined');
        
        // More detailed error message
        let errorMessage = 'Failed to load document types from database. ';
        if (error.response) {
          errorMessage += `Server responded with status ${error.response.status}.`;
        } else if (error.request) {
          errorMessage += 'No response received from server.';
        } else {
          errorMessage += error.message || 'Unknown error occurred.';
        }
        setError(errorMessage);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchDocumentTypes();
  }, [setValue, initialData]);

  useEffect(() => {
    const calculateTotalBudget = () => {
      // Get cost per page based on document type
      const documentConfig = documentTypes.find(doc => doc.value === watchDocumentType);
      const costPerPage = documentConfig?.costPerPage || 50; // Default to 50 if not found
      
      // Calculate printing cost
      const printingCost = costPerPage * (watchNumberOfPages || 0) * (watchNumberOfCopies || 0);
      
      // Add other costs
      const otherCostsTotal = watchOtherCosts || 0;
      
      // Calculate total
      const total = printingCost + otherCostsTotal;
      
      setValue('totalBudget', total);
      return total;
    };

    calculateTotalBudget();
  }, [watchDocumentType, watchNumberOfPages, watchNumberOfCopies, watchOtherCosts, setValue, documentTypes]);

  const handleFormSubmit = async (data: PrintingCost) => {
    try {
      setIsCalculating(true);
      setError(null);
      
      // Make sure we have a valid budget amount
      const calculatedBudget = watch('totalBudget') || 0;
      
      console.log('Printing calculated budget:', calculatedBudget);
      
      if (!calculatedBudget || calculatedBudget <= 0) {
        setError('Total budget must be greater than 0');
        return;
      }
      
      // Prepare streamlined data for the budget form
      const budgetData = {
        activity: data.activity,
        budget_calculation_type: 'WITH_TOOL',
        activity_type: 'Printing', // Explicitly set type
        estimated_cost_with_tool: calculatedBudget || 0,
        totalBudget: calculatedBudget || 0, // Add totalBudget for consistency
        estimated_cost: calculatedBudget || 0, // Add estimated_cost for consistency
        estimated_cost_without_tool: 0, // Not used since we're using the tool
        government_treasury: 0,
        sdg_funding: 0,
        partners_funding: 0,
        other_funding: 0,
        printing_details: {
          description: data.description,
          documentType: data.documentType,
          numberOfPages: Number(data.numberOfPages) || 0,
          numberOfCopies: Number(data.numberOfCopies) || 0,
          otherCosts: Number(data.otherCosts) || 0,
          justification: data.justification
        }
      };
      
      // Pass the prepared budget data to the parent component
      onCalculate(budgetData);
    } catch (err: any) {
      console.error('Failed to process printing costs:', err);
      setError(err.message || 'Failed to process printing costs. Please try again.');
    } finally {
      setIsCalculating(false);
    }
  };

  // Show loading state while fetching data
  if (isLoading) {
    return <div className="flex flex-col items-center justify-center p-8">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mb-4"></div>
      <p className="text-gray-700">Loading document types from database...</p>
    </div>;
  }

  // If no document types are available, show an error
  if ((!documentTypes || documentTypes.length === 0) && !isLoading) {
    return <div className="p-6 bg-red-50 border border-red-200 rounded-lg">
      <div className="flex items-center text-red-500 mb-2">
        <AlertCircle className="h-6 w-6 mr-2 flex-shrink-0" />
        <h3 className="text-lg font-medium text-red-800">Document types not available</h3>
      </div>
      <p className="text-red-600 mb-4">Could not load document types from the database. The system will use default values.</p>
      <p className="text-sm text-red-600 mb-2">
        {error ? `Error details: ${error}` : "Using default document types instead."}
      </p>
      <button
        onClick={() => {
          // Set default document types and continue
          setDocumentTypes(DEFAULT_DOCUMENT_TYPES);
          setIsLoading(false);
        }}
        className="px-4 py-2 mb-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 mr-2"
      >
        Use Default Types
      </button>
      <button 
        onClick={onCancel} 
        className="mt-4 px-4 py-2 bg-white border border-red-300 rounded-md text-red-700 hover:bg-red-50"
      >
        Go Back
      </button>
    </div>;
  }

  return (
    <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6 max-h-[75vh] overflow-y-auto p-2 pb-20">
      <div className="flex items-center justify-between">
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 flex-1">
          <h3 className="text-lg font-medium text-blue-800 mb-2 flex items-center">
            <Calculator className="h-5 w-5 mr-2" />
            Printing Cost Calculator
          </h3>
          <p className="text-sm text-blue-600">
            Fill in the printing details below to calculate the total budget.
          </p>
        </div>
        <button
          type="button"
          onClick={onCancel}
          className="ml-4 p-2 text-gray-400 hover:text-gray-500"
        >
          <span className="sr-only">Cancel</span>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-md flex items-center gap-2">
          <AlertCircle className="h-5 w-5 text-red-500" />
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Description of Printing Activity
        </label>
        <textarea
          {...register('description', { required: 'Description is required' })}
          rows={3}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          placeholder="Describe what will be printed..."
        />
        {errors.description && (
          <p className="mt-1 text-sm text-red-600">{errors.description.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Document Type
        </label>
        <select
          {...register('documentType', { required: 'Document type is required' })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        >
          {documentTypes.map(type => (
            <option key={type.value} value={type.value}>
              {type.label} (ETB {type.costPerPage.toLocaleString()}/page)
            </option>
          ))}
        </select>
        {errors.documentType && (
          <p className="mt-1 text-sm text-red-600">{errors.documentType.message}</p>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Number of Pages
          </label>
          <input
            type="number"
            min="1"
            {...register('numberOfPages', {
              required: 'Number of pages is required',
              min: { value: 1, message: 'Minimum 1 page required' },
              valueAsNumber: true
            })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
          {errors.numberOfPages && (
            <p className="mt-1 text-sm text-red-600">{errors.numberOfPages.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Number of Copies
          </label>
          <input
            type="number"
            min="1"
            {...register('numberOfCopies', {
              required: 'Number of copies is required',
              min: { value: 1, message: 'Minimum 1 copy required' },
              valueAsNumber: true
            })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
          {errors.numberOfCopies && (
            <p className="mt-1 text-sm text-red-600">{errors.numberOfCopies.message}</p>
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Other Costs (ETB)
        </label>
        <input
          type="number"
          min="0"
          {...register('otherCosts', {
            min: { value: 0, message: 'Cannot be negative' },
            valueAsNumber: true
          })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          placeholder="0"
        />
        {errors.otherCosts && (
          <p className="mt-1 text-sm text-red-600">{errors.otherCosts.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Justification for Additional Costs
        </label>
        <textarea
          {...register('justification')}
          rows={3}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          placeholder="Explain any additional costs..."
        />
      </div>

      <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <DollarSign className="h-5 w-5 text-green-600 mr-1 flex-shrink-0" />
            <span className="text-lg font-medium text-gray-900">Total Printing Budget</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-green-600">
              ETB {watch('totalBudget')?.toLocaleString() || '0'}
            </span>
          </div>
        </div>
        <p className="mt-2 text-sm text-gray-500 flex items-center">
          <Info className="h-4 w-4 mr-1" />
          This total is calculated based on the document type, number of pages, copies, and standard rates
        </p>
      </div>
      
      <div className="flex justify-end space-x-2 sticky bottom-0 left-0 right-0 bg-white py-4 px-2 border-t border-gray-200 shadow-md z-10">
        <button
          type="button"
          onClick={onCancel}
          disabled={isCalculating}
          className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={isCalculating}
          className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 flex items-center"
        >
          {isCalculating ? (
            <>
              <span className="inline-block h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
              Processing...
            </>
          ) : (
            'Apply and Continue to Funding Sources'
          )}
        </button>
      </div>
    </form>
  );
};

export default PrintingCostingTool;