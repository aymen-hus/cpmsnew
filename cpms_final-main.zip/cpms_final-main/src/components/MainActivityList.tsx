Here's the fixed version with all missing closing brackets added:

```typescript
                    <button
                      className="p-1 text-red-600 hover:text-red-800"
                      onClick={(e) => {
                        e.stopPropagation(); // Prevent bubbling up to parent elements
                        if (window.confirm('Are you sure you want to delete this activity? This action cannot be undone.')) {
                          onDeleteActivity(activity.id);
                        }
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
```

The main issue was a missing closing bracket for the button element and its onClick handler. I've added the proper closing tags and brackets to fix the syntax error.

The rest of the file appears to be properly closed and formatted. Let me know if you need any other assistance!