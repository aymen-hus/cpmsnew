#!/bin/bash

# This script generates a detailed error report for debugging purposes
echo "Generating error report for MOH Planning application..."
REPORT_FILE="moh-planning-error-report-$(date +%Y%m%d-%H%M%S).txt"

{
    echo "=== MOH Planning Error Report ==="
    echo "Generated: $(date)"
    echo "Hostname: $(hostname)"
    echo ""

    echo "=== System Information ==="
    echo "Operating System: $(cat /etc/os-release | grep PRETTY_NAME | cut -d= -f2 | tr -d '"')"
    echo "Kernel: $(uname -r)"
    echo "Architecture: $(uname -m)"
    echo ""

    echo "=== Service Status ==="
    echo "Nginx Status:"
    systemctl status nginx --no-pager || echo "Failed to get Nginx status"
    echo ""
    
    echo "MOH Planning Status:"
    systemctl status moh-planning --no-pager || echo "Failed to get MOH Planning status"
    echo ""

    echo "=== Network Status ==="
    echo "Listening ports:"
    ss -tulpn | grep -E ':80|:8000' || echo "No relevant ports found"
    echo ""
    
    echo "Connection test to backend:"
    curl -s -I http://localhost:8000/api/auth/check/ || echo "Failed to connect to backend"
    echo ""

    echo "=== Configuration Files ==="
    echo "Nginx configuration:"
    if [ -f /etc/nginx/sites-available/moh-planning ]; then
        cat /etc/nginx/sites-available/moh-planning
    else
        echo "File not found"
    fi
    echo ""
    
    echo "Gunicorn configuration:"
    if [ -f /var/www/moh-planning/gunicorn.conf.py ]; then
        cat /var/www/moh-planning/gunicorn.conf.py
    else
        echo "File not found"
    fi
    echo ""
    
    echo ".env file (sensitive info redacted):"
    if [ -f /var/www/moh-planning/.env ]; then
        grep -v "SECRET|PASSWORD" /var/www/moh-planning/.env || echo "No env file found"
    else
        echo "File not found"
    fi
    echo ""

    echo "=== Log Files ==="
    echo "Nginx error log (last 50 lines):"
    tail -n 50 /var/log/nginx/moh-planning-error.log 2>/dev/null || echo "File not found"
    echo ""
    
    echo "Gunicorn error log (last 50 lines):"
    tail -n 50 /var/www/moh-planning/logs/gunicorn-error.log 2>/dev/null || echo "File not found"
    echo ""
    
    echo "Django log (last 50 lines):"
    tail -n 50 /var/www/moh-planning/logs/django.log 2>/dev/null || echo "File not found"
    echo ""

    echo "=== Directory Structure ==="
    echo "Static files:"
    find /var/www/moh-planning/staticfiles -type f -name "*.css" | wc -l || echo "Failed to check static files"
    echo ""
    
    echo "Frontend files:"
    find /var/www/moh-planning/dist -type f -name "*.js" | wc -l || echo "Failed to check frontend files"
    echo ""
    
    echo "=== File Permissions ==="
    echo "Directory permissions:"
    ls -ld /var/www/moh-planning /var/www/moh-planning/staticfiles /var/www/moh-planning/dist /var/www/moh-planning/media 2>/dev/null || echo "Failed to check permissions"
    echo ""
    
    echo "=== End of Report ==="

} > "$REPORT_FILE"

echo "Error report generated: $REPORT_FILE"
echo "Please provide this file to your system administrator for troubleshooting."