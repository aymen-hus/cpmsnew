#!/bin/bash
set -e

echo "=== Checking Development Settings That May Cause Production Errors ==="

# Check CSRF settings in Django settings
echo "Checking CSRF settings in Django settings.py..."
grep -n "CSRF_" core/settings.py
echo ""

# Check for CORS settings
echo "Checking CORS settings..."
grep -n "CORS_" core/settings.py
echo ""

# Check security headers
echo "Checking security headers..."
grep -n "SECURE_" core/settings.py
echo ""

# Check ALLOWED_HOSTS
echo "Checking ALLOWED_HOSTS..."
grep -n "ALLOWED_HOSTS" core/settings.py
echo ""

# Check API URL configuration
echo "Checking API URL configuration..."
grep -n "VITE_API_URL" .env
grep -n "VITE_API_URL" .env.production
echo ""

# Check frontend API configuration
echo "Checking frontend API configuration..."
grep -n "api =" src/lib/api.ts
echo ""

# Check if CSRF token is being included in API requests
echo "Checking if CSRF token is being included in API requests..."
grep -n "X-CSRFToken" src/lib/api.ts
echo ""

# Check if cookie settings are configured properly
echo "Checking if cookie settings are properly configured..."
grep -n "withCredentials" src/lib/api.ts
echo ""

# Check the auth module's CSRF handling
echo "Checking auth module's CSRF handling..."
grep -n "csrftoken" src/lib/api.ts
echo ""

echo "=== Diagnosis Complete ==="
echo ""
echo "Common issues that could cause problems in production:"
echo "1. CSRF_TRUSTED_ORIGINS not including the production domain/IP"
echo "2. Missing withCredentials: true in API requests"
echo "3. Not properly handling CSRF tokens in the frontend"
echo "4. Security headers causing issues when using HTTP instead of HTTPS"
echo ""
echo "To fix these issues:"
echo "- Make sure CSRF_TRUSTED_ORIGINS includes your production domain/IP"
echo "- Ensure API requests use withCredentials: true"
echo "- Verify CSRF tokens are properly included in POST requests"
echo "- Consider disabling SECURE_* headers for HTTP if using plain HTTP"