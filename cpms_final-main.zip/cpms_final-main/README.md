# MOH Planning and Reporting App - Apache Deployment

This document describes how to deploy the Ministry of Health Planning and Reporting application using Apache.

## Deployment Components

The application consists of:

1. **Frontend**: React application (built with Vite)
2. **Backend**: Django REST API
3. **Web Server**: Apache with mod_wsgi

## Directory Structure

- `/var/www/moh-planning/` - Main application directory
  - `dist/` - Built React frontend
  - `staticfiles/` - Collected Django static files
  - `media/` - User uploaded files
  - `logs/` - Application logs
  - `venv/` - Python virtual environment

## Apache Setup

To set up the application with Apache:

```bash
# Run the setup script
sudo ./setup-apache.sh
```

This will:
1. Install Apache and mod_wsgi
2. Configure Apache to serve the application
3. Set up the required directories and permissions
4. Enable the site configuration
5. Restart Apache

## Manual Configuration Steps

If you prefer to set up manually:

1. Install required packages:
```bash
sudo apt-get update
sudo apt-get install -y apache2 libapache2-mod-wsgi-py3
```

2. Enable required modules:
```bash
sudo a2enmod wsgi
sudo a2enmod rewrite
```

3. Copy configuration:
```bash
sudo cp moh-planning-apache.conf /etc/apache2/sites-available/moh-planning.conf
sudo a2ensite moh-planning.conf
```

4. Test and restart:
```bash
sudo apache2ctl configtest
sudo systemctl restart apache2
```

## Troubleshooting

If you encounter issues:

1. Check Apache error logs:
```bash
sudo tail -f /var/log/apache2/moh-planning-error.log
```

2. Check Apache configuration:
```bash
sudo apache2ctl configtest
```

3. Verify permissions:
```bash
sudo ls -la /var/www/moh-planning/dist
sudo ls -la /var/www/moh-planning/staticfiles
```

4. Restart Apache:
```bash
sudo systemctl restart apache2
```