#!/bin/bash
set -e

echo "=== Fixing Nginx Configuration ==="

# Create backup of existing config
if [ -f /etc/nginx/sites-available/moh-planning ]; then
    sudo cp /etc/nginx/sites-available/moh-planning /etc/nginx/sites-available/moh-planning.backup
    echo "Created backup of current config at /etc/nginx/sites-available/moh-planning.backup"
fi

# Copy fixed configuration
echo "Updating Nginx configuration..."
sudo cp fixed-nginx.conf /etc/nginx/sites-available/moh-planning

# Make sure the symlink exists
if [ ! -f /etc/nginx/sites-enabled/moh-planning ]; then
    sudo ln -s /etc/nginx/sites-available/moh-planning /etc/nginx/sites-enabled/
    echo "Created symlink for Nginx configuration"
else
    echo "Symlink already exists"
fi

# Remove default site if it exists
if [ -f /etc/nginx/sites-enabled/default ]; then
    sudo rm /etc/nginx/sites-enabled/default
    echo "Removed default site configuration"
fi

# Test Nginx configuration
echo "Testing Nginx configuration..."
sudo nginx -t

# Reload Nginx (gentler than restart)
echo "Reloading Nginx..."
sudo systemctl reload nginx

echo "=== Configuration update completed ==="
echo "Check if the error is resolved by accessing your server."
echo "If you still have issues, check the error logs:"
echo "  sudo tail -f /var/log/nginx/error.log"
echo "  sudo tail -f /var/log/nginx/moh-planning-error.log"