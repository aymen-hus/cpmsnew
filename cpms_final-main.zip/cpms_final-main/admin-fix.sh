#!/bin/bash
set -e

echo "Fixing Django Admin 504 Gateway Timeout..."

# Ensure the logs directory exists
sudo mkdir -p /var/www/moh-planning/logs
sudo chown -R www-data:www-data /var/www/moh-planning/logs

# Apply the new nginx and gunicorn configs
sudo cp moh-planning.nginx.conf /etc/nginx/sites-available/moh-planning
sudo cp gunicorn.conf.py /var/www/moh-planning/

# Test nginx configuration
echo "Testing Nginx configuration..."
sudo nginx -t

# Restart services with new timeout settings
echo "Restarting services with new timeout settings..."
sudo systemctl restart moh-planning
sudo systemctl restart nginx

# Check if services are running
echo "Checking service status..."
sudo systemctl status moh-planning --no-pager
sudo systemctl status nginx --no-pager

echo "Done! Django admin should now have increased timeout settings."
echo "Try accessing the admin again. If issues persist, check logs with:"
echo "  sudo tail -f /var/www/moh-planning/logs/gunicorn-error.log"
echo "  sudo tail -f /var/log/nginx/moh-planning-error.log"