// CommonJS build script for older Node.js versions
const { execSync } = require('child_process');

try {
  console.log('Building project using compatibility script...');
  console.log('Running Vite build via npx...');
  
  // Use npx to run Vite build command
  execSync('npx --yes vite build', { stdio: 'inherit' });
  
  console.log('Build completed successfully!');
} catch (error) {
  console.error('Build failed:', error.message);
  process.exit(1);
}