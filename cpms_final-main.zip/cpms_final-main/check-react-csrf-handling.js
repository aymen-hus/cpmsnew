// Run this in browser console to test CSRF handling
console.log('Testing CSRF handling in the frontend...');

// Check if CSRF cookie exists
const hasCsrfCookie = document.cookie.includes('csrftoken');
console.log('CSRF cookie exists:', hasCsrfCookie);

if (hasCsrfCookie) {
  const csrfCookie = document.cookie
    .split('; ')
    .find(cookie => cookie.startsWith('csrftoken='));
  
  if (csrfCookie) {
    const csrfToken = csrfCookie.split('=')[1];
    console.log('CSRF token:', csrfToken.substring(0, 10) + '...');
  }
}

// Check axios configuration
if (window.axios) {
  console.log('Axios default config:', window.axios.defaults);
} else {
  console.log('Axios not found in global scope');
}

// Test CSRF fetch
console.log('Fetching CSRF token...');
fetch('/api/auth/csrf/', { 
  credentials: 'include'
})
.then(response => {
  console.log('CSRF Response status:', response.status);
  console.log('CSRF Response headers:', response.headers);
  return response.json();
})
.then(data => {
  console.log('CSRF Response data:', data);
})
.catch(error => {
  console.error('CSRF fetch error:', error);
});

console.log('When running in production, check the Network tab in DevTools');
console.log('Look for 400 status codes and examine request/response headers');