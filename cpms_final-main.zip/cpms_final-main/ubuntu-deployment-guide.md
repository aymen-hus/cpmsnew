# MOH Planning Application - Complete Ubuntu VPS Deployment Guide

This guide provides detailed, step-by-step instructions for deploying the Ministry of Health Planning application on an Ubuntu VPS using Nginx, Gunicorn, and MySQL.

## 1. Initial Server Setup

### 1.1 Update System Packages

```bash
sudo apt update
sudo apt upgrade -y
```

### 1.2 Install Required System Packages

```bash
sudo apt install -y python3 python3-pip python3-dev python3-venv nginx mysql-server libmysqlclient-dev build-essential git curl wget unzip
```

### 1.3 Configure Firewall

```bash
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw enable
```

## 2. Set Up MySQL Database

### 2.1 Secure MySQL Installation

```bash
sudo mysql_secure_installation
```

Follow the prompts to set the root password and secure your MySQL installation.

### 2.2 Create Database and User

```bash
sudo mysql -u root -p
```

In the MySQL shell, execute:

```sql
CREATE DATABASE organization_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'moh_user'@'localhost' IDENTIFIED BY 'your_secure_password';
GRANT ALL PRIVILEGES ON organization_db.* TO 'moh_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

## 3. Deploy Application Files

### 3.1 Create Application Directory

```bash
sudo mkdir -p /var/www/moh-planning
sudo chown $USER:$USER /var/www/moh-planning
```

### 3.2 Clone or Upload Project Files

Option 1: If using Git:
```bash
cd /var/www/moh-planning
git clone https://your-repository-url.git .
```

Option 2: If uploading manually, use SCP or SFTP to transfer files to `/var/www/moh-planning`

### 3.3 Create Required Directories

```bash
mkdir -p /var/www/moh-planning/logs
mkdir -p /var/www/moh-planning/staticfiles
mkdir -p /var/www/moh-planning/media
```

## 4. Set Up Python Environment

### 4.1 Create Virtual Environment

```bash
cd /var/www/moh-planning
python3 -m venv venv
source venv/bin/activate
```

### 4.2 Install Python Dependencies

```bash
pip install --upgrade pip
pip install -r requirements.production.txt
```

## 5. Configure the Application

### 5.1 Create Environment File

```bash
cp .env.production /var/www/moh-planning/.env
```

Then edit the file:

```bash
nano /var/www/moh-planning/.env
```

Update with your production settings:

```ini
DEBUG=False
DJANGO_SECRET_KEY=your-secure-secret-key-here
ALLOWED_HOSTS=localhost,127.0.0.1,your-server-ip,your-domain.com

# Database configuration
DB_NAME=organization_db
DB_USER=moh_user
DB_PASSWORD=your_secure_password
DB_HOST=localhost
DB_PORT=3306

# Security settings
CSRF_COOKIE_SECURE=False
SESSION_COOKIE_SECURE=False
CSRF_COOKIE_HTTPONLY=False
SESSION_COOKIE_HTTPONLY=True
CSRF_TRUSTED_ORIGINS=http://your-server-ip,http://your-domain.com

# Static files
STATIC_URL=/static/
STATIC_ROOT=/var/www/moh-planning/staticfiles
```

### 5.2 Create Gunicorn Configuration File

```bash
nano /var/www/moh-planning/gunicorn.conf.py
```

Copy the contents:

```python
# Gunicorn configuration file
import multiprocessing
import os

# Bind to localhost only (Nginx will proxy requests)
bind = "127.0.0.1:8000"

# Number of worker processes (2-4 x number of CPU cores)
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = "sync"

# Timeouts - increase for admin pages
timeout = 300

# Logging
log_dir = "/var/www/moh-planning/logs"
# Create logs directory if it doesn't exist
if not os.path.exists(log_dir):
    try:
        os.makedirs(log_dir)
    except:
        pass

accesslog = f"{log_dir}/gunicorn-access.log"
errorlog = f"{log_dir}/gunicorn-error.log"
loglevel = "debug"  # Increase log level for troubleshooting
capture_output = True  # Ensure all app output is captured

# Security and performance
max_requests = 1000
max_requests_jitter = 50
keepalive = 2

# Improve worker process name
proc_name = "moh-planning"

# Set low keep-alive to prevent long-running connections
keepalive = 2
```

## 6. Setup Node.js and Build Frontend

### 6.1 Install Node.js

```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### 6.2 Install NPM Dependencies and Build the Frontend

```bash
cd /var/www/moh-planning
npm ci
npm run build
```

## 7. Configure Django

### 7.1 Apply Database Migrations

```bash
cd /var/www/moh-planning
source venv/bin/activate
python manage.py migrate
```

### 7.2 Collect Static Files

```bash
python manage.py collectstatic --noinput
```

### 7.3 Create a Superuser (Admin)

```bash
python manage.py createsuperuser
```

## 8. Configure Systemd for Process Management

### 8.1 Create Systemd Service File

```bash
sudo nano /etc/systemd/system/moh-planning.service
```

Copy the content:

```ini
[Unit]
Description=Ministry of Health Planning and Reporting Application
After=network.target mysql.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/moh-planning
Environment="PATH=/var/www/moh-planning/venv/bin:/usr/local/bin:/usr/bin:/bin"
Environment="DJANGO_SETTINGS_MODULE=core.production"
Environment="DEBUG=False"
Environment="ALLOWED_HOSTS=localhost,127.0.0.1,your-server-ip,your-domain.com"

# Explicitly set CSRF trusted origins
Environment="CSRF_TRUSTED_ORIGINS=http://localhost:5173,http://localhost:4173,http://your-server-ip,http://your-domain.com"

# Add more debug info to logs
ExecStart=/var/www/moh-planning/venv/bin/gunicorn core.wsgi:application --config=/var/www/moh-planning/gunicorn.conf.py
Restart=always
RestartSec=5s
StartLimitIntervalSec=0

# Give time for gunicorn to start properly
TimeoutStartSec=60s

[Install]
WantedBy=multi-user.target
```

Replace `your-server-ip` and `your-domain.com` with your actual server IP and domain name.

### 8.2 Set Permissions

```bash
sudo chown -R www-data:www-data /var/www/moh-planning
sudo chmod -R 755 /var/www/moh-planning/staticfiles
sudo chmod -R 755 /var/www/moh-planning/media
sudo chmod 664 /var/www/moh-planning/.env
```

### 8.3 Enable and Start Service

```bash
sudo systemctl daemon-reload
sudo systemctl enable moh-planning
sudo systemctl start moh-planning
```

## 9. Configure Nginx

### 9.1 Create Nginx Server Configuration

```bash
sudo nano /etc/nginx/sites-available/moh-planning
```

Add the following configuration:

```nginx
server {
    listen 80;
    server_name your-server-ip your-domain.com;

    # Logs
    access_log /var/log/nginx/moh-planning-access.log;
    error_log /var/log/nginx/moh-planning-error.log error;

    # Static files with improved caching
    location /static/ {
        alias /var/www/moh-planning/staticfiles/;
        expires 30d;
        add_header Cache-Control "public, max-age=2592000";
        try_files $uri $uri/ =404;
        access_log off;
    }

    # Media files
    location /media/ {
        alias /var/www/moh-planning/media/;
        expires 30d;
        add_header Cache-Control "public, max-age=2592000";
        access_log off;
    }

    # Django admin with extended timeout
    location /admin/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Extended timeout for admin
        proxy_connect_timeout 300s;
        proxy_send_timeout 300s;
        proxy_read_timeout 300s;
        
        # Increased buffer size for admin responses
        proxy_buffer_size 16k;
        proxy_buffers 8 16k;
        proxy_busy_buffers_size 32k;
    }
    
    # Django API
    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 120s;
        
        # CORS headers
        add_header 'Access-Control-Allow-Origin' '*' always;
        add_header 'Access-Control-Allow-Methods' 'GET, POST, PUT, DELETE, OPTIONS' always;
        add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization,X-CSRFToken' always;
        
        # Handle OPTIONS requests for CORS preflight
        if ($request_method = 'OPTIONS') {
            add_header 'Access-Control-Allow-Origin' '*';
            add_header 'Access-Control-Allow-Methods' 'GET, POST, PUT, DELETE, OPTIONS';
            add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization,X-CSRFToken';
            add_header 'Access-Control-Max-Age' 1728000;
            add_header 'Content-Type' 'text/plain; charset=utf-8';
            add_header 'Content-Length' 0;
            return 204;
        }
        
        # Buffering settings
        proxy_buffer_size 16k;
        proxy_buffers 8 16k;
    }

    # Frontend React app and catch-all
    location / {
        root /var/www/moh-planning/dist;
        try_files $uri $uri/ /index.html;
        expires 1h;
    }
    
    # Increase max request size
    client_max_body_size 10M;
    
    # Error pages
    error_page 500 502 503 504 /500.html;
    location = /500.html {
        root /var/www/moh-planning/dist;
        internal;
    }
}
```

Replace `your-server-ip` and `your-domain.com` with your actual server IP and domain name.

### 9.2 Enable the Nginx Configuration

```bash
sudo ln -sf /etc/nginx/sites-available/moh-planning /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default  # Remove default site if it exists
sudo nginx -t  # Test nginx configuration
sudo systemctl restart nginx
```

## 10. Secure Your Application

### 10.1 Configure Custom Error Pages

Copy the 500.html file:

```bash
cp /var/www/moh-planning/500.html /var/www/moh-planning/dist/
cp /var/www/moh-planning/502.html /var/www/moh-planning/dist/
```

### 10.2 Set Proper Permissions Again (Final Check)

```bash
sudo chown -R www-data:www-data /var/www/moh-planning
sudo chmod -R 755 /var/www/moh-planning/staticfiles
sudo chmod -R 755 /var/www/moh-planning/media
sudo chmod -R 755 /var/www/moh-planning/dist
sudo chmod 664 /var/www/moh-planning/.env
```

## 11. Verify the Deployment

### 11.1 Check Service Status

```bash
sudo systemctl status moh-planning
sudo systemctl status nginx
```

### 11.2 Test API Connection

```bash
curl http://localhost:8000/api/auth/check/
curl -I http://localhost/api/auth/check/
```

### 11.3 View Application Logs

```bash
sudo tail -f /var/www/moh-planning/logs/gunicorn-error.log
sudo tail -f /var/log/nginx/moh-planning-error.log
```

## 12. Troubleshooting Common Issues

### 12.1 CSRF Issues

If you encounter CSRF issues, verify the `CSRF_TRUSTED_ORIGINS` setting:

```bash
sudo nano /var/www/moh-planning/.env
```

Make sure it includes your domain and server IP:
```
CSRF_TRUSTED_ORIGINS=http://your-server-ip,http://your-domain.com
```

Restart the application:
```bash
sudo systemctl restart moh-planning
```

### 12.2 Static Files Not Loading

Run the following to check static file permissions:

```bash
sudo find /var/www/moh-planning/staticfiles -type d -not -perm 755 -exec chmod 755 {} \;
sudo find /var/www/moh-planning/staticfiles -type f -not -perm 644 -exec chmod 644 {} \;
```

Re-collect static files:
```bash
cd /var/www/moh-planning
source venv/bin/activate
python manage.py collectstatic --noinput
```

### 12.3 502 Bad Gateway or 504 Gateway Timeout

If you encounter these errors, check the Gunicorn logs:

```bash
sudo tail -f /var/www/moh-planning/logs/gunicorn-error.log
```

Try increasing timeout settings in both Nginx and Gunicorn configurations.

### 12.4 500 Internal Server Error

Check Django logs for exceptions:

```bash
sudo tail -f /var/www/moh-planning/logs/django.log
```

Make sure your server IP is included in `ALLOWED_HOSTS` in the `.env` file.

### 12.5 Connection Refused

If the backend can't be reached, check if Gunicorn is running:

```bash
ps aux | grep gunicorn
```

If it's not running, check the systemd logs:

```bash
sudo journalctl -u moh-planning -n 50
```

## 13. Performance Tuning

### 13.1 Optimize Gunicorn Settings

Adjust the number of workers in `gunicorn.conf.py` based on your server's available memory and CPU cores.

### 13.2 Enable Nginx Caching

For better performance, add caching to the Nginx configuration:

```nginx
# Add to the server block
proxy_cache_path /var/cache/nginx levels=1:2 keys_zone=moh_cache:10m max_size=500m inactive=60m;

# Add to static files location
location /static/ {
    proxy_cache moh_cache;
    proxy_cache_valid 200 60m;
    # ...existing configuration...
}
```

### 13.3 Database Optimization

Optimize MySQL for better performance:

```bash
sudo nano /etc/mysql/mysql.conf.d/mysqld.cnf
```

Add the following under `[mysqld]`:

```ini
innodb_buffer_pool_size = 256M
innodb_log_file_size = 64M
innodb_flush_log_at_trx_commit = 2
```

Restart MySQL:

```bash
sudo systemctl restart mysql
```

## 14. Setup Automatic Backups

### 14.1 Create Backup Script

```bash
sudo nano /var/www/moh-planning/backup.sh
```

Add the following:

```bash
#!/bin/bash

# Configuration
BACKUP_DIR="/var/backups/moh-planning"
MYSQL_USER="moh_user"
MYSQL_PASS="your_secure_password"
DB_NAME="organization_db"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# Create backup directory if it doesn't exist
mkdir -p $BACKUP_DIR

# Backup the database
mysqldump -u $MYSQL_USER -p$MYSQL_PASS $DB_NAME | gzip > "$BACKUP_DIR/db_backup_$TIMESTAMP.sql.gz"

# Backup application files
tar -zcf "$BACKUP_DIR/app_backup_$TIMESTAMP.tar.gz" -C /var/www moh-planning --exclude="moh-planning/venv" --exclude="moh-planning/node_modules"

# Remove backups older than 7 days
find $BACKUP_DIR -name "db_backup_*" -mtime +7 -delete
find $BACKUP_DIR -name "app_backup_*" -mtime +7 -delete

echo "Backup completed at $TIMESTAMP"
```

Make it executable:

```bash
sudo chmod +x /var/www/moh-planning/backup.sh
```

### 14.2 Set Up Cron Job for Regular Backups

```bash
sudo crontab -e
```

Add the following line to run backups daily at 2 AM:

```
0 2 * * * /var/www/moh-planning/backup.sh >> /var/log/moh-planning-backup.log 2>&1
```

## 15. Setting Up HTTPS with Let's Encrypt (Optional)

### 15.1 Install Certbot

```bash
sudo apt install -y certbot python3-certbot-nginx
```

### 15.2 Obtain and Install Certificate

```bash
sudo certbot --nginx -d your-domain.com
```

Follow the prompts to complete the setup. Certbot will automatically modify your Nginx configuration.

## 16. Monitoring and Maintenance

### 16.1 Install and Set Up Monitoring Tools

```bash
sudo apt install -y htop iotop iftop
```

### 16.2 Set Up Log Rotation

Create a log rotation configuration:

```bash
sudo nano /etc/logrotate.d/moh-planning
```

Add the following:

```
/var/www/moh-planning/logs/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 www-data www-data
    sharedscripts
    postrotate
        systemctl reload moh-planning
    endscript
}
```

## 17. Final Deployment Verification Checklist

After completing all the steps above, run through this checklist:

- [ ] Frontend loads correctly (http://your-domain.com)
- [ ] Login functionality works
- [ ] Admin interface is accessible (http://your-domain.com/admin/)
- [ ] API endpoints are accessible (http://your-domain.com/api/auth/check/)
- [ ] Static files (CSS/JS) load correctly
- [ ] All services are running (`systemctl status moh-planning nginx mysql`)
- [ ] Error pages display correctly (500.html, 502.html)
- [ ] Database migrations have been applied
- [ ] CSRF works correctly for form submissions

## Conclusion

Your MOH Planning application should now be successfully deployed on your Ubuntu VPS with Nginx. If you encounter any issues, refer to the troubleshooting section or check the application logs for more specific error information.