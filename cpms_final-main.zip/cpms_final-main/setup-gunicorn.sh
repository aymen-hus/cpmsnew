#!/bin/bash
set -e

echo "Setting up Gunicorn with IP 196.190.255.168..."

# Create necessary directories
sudo mkdir -p /var/www/moh-planning/logs
sudo mkdir -p /var/www/moh-planning/staticfiles
sudo mkdir -p /var/www/moh-planning/media

# Copy configuration files
sudo cp gunicorn.conf.py /var/www/moh-planning/
sudo cp moh-planning.service /etc/systemd/system/
sudo cp moh-planning.nginx.conf /etc/nginx/sites-available/moh-planning

# Create symlink if it doesn't exist
if [ ! -f /etc/nginx/sites-enabled/moh-planning ]; then
    sudo ln -s /etc/nginx/sites-available/moh-planning /etc/nginx/sites-enabled/
fi

# Set correct permissions
sudo chown -R www-data:www-data /var/www/moh-planning
sudo chmod -R 755 /var/www/moh-planning/staticfiles
sudo chmod -R 755 /var/www/moh-planning/media

# Collect static files
cd /var/www/moh-planning
source venv/bin/activate
python manage.py collectstatic --noinput

# Reload systemd
sudo systemctl daemon-reload

# Test nginx configuration
sudo nginx -t

# Restart services
echo "Restarting services..."
sudo systemctl restart moh-planning
sudo systemctl restart nginx

# Check service status
echo "Service status:"
sudo systemctl status moh-planning --no-pager

echo "Gunicorn should now be running on 196.190.255.168:8000"
echo "Check if it's accessible with: curl http://196.190.255.168:8000"
echo "Nginx should be forwarding requests from port 80 to Gunicorn"