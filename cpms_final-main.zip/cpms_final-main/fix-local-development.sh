#!/bin/bash
set -e

echo "=== Fixing Local Development Configuration ==="

# Create a backup of current settings.py
cp core/settings.py core/settings.py.bak
echo "✅ Created backup of settings.py"

# Update CSRF_TRUSTED_ORIGINS to include all needed domains
echo "Updating CSRF_TRUSTED_ORIGINS..."
cat > csrf_origins.txt << 'EOL'
CSRF_TRUSTED_ORIGINS = [
    "http://localhost:5173",  # Vite dev server
    "http://localhost:4173",  # Vite preview
    "http://196.190.255.168",
    "http://196.190.251.168",
    "http://196.188.120.132"  # Production IP
]
EOL

# Replace CSRF_TRUSTED_ORIGINS section in settings.py
sed -i '/CSRF_TRUSTED_ORIGINS/,/\]/c\'"$(cat csrf_origins.txt)" core/settings.py
rm csrf_origins.txt

# Add security headers configuration to the end of settings.py
echo "Adding security headers configuration..."
cat >> core/settings.py << 'EOL'

# Additional security headers (disabled for HTTP)
SECURE_BROWSER_XSS_FILTER = False
SECURE_CONTENT_TYPE_NOSNIFF = False
SECURE_HSTS_SECONDS = 0  # Disable HSTS for non-HTTPS
EOL

# Update api.ts to ensure proper CSRF handling
echo "Checking frontend API configuration..."
if ! grep -q "withCredentials: true" src/lib/api.ts; then
    echo "⚠️ withCredentials not properly set in api.ts"
    echo "Please manually check src/lib/api.ts and ensure all API calls include withCredentials: true"
fi

if ! grep -q "X-CSRFToken" src/lib/api.ts; then
    echo "⚠️ CSRF token header not properly set in api.ts"
    echo "Please manually check src/lib/api.ts and ensure CSRF tokens are included in all POST requests"
fi

# Create a .env file if it doesn't exist
if [ ! -f .env ]; then
    echo "Creating .env file..."
    cp .env.example .env || echo "VITE_API_URL=http://localhost:8000" > .env
    echo "✅ Created .env file"
fi

echo "=== Local Development Configuration Fixed ==="
echo ""
echo "What was updated:"
echo "1. Added all necessary IPs to CSRF_TRUSTED_ORIGINS"
echo "2. Added security header settings to core/settings.py"
echo "3. Ensured .env file exists for local development"
echo ""
echo "Next steps:"
echo "1. Restart your development server: python manage.py runserver"
echo "2. Try accessing the admin interface again"
echo "3. If problems persist, run './check-csrf-handling.sh' to diagnose CSRF issues"