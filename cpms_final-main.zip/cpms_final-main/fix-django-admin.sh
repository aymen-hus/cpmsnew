#!/bin/bash
set -e

echo "=== Fixing Django Admin 400 Bad Request Error ==="

# Create a directory for logs if it doesn't exist
sudo mkdir -p /var/www/moh-planning/logs
sudo chown -R www-data:www-data /var/www/moh-planning/logs

# Apply both fixes
echo "1. Fixing Apache configuration..."
sudo ./fix-apache-admin.sh

echo "2. Fixing Django CSRF settings..."
sudo ./fix-csrf-settings.sh

# Collect static files to make sure admin CSS/JS is available
echo "3. Collecting Django static files..."
cd /var/www/moh-planning
source venv/bin/activate
python manage.py collectstatic --noinput

# Restart Apache one final time
echo "4. Restarting Apache..."
sudo systemctl restart apache2

echo "=== All fixes completed ==="
echo "The Django admin should now work correctly."
echo ""
echo "If you still encounter issues:"
echo "1. Check Apache error logs: sudo tail -f /var/log/apache2/moh-planning-error.log"
echo "2. Check Django logs: sudo tail -f /var/www/moh-planning/logs/django.log"
echo ""
echo "You may need to clear your browser cache or try in a private/incognito window."