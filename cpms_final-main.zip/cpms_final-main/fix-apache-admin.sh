#!/bin/bash
set -e

echo "=== Fixing Apache Admin CSRF Issues ==="

# Create backup of existing config
if [ -f /etc/apache2/sites-available/moh-planning.conf ]; then
    sudo cp /etc/apache2/sites-available/moh-planning.conf /etc/apache2/sites-available/moh-planning.conf.bak
    echo "Created backup of current config"
fi

# Copy updated Apache configuration
echo "Updating Apache configuration..."
sudo cp fixed-apache.conf /etc/apache2/sites-available/moh-planning.conf

# Test Apache configuration
echo "Testing Apache configuration..."
sudo apache2ctl configtest

# Restart Apache
echo "Restarting Apache..."
sudo systemctl restart apache2

echo "=== Fix completed ==="
echo "Try accessing the admin page again at: http://196.190.255.168/admin/"
echo "If you still experience issues, check the logs:"
echo "  sudo tail -f /var/log/apache2/moh-planning-error.log"