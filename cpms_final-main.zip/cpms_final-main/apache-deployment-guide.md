# MOH Planning Application - Apache Deployment Guide

This guide provides step-by-step instructions for deploying your Django backend and React frontend using Apache with mod_wsgi.

## Prerequisites

- Ubuntu/Debian server
- Python 3.8+ 
- Node.js 14+
- Apache 2.4+
- MySQL database

## Step 1: Prepare Environment Variables

First, create a production environment file:

```bash
sudo mkdir -p /var/www/moh-planning
sudo cp .env.production /var/www/moh-planning/.env
```

Update the file with your specific settings:

```bash
sudo nano /var/www/moh-planning/.env
```

Make sure to include:
```
DEBUG=False
DJANGO_SECRET_KEY=your-production-secret-key-here
ALLOWED_HOSTS=localhost,127.0.0.1,196.190.255.168,196.190.251.168

# Database configuration
DB_NAME=organization_db
DB_USER=your_db_user
DB_PASSWORD=your_db_password
DB_HOST=localhost
DB_PORT=3306
```

## Step 2: Install Required Packages

```bash
# Update package list
sudo apt update

# Install Apache and mod_wsgi
sudo apt install apache2 libapache2-mod-wsgi-py3 python3-dev build-essential

# Install MySQL client if needed
sudo apt install default-libmysqlclient-dev
```

## Step 3: Set Up Python Virtual Environment

```bash
# Create application directory structure
sudo mkdir -p /var/www/moh-planning/logs
sudo mkdir -p /var/www/moh-planning/staticfiles
sudo mkdir -p /var/www/moh-planning/media

# Create virtual environment
sudo python3 -m venv /var/www/moh-planning/venv

# Install Python dependencies
sudo /var/www/moh-planning/venv/bin/pip install --upgrade pip
sudo /var/www/moh-planning/venv/bin/pip install -r requirements.production.txt
```

## Step 4: Build Frontend

```bash
# Install Node.js dependencies
npm ci

# Build the frontend
npm run build

# Copy the built frontend to the deployment directory
sudo cp -r dist/* /var/www/moh-planning/dist/
```

## Step 5: Deploy Django Backend

```bash
# Copy Django project files
sudo rsync -av --exclude={node_modules,venv,dist,.git} ./ /var/www/moh-planning/

# Collect static files
cd /var/www/moh-planning
sudo /var/www/moh-planning/venv/bin/python manage.py collectstatic --noinput

# Apply migrations
sudo /var/www/moh-planning/venv/bin/python manage.py migrate
```

## Step 6: Configure Apache

Create an Apache configuration file:

```bash
sudo nano /etc/apache2/sites-available/moh-planning.conf
```

Add the following content:

```apache
<VirtualHost *:80>
    ServerName 196.190.255.168
    ServerAlias 196.190.251.168
    
    # Admin email for server-generated messages
    ServerAdmin webmaster@localhost
    
    # Logs
    ErrorLog ${APACHE_LOG_DIR}/moh-planning-error.log
    CustomLog ${APACHE_LOG_DIR}/moh-planning-access.log combined
    
    # Document root for the React frontend
    DocumentRoot /var/www/moh-planning/dist
    
    # Static files
    Alias /static/ /var/www/moh-planning/staticfiles/
    <Directory /var/www/moh-planning/staticfiles>
        Require all granted
    </Directory>
    
    # Media files
    Alias /media/ /var/www/moh-planning/media/
    <Directory /var/www/moh-planning/media>
        Require all granted
    </Directory>
    
    # Django application served via WSGI
    WSGIDaemonProcess moh-planning python-home=/var/www/moh-planning/venv python-path=/var/www/moh-planning processes=2 threads=15 display-name=%{GROUP}
    WSGIProcessGroup moh-planning
    WSGIScriptAlias /api /var/www/moh-planning/core/wsgi.py
    WSGIScriptAlias /admin /var/www/moh-planning/core/wsgi.py
    
    <Directory /var/www/moh-planning/core>
        <Files wsgi.py>
            Require all granted
        </Files>
    </Directory>
    
    # React SPA routing - handle client-side routes
    <Directory /var/www/moh-planning/dist>
        Options -Indexes +FollowSymLinks
        AllowOverride None
        Require all granted
        
        # Rewrite rules for SPA
        RewriteEngine On
        # If the requested resource doesn't exist
        RewriteCond %{REQUEST_FILENAME} !-f
        RewriteCond %{REQUEST_FILENAME} !-d
        # And it's not an API request or admin
        RewriteCond %{REQUEST_URI} !^/api/
        RewriteCond %{REQUEST_URI} !^/admin/
        RewriteCond %{REQUEST_URI} !^/static/
        RewriteCond %{REQUEST_URI} !^/media/
        # Then rewrite to index.html
        RewriteRule ^ index.html [L]
    </Directory>
    
    # Increased timeout settings
    TimeOut 300
</VirtualHost>
```

## Step 7: Enable the Site

```bash
# Enable required Apache modules
sudo a2enmod wsgi
sudo a2enmod rewrite

# Disable the default site (if needed)
sudo a2dissite 000-default.conf

# Enable our site
sudo a2ensite moh-planning.conf

# Test the Apache configuration
sudo apache2ctl configtest

# Restart Apache
sudo systemctl restart apache2
```

## Step 8: Set Permissions

```bash
# Set proper ownership
sudo chown -R www-data:www-data /var/www/moh-planning

# Set proper permissions
sudo chmod -R 755 /var/www/moh-planning/staticfiles
sudo chmod -R 755 /var/www/moh-planning/media
sudo chmod 664 /var/www/moh-planning/.env
```

## Step 9: Test the Deployment

1. Visit your server in a browser: http://196.190.255.168/
2. Try accessing the admin interface: http://196.190.255.168/admin/
3. Test the API: http://196.190.255.168/api/auth/check/

## Troubleshooting

If you encounter issues:

1. Check Apache error logs:
   ```bash
   sudo tail -f /var/log/apache2/moh-planning-error.log
   ```

2. Check Apache access logs:
   ```bash
   sudo tail -f /var/log/apache2/moh-planning-access.log
   ```

3. Check Django logs:
   ```bash
   sudo tail -f /var/www/moh-planning/logs/django.log
   ```

4. Check Apache configuration:
   ```bash
   sudo apache2ctl configtest
   ```

5. Restart Apache:
   ```bash
   sudo systemctl restart apache2
   ```

6. Check mod_wsgi processes:
   ```bash
   ps aux | grep wsgi
   ```

7. Check if the port is in use:
   ```bash
   sudo netstat -tulpn | grep :80
   ```

## Common Issues and Solutions

### 1. "connect() failed" error in logs
This typically indicates that the WSGI process is not running or not accessible.

Solution:
```bash
# Restart Apache
sudo systemctl restart apache2

# Check if WSGI processes are running
ps aux | grep wsgi
```

### 2. "Permission denied" in logs
This indicates permission issues with your files.

Solution:
```bash
sudo chown -R www-data:www-data /var/www/moh-planning
sudo chmod -R 755 /var/www/moh-planning
```

### 3. 500 Internal Server Error
Check the Django logs for Python exceptions.

Solution:
```bash
# Check the logs
sudo tail -f /var/www/moh-planning/logs/django.log
```

### 4. CSS/JS not loading
This may be due to static files not being collected or served correctly.

Solution:
```bash
cd /var/www/moh-planning
sudo /var/www/moh-planning/venv/bin/python manage.py collectstatic --noinput
sudo chown -R www-data:www-data /var/www/moh-planning/staticfiles
```