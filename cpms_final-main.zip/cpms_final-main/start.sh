#!/bin/bash
# Start Django server and Vite dev server

echo "Starting Django server..."
python manage.py runserver &
DJANGO_PID=$!

echo "Starting Vite dev server..."
npm run dev &
VITE_PID=$!

# Trap Ctrl-C to kill both servers
trap "kill $DJANGO_PID $VITE_PID; exit" INT

# Wait for both processes
wait $DJANGO_PID $VITE_PID