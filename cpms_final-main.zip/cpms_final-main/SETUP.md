# Fixing 502 Bad Gateway Error

Follow these steps to fix your deployment issues:

## 1. Copy Configuration Files

```bash
# Copy the systemd service file
sudo cp moh-planning.service /etc/systemd/system/
sudo systemctl daemon-reload

# Copy the nginx configuration file
sudo cp moh-planning.nginx.conf /etc/nginx/sites-available/moh-planning
sudo ln -s /etc/nginx/sites-available/moh-planning /etc/nginx/sites-enabled/
```

## 2. Configure Production Environment

```bash
# Copy the production environment file
cp .env.production .env

# Edit the file to set your actual database credentials and secret key
nano .env
```

## 3. Set Correct Permissions

```bash
# Ensure the www-data user can access files
sudo mkdir -p /var/www/moh-planning/staticfiles /var/www/moh-planning/media
sudo chown -R www-data:www-data /var/www/moh-planning
```

## 4. Test Your Configuration

Check for errors in your nginx configuration:

```bash
sudo nginx -t
```

## 5. Restart Services

```bash
sudo systemctl restart moh-planning
sudo systemctl restart nginx
```

## 6. Check Service Status

```bash
sudo systemctl status moh-planning
sudo journalctl -u moh-planning -n 50
```

## 7. Troubleshooting

If you're still having issues:

1. Check the logs:
   ```bash
   sudo tail -n 50 /var/log/nginx/error.log
   ```

2. Make sure gunicorn is running:
   ```bash
   ps aux | grep gunicorn
   ```

3. Test if port 8000 is accessible:
   ```bash
   curl http://localhost:8000
   ```

4. Run the troubleshooting script:
   ```bash
   sudo ./troubleshoot.sh
   ```