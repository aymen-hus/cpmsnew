#!/bin/bash
set -e

echo "=== Testing CSRF Token Handling ==="

# Create test file for CSRF checking
cat > csrf-test.py << 'EOL'
#!/usr/bin/env python
import os
import sys
import requests
import json

# Base URL for API
base_url = os.environ.get('API_URL', 'http://localhost:8000')
print(f"Using API URL: {base_url}")

# Get CSRF token
print("\nGetting CSRF token...")
session = requests.Session()
try:
    csrf_response = session.get(f"{base_url}/api/auth/csrf/", timeout=5)
    print(f"CSRF Response status: {csrf_response.status_code}")
    print(f"CSRF Response headers: {csrf_response.headers}")
    
    cookies = session.cookies.get_dict()
    print(f"Cookies after CSRF request: {cookies}")
    
    csrf_token = cookies.get('csrftoken')
    if not csrf_token:
        print("⚠️ No CSRF token in cookies")
    else:
        print(f"CSRF token: {csrf_token[:10]}...")
    
    # Try making a POST request with CSRF token
    print("\nTrying POST request with CSRF token...")
    headers = {
        'Content-Type': 'application/json',
        'X-CSRFToken': csrf_token or '',
    }
    
    # Use a safe endpoint like logout that requires CSRF but won't affect the system
    post_response = session.post(
        f"{base_url}/api/auth/logout/", 
        headers=headers,
        timeout=5
    )
    print(f"POST Response status: {post_response.status_code}")
    print(f"POST Response: {post_response.text}")
    
except Exception as e:
    print(f"Error during CSRF test: {e}")
    sys.exit(1)
EOL

chmod +x csrf-test.py

# Test with development API URL
echo "Testing with development API URL..."
API_URL=http://localhost:8000 python3 csrf-test.py

# Test with production API URL if available
if [ -f .env.production ]; then
    PROD_URL=$(grep VITE_API_URL .env.production | cut -d= -f2)
    if [ ! -z "$PROD_URL" ]; then
        echo -e "\n\nTesting with production API URL..."
        API_URL=$PROD_URL python3 csrf-test.py
    fi
fi

echo -e "\n=== CSRF Test Complete ==="
echo "If you see '⚠️ No CSRF token in cookies', that's a problem."
echo "Make sure your server is setting the CSRF cookie correctly."