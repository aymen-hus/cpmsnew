/*
  # Fix Plan Submission Validation

  1. New Features
    - Add validation trigger for plan submission
    - Fix plan validation to prevent 400 errors
    - Ensure proper date validation
    - Add check for duplicate submissions

  2. Security
    - No changes to security settings
*/

-- First, add an index to speed up duplicate plan checks
CREATE INDEX IF NOT EXISTS idx_plans_submission 
ON plans(organization_id, strategic_objective_id, status);

-- Create function to validate plans before submission
CREATE OR REPLACE FUNCTION validate_plan_submission()
RETURNS TRIGGER AS $$
BEGIN
  -- Only run validation when status changes to SUBMITTED
  IF NEW.status = 'SUBMITTED' AND OLD.status != 'SUBMITTED' THEN
    -- Set submitted_at timestamp if not already set
    IF NEW.submitted_at IS NULL THEN
      NEW.submitted_at = now();
    END IF;
    
    -- Check for valid dates
    IF NEW.to_date < NEW.from_date THEN
      RAISE EXCEPTION 'End date must be after start date';
    END IF;
    
    -- Ensure fiscal year format is valid
    IF NEW.fiscal_year IS NULL OR length(NEW.fiscal_year) != 4 OR NEW.fiscal_year !~ '^\d{4}$' THEN
      RAISE EXCEPTION 'Fiscal year must be a 4-digit number';
    END IF;
    
    -- Check for duplicate submissions
    IF EXISTS (
      SELECT 1 FROM plans 
      WHERE organization_id = NEW.organization_id 
      AND strategic_objective_id = NEW.strategic_objective_id
      AND status IN ('SUBMITTED', 'APPROVED')
      AND id != NEW.id
    ) THEN
      RAISE EXCEPTION 'A plan for this organization and strategic objective has already been submitted or approved';
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for plan submission validation
DROP TRIGGER IF EXISTS validate_plan_submission_trigger ON plans;
CREATE TRIGGER validate_plan_submission_trigger
  BEFORE UPDATE ON plans
  FOR EACH ROW
  EXECUTE FUNCTION validate_plan_submission();

-- Create validation function for plan creation
CREATE OR REPLACE FUNCTION validate_plan_creation()
RETURNS TRIGGER AS $$
BEGIN
  -- Ensure required fields are present
  IF NEW.organization_id IS NULL THEN
    RAISE EXCEPTION 'Organization is required';
  END IF;
  
  IF NEW.strategic_objective_id IS NULL THEN
    RAISE EXCEPTION 'Strategic objective is required';
  END IF;
  
  IF NEW.from_date IS NULL OR NEW.to_date IS NULL THEN
    RAISE EXCEPTION 'From date and to date are required';
  END IF;
  
  IF NEW.planner_name IS NULL OR NEW.planner_name = '' THEN
    RAISE EXCEPTION 'Planner name is required';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for plan creation validation
DROP TRIGGER IF EXISTS validate_plan_creation_trigger ON plans;
CREATE TRIGGER validate_plan_creation_trigger
  BEFORE INSERT ON plans
  FOR EACH ROW
  EXECUTE FUNCTION validate_plan_creation();