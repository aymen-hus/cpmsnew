/*
  # New Costing Models Migration

  1. New Tables
    - locations
    - land_transports
    - air_transports
    - per_diems
    - accommodations
    - participant_costs
    - session_costs
    - printing_costs
    - supervisor_costs
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create locations table
CREATE TABLE locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  region text NOT NULL,
  is_hardship_area boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create land_transports table
CREATE TABLE land_transports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  origin_id uuid NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  destination_id uuid NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  trip_type text NOT NULL CHECK (trip_type IN ('SINGLE', 'ROUND')),
  price decimal NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create air_transports table
CREATE TABLE air_transports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  origin_id uuid NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  destination_id uuid NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  single_trip_price decimal NOT NULL,
  round_trip_price decimal NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create per_diems table
CREATE TABLE per_diems (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location_id uuid NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  amount decimal NOT NULL,
  hardship_allowance_amount decimal DEFAULT 0 NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create accommodations table
CREATE TABLE accommodations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location_id uuid NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  service_type text NOT NULL CHECK (service_type IN ('LUNCH', 'HALL_REFRESHMENT', 'DINNER', 'BED', 'FULL_BOARD')),
  price decimal NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create participant_costs table
CREATE TABLE participant_costs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cost_type text NOT NULL CHECK (cost_type IN ('FLASH_DISK', 'STATIONARY', 'ALL')),
  price decimal NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create session_costs table
CREATE TABLE session_costs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cost_type text NOT NULL CHECK (cost_type IN ('FLIP_CHART', 'MARKER', 'TONER_PAPER', 'ALL')),
  price decimal NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create printing_costs table
CREATE TABLE printing_costs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_type text NOT NULL CHECK (document_type IN ('MANUAL', 'BOOKLET', 'LEAFLET', 'BROCHURE')),
  price_per_page decimal NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create supervisor_costs table
CREATE TABLE supervisor_costs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cost_type text NOT NULL CHECK (cost_type IN ('MOBILE_CARD_300', 'MOBILE_CARD_500', 'STATIONARY', 'ALL')),
  amount decimal NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE land_transports ENABLE ROW LEVEL SECURITY;
ALTER TABLE air_transports ENABLE ROW LEVEL SECURITY;
ALTER TABLE per_diems ENABLE ROW LEVEL SECURITY;
ALTER TABLE accommodations ENABLE ROW LEVEL SECURITY;
ALTER TABLE participant_costs ENABLE ROW LEVEL SECURITY;
ALTER TABLE session_costs ENABLE ROW LEVEL SECURITY;
ALTER TABLE printing_costs ENABLE ROW LEVEL SECURITY;
ALTER TABLE supervisor_costs ENABLE ROW LEVEL SECURITY;

-- Create policies for each table
CREATE POLICY "Authenticated users can read locations"
  ON locations FOR SELECT TO authenticated USING (true);
  
CREATE POLICY "Admins can manage locations"
  ON locations FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM organization_users
      WHERE user_id = auth.uid()
      AND role = 'ADMIN'
    )
  );

-- Land transports policies
CREATE POLICY "Authenticated users can read land_transports"
  ON land_transports FOR SELECT TO authenticated USING (true);
  
CREATE POLICY "Admins can manage land_transports"
  ON land_transports FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM organization_users
      WHERE user_id = auth.uid()
      AND role = 'ADMIN'
    )
  );

-- Air transports policies
CREATE POLICY "Authenticated users can read air_transports"
  ON air_transports FOR SELECT TO authenticated USING (true);
  
CREATE POLICY "Admins can manage air_transports"
  ON air_transports FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM organization_users
      WHERE user_id = auth.uid()
      AND role = 'ADMIN'
    )
  );

-- Per diems policies
CREATE POLICY "Authenticated users can read per_diems"
  ON per_diems FOR SELECT TO authenticated USING (true);
  
CREATE POLICY "Admins can manage per_diems"
  ON per_diems FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM organization_users
      WHERE user_id = auth.uid()
      AND role = 'ADMIN'
    )
  );

-- Accommodations policies
CREATE POLICY "Authenticated users can read accommodations"
  ON accommodations FOR SELECT TO authenticated USING (true);
  
CREATE POLICY "Admins can manage accommodations"
  ON accommodations FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM organization_users
      WHERE user_id = auth.uid()
      AND role = 'ADMIN'
    )
  );

-- Participant costs policies
CREATE POLICY "Authenticated users can read participant_costs"
  ON participant_costs FOR SELECT TO authenticated USING (true);
  
CREATE POLICY "Admins can manage participant_costs"
  ON participant_costs FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM organization_users
      WHERE user_id = auth.uid()
      AND role = 'ADMIN'
    )
  );

-- Session costs policies
CREATE POLICY "Authenticated users can read session_costs"
  ON session_costs FOR SELECT TO authenticated USING (true);
  
CREATE POLICY "Admins can manage session_costs"
  ON session_costs FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM organization_users
      WHERE user_id = auth.uid()
      AND role = 'ADMIN'
    )
  );

-- Printing costs policies
CREATE POLICY "Authenticated users can read printing_costs"
  ON printing_costs FOR SELECT TO authenticated USING (true);
  
CREATE POLICY "Admins can manage printing_costs"
  ON printing_costs FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM organization_users
      WHERE user_id = auth.uid()
      AND role = 'ADMIN'
    )
  );

-- Supervisor costs policies
CREATE POLICY "Authenticated users can read supervisor_costs"
  ON supervisor_costs FOR SELECT TO authenticated USING (true);
  
CREATE POLICY "Admins can manage supervisor_costs"
  ON supervisor_costs FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM organization_users
      WHERE user_id = auth.uid()
      AND role = 'ADMIN'
    )
  );

-- Create indexes for better query performance
CREATE INDEX idx_land_transports_origin ON land_transports(origin_id);
CREATE INDEX idx_land_transports_destination ON land_transports(destination_id);
CREATE INDEX idx_air_transports_origin ON air_transports(origin_id);
CREATE INDEX idx_air_transports_destination ON air_transports(destination_id);
CREATE INDEX idx_per_diems_location ON per_diems(location_id);
CREATE INDEX idx_accommodations_location ON accommodations(location_id);