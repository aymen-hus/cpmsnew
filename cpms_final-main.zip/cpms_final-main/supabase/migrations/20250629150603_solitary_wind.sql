-- Create or replace function to validate initiative weights for custom objectives
CREATE OR REPLACE FUNCTION validate_initiative_weights_for_custom_objective()
RETURNS TRIGGER AS $$
DECLARE
  objective_record RECORD;
  total_weight DECIMAL;
  is_custom BOOLEAN;
BEGIN
  -- Only validate for initiatives linked to strategic objectives
  IF NEW.strategic_objective_id IS NULL THEN
    RETURN NEW;
  END IF;
  
  -- Get the strategic objective
  SELECT * INTO objective_record FROM strategic_objectives 
  WHERE id = NEW.strategic_objective_id;
  
  -- Check if it's a custom objective (not default)
  is_custom := NOT objective_record.is_default;
  
  -- If it's a custom objective, validate total weight
  IF is_custom THEN
    -- Calculate total weight of all initiatives for this objective (excluding current one if updating)
    SELECT COALESCE(SUM(weight), 0) INTO total_weight 
    FROM strategic_initiatives 
    WHERE strategic_objective_id = NEW.strategic_objective_id
    AND id != NEW.id;
    
    -- Add the new weight
    total_weight := total_weight + NEW.weight;
    
    -- For custom objectives, total weight must equal objective weight exactly
    IF total_weight != objective_record.weight THEN
      RAISE EXCEPTION 'For custom objectives, total initiative weight (%) must equal objective weight (%) exactly', 
                      total_weight, objective_record.weight;
    END IF;
  ELSE
    -- For default objectives, just ensure initiative weight doesn't exceed objective weight
    IF NEW.weight > objective_record.weight THEN
      RAISE EXCEPTION 'Initiative weight (%) exceeds objective weight (%)', 
                      NEW.weight, objective_record.weight;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop existing trigger first
DROP TRIGGER IF EXISTS validate_initiative_weights_trigger ON strategic_initiatives;

-- Create trigger to validate initiative weights
CREATE TRIGGER validate_initiative_weights_trigger
  BEFORE INSERT OR UPDATE ON strategic_initiatives
  FOR EACH ROW
  EXECUTE FUNCTION validate_initiative_weights_for_custom_objective();