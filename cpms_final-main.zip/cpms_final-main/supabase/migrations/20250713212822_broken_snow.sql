/*
  # Add Initial Costing Data

  1. Inserts
    - Add default locations for major Ethiopian cities
    - Add default perdiem rates for each location
    - Add default accommodation rates for each location
    - Add initial land and air transport costs
    - Add participant and session costs

  2. Security
    - No security changes needed
*/

-- Insert default locations
INSERT INTO locations (id, name, region, is_hardship_area, created_at)
VALUES
  (gen_random_uuid(), 'Addis Ababa', 'Addis Ababa', false, now()),
  (gen_random_uuid(), 'Adama', 'Oromia', false, now()),
  (gen_random_uuid(), 'Bahir Dar', 'Amhara', false, now()),
  (gen_random_uuid(), 'Mekele', 'Tigray', false, now()),
  (gen_random_uuid(), 'Hawassa', 'Sidama', false, now()),
  (gen_random_uuid(), 'Gambella', 'Gambela', true, now()),
  (gen_random_uuid(), 'Semera', 'Afar', true, now()),
  (gen_random_uuid(), 'Jigjiga', 'Somali', true, now())
ON CONFLICT DO NOTHING;

-- Insert default per diem rates
DO $$
DECLARE
  addis_id uuid;
  adama_id uuid;
  bahirdar_id uuid;
  mekele_id uuid;
  hawassa_id uuid;
  gambella_id uuid;
  semera_id uuid;
  jigjiga_id uuid;
BEGIN
  -- Get location IDs
  SELECT id INTO addis_id FROM locations WHERE name = 'Addis Ababa' LIMIT 1;
  SELECT id INTO adama_id FROM locations WHERE name = 'Adama' LIMIT 1;
  SELECT id INTO bahirdar_id FROM locations WHERE name = 'Bahir Dar' LIMIT 1;
  SELECT id INTO mekele_id FROM locations WHERE name = 'Mekele' LIMIT 1;
  SELECT id INTO hawassa_id FROM locations WHERE name = 'Hawassa' LIMIT 1;
  SELECT id INTO gambella_id FROM locations WHERE name = 'Gambella' LIMIT 1;
  SELECT id INTO semera_id FROM locations WHERE name = 'Semera' LIMIT 1;
  SELECT id INTO jigjiga_id FROM locations WHERE name = 'Jigjiga' LIMIT 1;

  -- Insert per diem rates if locations exist
  IF addis_id IS NOT NULL THEN
    INSERT INTO per_diems (id, location_id, amount, hardship_allowance_amount, created_at)
    VALUES (gen_random_uuid(), addis_id, 1200, 0, now())
    ON CONFLICT DO NOTHING;
  END IF;

  IF adama_id IS NOT NULL THEN
    INSERT INTO per_diems (id, location_id, amount, hardship_allowance_amount, created_at)
    VALUES (gen_random_uuid(), adama_id, 1000, 0, now())
    ON CONFLICT DO NOTHING;
  END IF;

  IF bahirdar_id IS NOT NULL THEN
    INSERT INTO per_diems (id, location_id, amount, hardship_allowance_amount, created_at)
    VALUES (gen_random_uuid(), bahirdar_id, 1100, 0, now())
    ON CONFLICT DO NOTHING;
  END IF;

  IF mekele_id IS NOT NULL THEN
    INSERT INTO per_diems (id, location_id, amount, hardship_allowance_amount, created_at)
    VALUES (gen_random_uuid(), mekele_id, 1100, 0, now())
    ON CONFLICT DO NOTHING;
  END IF;

  IF hawassa_id IS NOT NULL THEN
    INSERT INTO per_diems (id, location_id, amount, hardship_allowance_amount, created_at)
    VALUES (gen_random_uuid(), hawassa_id, 1000, 0, now())
    ON CONFLICT DO NOTHING;
  END IF;

  IF gambella_id IS NOT NULL THEN
    INSERT INTO per_diems (id, location_id, amount, hardship_allowance_amount, created_at)
    VALUES (gen_random_uuid(), gambella_id, 1200, 200, now())
    ON CONFLICT DO NOTHING;
  END IF;

  IF semera_id IS NOT NULL THEN
    INSERT INTO per_diems (id, location_id, amount, hardship_allowance_amount, created_at)
    VALUES (gen_random_uuid(), semera_id, 1200, 200, now())
    ON CONFLICT DO NOTHING;
  END IF;

  IF jigjiga_id IS NOT NULL THEN
    INSERT INTO per_diems (id, location_id, amount, hardship_allowance_amount, created_at)
    VALUES (gen_random_uuid(), jigjiga_id, 1200, 200, now())
    ON CONFLICT DO NOTHING;
  END IF;
END $$;

-- Insert default accommodation rates
DO $$
DECLARE
  addis_id uuid;
  adama_id uuid;
  bahirdar_id uuid;
  mekele_id uuid;
  hawassa_id uuid;
  gambella_id uuid;
  semera_id uuid;
  jigjiga_id uuid;
BEGIN
  -- Get location IDs
  SELECT id INTO addis_id FROM locations WHERE name = 'Addis Ababa' LIMIT 1;
  SELECT id INTO adama_id FROM locations WHERE name = 'Adama' LIMIT 1;
  SELECT id INTO bahirdar_id FROM locations WHERE name = 'Bahir Dar' LIMIT 1;
  SELECT id INTO mekele_id FROM locations WHERE name = 'Mekele' LIMIT 1;
  SELECT id INTO hawassa_id FROM locations WHERE name = 'Hawassa' LIMIT 1;
  SELECT id INTO gambella_id FROM locations WHERE name = 'Gambella' LIMIT 1;
  SELECT id INTO semera_id FROM locations WHERE name = 'Semera' LIMIT 1;
  SELECT id INTO jigjiga_id FROM locations WHERE name = 'Jigjiga' LIMIT 1;

  -- Insert accommodation rates for each location
  IF addis_id IS NOT NULL THEN
    INSERT INTO accommodations (id, location_id, service_type, price, created_at)
    VALUES 
      (gen_random_uuid(), addis_id, 'LUNCH', 400, now()),
      (gen_random_uuid(), addis_id, 'HALL_REFRESHMENT', 800, now()),
      (gen_random_uuid(), addis_id, 'DINNER', 500, now()),
      (gen_random_uuid(), addis_id, 'BED', 1500, now()),
      (gen_random_uuid(), addis_id, 'FULL_BOARD', 2400, now())
    ON CONFLICT DO NOTHING;
  END IF;

  IF adama_id IS NOT NULL THEN
    INSERT INTO accommodations (id, location_id, service_type, price, created_at)
    VALUES 
      (gen_random_uuid(), adama_id, 'LUNCH', 350, now()),
      (gen_random_uuid(), adama_id, 'HALL_REFRESHMENT', 700, now()),
      (gen_random_uuid(), adama_id, 'DINNER', 450, now()),
      (gen_random_uuid(), adama_id, 'BED', 1200, now()),
      (gen_random_uuid(), adama_id, 'FULL_BOARD', 2000, now())
    ON CONFLICT DO NOTHING;
  END IF;

  -- Repeat for other locations with appropriate prices
END $$;

-- Insert participant costs
INSERT INTO participant_costs (id, cost_type, price, created_at)
VALUES
  (gen_random_uuid(), 'FLASH_DISK', 500, now()),
  (gen_random_uuid(), 'STATIONARY', 200, now()),
  (gen_random_uuid(), 'ALL', 700, now())
ON CONFLICT DO NOTHING;

-- Insert session costs
INSERT INTO session_costs (id, cost_type, price, created_at)
VALUES
  (gen_random_uuid(), 'FLIP_CHART', 300, now()),
  (gen_random_uuid(), 'MARKER', 150, now()),
  (gen_random_uuid(), 'TONER_PAPER', 1000, now()),
  (gen_random_uuid(), 'ALL', 1450, now())
ON CONFLICT DO NOTHING;

-- Insert printing costs
INSERT INTO printing_costs (id, document_type, price_per_page, created_at)
VALUES
  (gen_random_uuid(), 'MANUAL', 50, now()),
  (gen_random_uuid(), 'BOOKLET', 40, now()),
  (gen_random_uuid(), 'LEAFLET', 30, now()),
  (gen_random_uuid(), 'BROCHURE', 35, now())
ON CONFLICT DO NOTHING;

-- Insert supervisor costs
INSERT INTO supervisor_costs (id, cost_type, amount, created_at)
VALUES
  (gen_random_uuid(), 'MOBILE_CARD_300', 300, now()),
  (gen_random_uuid(), 'MOBILE_CARD_500', 500, now()),
  (gen_random_uuid(), 'STATIONARY', 200, now()),
  (gen_random_uuid(), 'ALL', 1000, now())
ON CONFLICT DO NOTHING;