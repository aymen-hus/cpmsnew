/*
  # Fix Plan Validation

  1. Changes
    - Improve plan validation to better handle submission status
    - Add constraints to ensure proper validation of plans
    - Add index for faster plan queries by organization and status

  2. Security
    - No security changes needed
*/

-- Add index to plans table for faster querying of submitted plans by organization
CREATE INDEX IF NOT EXISTS idx_plans_org_status ON plans(organization_id, status);

-- Add constraint to ensure submitted plans have valid dates
ALTER TABLE plans ADD CONSTRAINT plan_dates_check 
CHECK (to_date >= from_date);

-- Create or replace function to validate plan submission
CREATE OR REPLACE FUNCTION validate_plan_submission()
RETURNS TRIGGER AS $$
BEGIN
  -- Only validate when status is being changed to SUBMITTED or APPROVED
  IF NEW.status IN ('SUBMITTED', 'APPROVED') THEN
    -- Ensure plan has valid dates
    IF NEW.to_date < NEW.from_date THEN
      RAISE EXCEPTION 'End date must be after start date';
    END IF;
    
    -- Check for existing submitted or approved plans with same organization and objective
    IF EXISTS (
      SELECT 1 FROM plans
      WHERE organization_id = NEW.organization_id
      AND strategic_objective_id = NEW.strategic_objective_id
      AND status IN ('SUBMITTED', 'APPROVED')
      AND id != NEW.id
    ) THEN
      RAISE EXCEPTION 'A plan for this organization and strategic objective has already been submitted or approved';
    END IF;
    
    -- Set submitted_at timestamp if it's not already set
    IF NEW.submitted_at IS NULL THEN
      NEW.submitted_at = now();
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for plan submission validation
DROP TRIGGER IF EXISTS validate_plan_submission_trigger ON plans;
CREATE TRIGGER validate_plan_submission_trigger
  BEFORE UPDATE OF status ON plans
  FOR EACH ROW
  EXECUTE FUNCTION validate_plan_submission();