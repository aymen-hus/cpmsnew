/*
  # Add Weight Validation to Custom Strategic Objectives

  1. Changes
    - Add check constraint to ensure weight is between 0.01 and 100
    - Add trigger to validate weight values

  2. Security
    - No security changes needed
*/

-- Add check constraint to ensure weight is within valid range
ALTER TABLE custom_strategic_objectives
ADD CONSTRAINT weight_range_check 
CHECK (weight IS NULL OR (weight >= 0.01 AND weight <= 100));

-- Create function to validate weight
CREATE OR REPLACE FUNCTION validate_custom_objective_weight()
RETURNS TRIGGER AS $$
BEGIN
  -- Only validate if weight is provided
  IF NEW.weight IS NOT NULL THEN
    -- Validate weight is positive
    IF NEW.weight <= 0 THEN
      RAISE EXCEPTION 'Weight must be positive';
    END IF;
    
    -- Validate weight doesn't exceed 100
    IF NEW.weight > 100 THEN
      RAISE EXCEPTION 'Weight cannot exceed 100';
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to validate weight
CREATE TRIGGER validate_custom_objective_weight_trigger
  BEFORE INSERT OR UPDATE ON custom_strategic_objectives
  FOR EACH ROW
  EXECUTE FUNCTION validate_custom_objective_weight();