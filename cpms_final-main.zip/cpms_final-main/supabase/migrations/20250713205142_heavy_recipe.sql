/*
  # Add Ethiopia Region Choices

  1. Changes
    - Add CHECK constraint for location regions to match Ethiopia's administrative divisions
    - Ensure all locations have valid regions
    - Add index for faster searching by region

  2. Security
    - No security changes needed
*/

-- Create temporary list of valid regions
CREATE TEMP TABLE valid_ethiopia_regions(region_name text);
INSERT INTO valid_ethiopia_regions VALUES 
  ('Addis Ababa'), ('Diredawa'), ('Afar'), ('Amhara'),
  ('Benishangul-Gumuz'), ('Central Ethiopia'), ('Gambela'), ('Harari'),
  ('Oromia'), ('Sidama'), ('Somali'), ('South Ethiopia'), ('Southwest'), ('Tigray');

-- Update any existing regions to valid ones if needed
UPDATE locations
SET region = 'Addis Ababa'
WHERE region NOT IN (SELECT region_name FROM valid_ethiopia_regions);

-- Add constraint to ensure only valid regions
ALTER TABLE locations
ADD CONSTRAINT location_region_check
CHECK (
  region IN ('Addis Ababa', 'Diredawa', 'Afar', 'Amhara', 'Benishangul-Gumuz',
            'Central Ethiopia', 'Gambela', 'Harari', 'Oromia', 'Sidama', 'Somali',
            'South Ethiopia', 'Southwest', 'Tigray')
);

-- Add index for faster region searches
CREATE INDEX IF NOT EXISTS idx_locations_region ON locations(region);

-- Drop temporary table
DROP TABLE valid_ethiopia_regions;