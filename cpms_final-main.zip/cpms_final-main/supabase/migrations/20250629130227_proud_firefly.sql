from django.db import migrations, models

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '20250528144500_add_weight_to_custom_objectives'),
    ]

    operations = [
        # Add program relationship index
        migrations.AddIndex(
            model_name='customstrategicobjective',
            index=models.Index(fields=['program'], name='idx_custom_objective_program'),
        ),
        
        # Add organization index
        migrations.AddIndex(
            model_name='customstrategicobjective',
            index=models.Index(fields=['organization'], name='idx_custom_objective_organization'),
        ),
    ]