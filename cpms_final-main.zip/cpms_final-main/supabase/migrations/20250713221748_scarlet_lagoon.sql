/*
  # Add Missing Per Diems for Locations

  1. Changes
    - Ensure every location has corresponding per diem rates
    - Ensure every location has corresponding accommodation rates
    - Update existing data to maintain consistency

  2. Security
    - No security changes needed
*/

-- Function to ensure per diem exists for each location
CREATE OR REPLACE FUNCTION ensure_per_diems_for_locations()
RETURNS void AS $$
DECLARE
  loc_record RECORD;
BEGIN
  FOR loc_record IN SELECT id, name, region, is_hardship_area FROM locations
  LOOP
    -- Check if per diem exists for this location
    IF NOT EXISTS (SELECT 1 FROM per_diems WHERE location_id = loc_record.id) THEN
      -- Insert default per diem based on region and hardship area
      INSERT INTO per_diems (
        id,
        location_id,
        amount,
        hardship_allowance_amount,
        created_at
      )
      VALUES (
        gen_random_uuid(),
        loc_record.id,
        CASE
          WHEN loc_record.region = 'Addis Ababa' THEN 1200
          WHEN loc_record.region IN ('Diredawa', 'Adama', 'Hawassa', 'Bahirdar') THEN 1000
          ELSE 1100
        END,
        CASE
          WHEN loc_record.is_hardship_area THEN 200
          ELSE 0
        END,
        now()
      );
      
      RAISE NOTICE 'Added per diem for location: %', loc_record.name;
    END IF;
    
    -- Check if full board accommodation exists for this location
    IF NOT EXISTS (
      SELECT 1 FROM accommodations 
      WHERE location_id = loc_record.id 
      AND service_type = 'FULL_BOARD'
    ) THEN
      -- Insert default accommodation rates
      INSERT INTO accommodations (
        id,
        location_id,
        service_type,
        price,
        created_at
      )
      VALUES
        (gen_random_uuid(), loc_record.id, 'LUNCH', 
          CASE
            WHEN loc_record.region = 'Addis Ababa' THEN 400
            WHEN loc_record.is_hardship_area THEN 450
            ELSE 350
          END, 
          now()
        ),
        (gen_random_uuid(), loc_record.id, 'HALL_REFRESHMENT', 
          CASE
            WHEN loc_record.region = 'Addis Ababa' THEN 800
            WHEN loc_record.is_hardship_area THEN 900
            ELSE 700
          END, 
          now()
        ),
        (gen_random_uuid(), loc_record.id, 'DINNER', 
          CASE
            WHEN loc_record.region = 'Addis Ababa' THEN 500
            WHEN loc_record.is_hardship_area THEN 550
            ELSE 450
          END, 
          now()
        ),
        (gen_random_uuid(), loc_record.id, 'BED', 
          CASE
            WHEN loc_record.region = 'Addis Ababa' THEN 1500
            WHEN loc_record.is_hardship_area THEN 1700
            ELSE 1200
          END, 
          now()
        ),
        (gen_random_uuid(), loc_record.id, 'FULL_BOARD', 
          CASE
            WHEN loc_record.region = 'Addis Ababa' THEN 2400
            WHEN loc_record.is_hardship_area THEN 2700
            ELSE 2000
          END, 
          now()
        );
      
      RAISE NOTICE 'Added accommodation rates for location: %', loc_record.name;
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Run the function to ensure per diems and accommodations exist for all locations
SELECT ensure_per_diems_for_locations();

-- Create basic transport options if none exist
DO $$
DECLARE
  addis_id uuid;
  loc_record RECORD;
BEGIN
  -- Try to find Addis Ababa
  SELECT id INTO addis_id FROM locations WHERE name = 'Addis Ababa' LIMIT 1;
  
  -- If Addis Ababa exists, create transport links to other locations
  IF addis_id IS NOT NULL THEN
    FOR loc_record IN 
      SELECT id, name, region, is_hardship_area 
      FROM locations 
      WHERE id != addis_id
    LOOP
      -- Add land transport if it doesn't exist
      IF NOT EXISTS (
        SELECT 1 FROM land_transports 
        WHERE (origin_id = addis_id AND destination_id = loc_record.id)
        OR (origin_id = loc_record.id AND destination_id = addis_id)
      ) THEN
        -- Add bidirectional land transport
        INSERT INTO land_transports (
          id, origin_id, destination_id, trip_type, price, created_at
        ) VALUES (
          gen_random_uuid(), addis_id, loc_record.id, 'SINGLE', 
          CASE
            WHEN loc_record.region IN ('Oromia', 'Addis Ababa', 'Diredawa') THEN 1000
            WHEN loc_record.is_hardship_area THEN 3000
            ELSE 2000
          END,
          now()
        );
        
        INSERT INTO land_transports (
          id, origin_id, destination_id, trip_type, price, created_at
        ) VALUES (
          gen_random_uuid(), loc_record.id, addis_id, 'SINGLE',
          CASE
            WHEN loc_record.region IN ('Oromia', 'Addis Ababa', 'Diredawa') THEN 1000
            WHEN loc_record.is_hardship_area THEN 3000
            ELSE 2000
          END,
          now()
        );
      END IF;
      
      -- Add air transport for distant locations
      IF loc_record.is_hardship_area OR 
         loc_record.region IN ('Tigray', 'Somali', 'Gambela', 'Afar', 'Benishangul-Gumuz') THEN
        
        IF NOT EXISTS (
          SELECT 1 FROM air_transports 
          WHERE (origin_id = addis_id AND destination_id = loc_record.id)
          OR (origin_id = loc_record.id AND destination_id = addis_id)
        ) THEN
          -- Add bidirectional air transport
          INSERT INTO air_transports (
            id, origin_id, destination_id, single_trip_price, round_trip_price, created_at
          ) VALUES (
            gen_random_uuid(), addis_id, loc_record.id, 5000, 9000, now()
          );
          
          INSERT INTO air_transports (
            id, origin_id, destination_id, single_trip_price, round_trip_price, created_at
          ) VALUES (
            gen_random_uuid(), loc_record.id, addis_id, 5000, 9000, now()
          );
        END IF;
      END IF;
    END LOOP;
  END IF;
END$$;