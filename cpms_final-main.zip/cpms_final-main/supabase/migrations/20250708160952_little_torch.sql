/*
  # Fix Plan Submission Issues

  1. Changes
    - Add better validation for plan submissions
    - Ensure proper handling of duplicate plan submissions
    - Add consistent timestamps for submitted plans

  2. Security
    - No security changes needed
*/

-- Add trigger function to validate plan submission
CREATE OR REPLACE FUNCTION validate_plan_submission()
RETURNS TRIGGER AS $$
BEGIN
  -- Only run validation when status changes to SUBMITTED
  IF NEW.status = 'SUBMITTED' AND OLD.status != 'SUBMITTED' THEN
    -- Check if the plan has a valid organization and strategic objective
    IF NEW.organization_id IS NULL OR NEW.strategic_objective_id IS NULL THEN
      RAISE EXCEPTION 'Plan must have both organization and strategic objective';
    END IF;
    
    -- Check if there's already a submitted or approved plan for this organization and objective
    IF EXISTS (
      SELECT 1 FROM plans 
      WHERE organization_id = NEW.organization_id 
      AND strategic_objective_id = NEW.strategic_objective_id
      AND status IN ('SUBMITTED', 'APPROVED')
      AND id != NEW.id
    ) THEN
      RAISE EXCEPTION 'A plan for this organization and strategic objective has already been submitted or approved';
    END IF;
    
    -- Set submitted_at timestamp if not already set
    IF NEW.submitted_at IS NULL THEN
      NEW.submitted_at = now();
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create or replace trigger for plan submission validation
DROP TRIGGER IF EXISTS validate_plan_submission_trigger ON plans;
CREATE TRIGGER validate_plan_submission_trigger
  BEFORE UPDATE ON plans
  FOR EACH ROW
  EXECUTE FUNCTION validate_plan_submission();

-- Add index to improve performance of duplicate plan checks
CREATE INDEX IF NOT EXISTS idx_plans_org_objective_status 
ON plans(organization_id, strategic_objective_id, status);