/*
  # Update Program Relationships

  1. Changes
    - Remove program field from custom_strategic_objectives
    - Add many-to-many relationship between programs and custom objectives
    - Create join table for program_custom_objectives

  2. Security
    - Update RLS policies for the new relationship
*/

-- Create join table for program_custom_objectives
CREATE TABLE IF NOT EXISTS program_custom_objectives (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id uuid NOT NULL REFERENCES programs(id) ON DELETE CASCADE,
  custom_objective_id uuid NOT NULL REFERENCES custom_strategic_objectives(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(program_id, custom_objective_id)
);

-- Enable RLS on the join table
ALTER TABLE program_custom_objectives ENABLE ROW LEVEL SECURITY;

-- Create policies for the join table
CREATE POLICY "Admins can manage program_custom_objectives"
  ON program_custom_objectives
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM organization_users
      WHERE user_id = auth.uid()
      AND role = 'ADMIN'
    )
  );

CREATE POLICY "All authenticated users can read program_custom_objectives"
  ON program_custom_objectives
  FOR SELECT
  TO authenticated
  USING (true);

-- Add indexes for better performance
CREATE INDEX idx_program_custom_objectives_program_id ON program_custom_objectives(program_id);
CREATE INDEX idx_program_custom_objectives_custom_objective_id ON program_custom_objectives(custom_objective_id);

-- Migrate existing relationships
-- This will copy relationships from the program field in custom_strategic_objectives
-- to the new join table
DO $$
DECLARE
  objective_record RECORD;
BEGIN
  FOR objective_record IN 
    SELECT id, program_id 
    FROM custom_strategic_objectives 
    WHERE program_id IS NOT NULL
  LOOP
    INSERT INTO program_custom_objectives (program_id, custom_objective_id)
    VALUES (objective_record.program_id, objective_record.id)
    ON CONFLICT DO NOTHING;
  END LOOP;
END $$;

-- Remove program_id column from custom_strategic_objectives
-- First drop the index if it exists
DROP INDEX IF EXISTS idx_custom_objective_program;

-- Then drop the column
ALTER TABLE custom_strategic_objectives DROP COLUMN IF EXISTS program_id;