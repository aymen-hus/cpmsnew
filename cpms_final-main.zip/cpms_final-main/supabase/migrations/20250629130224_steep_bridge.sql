from django.db import migrations, models
import django.core.validators

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '20250525121023_add_program_to_custom_objectives'),
    ]

    operations = [
        # Add weight field to CustomStrategicObjective model
        migrations.AddField(
            model_name='customstrategicobjective',
            name='weight',
            field=models.DecimalField(
                blank=True,
                decimal_places=2,
                help_text='Weight assigned by planner during planning (0-100)',
                max_digits=5,
                null=True,
                validators=[
                    django.core.validators.MinValueValidator(0.01, 'Weight must be positive'),
                    django.core.validators.MaxValueValidator(100, 'Weight cannot exceed 100')
                ]
            ),
        ),
    ]