/*
  # Add Target and Baseline Fields to Main Activities

  1. New Columns
    - `baseline` (text, not null, default '')
    - `q1_target` (decimal, not null, default 0)
    - `q2_target` (decimal, not null, default 0)
    - `q3_target` (decimal, not null, default 0)
    - `q4_target` (decimal, not null, default 0)
    - `annual_target` (decimal, not null, default 0)
    - `target_type` (text, not null, default 'cumulative')
  
  2. Changes
    - Add target and baseline fields to main_activities table
    - Set default values for all new fields
    - Add check constraint for target_type

  3. Security
    - No changes to RLS policies needed
*/

-- Update main_activities table to add target and baseline fields
ALTER TABLE main_activities
ADD COLUMN baseline TEXT NOT NULL DEFAULT '',
ADD COLUMN q1_target DECIMAL(10, 2) NOT NULL DEFAULT 0,
ADD COLUMN q2_target DECIMAL(10, 2) NOT NULL DEFAULT 0,
ADD COLUMN q3_target DECIMAL(10, 2) NOT NULL DEFAULT 0,
ADD COLUMN q4_target DECIMAL(10, 2) NOT NULL DEFAULT 0,
ADD COLUMN annual_target DECIMAL(10, 2) NOT NULL DEFAULT 0,
ADD COLUMN target_type TEXT NOT NULL DEFAULT 'cumulative';

-- Add constraint to ensure target_type is one of the allowed values
ALTER TABLE main_activities
ADD CONSTRAINT valid_target_type CHECK (
  target_type IN ('cumulative', 'increasing', 'decreasing')
);

-- Add index on target_type for better query performance
CREATE INDEX IF NOT EXISTS idx_main_activities_target_type ON main_activities(target_type);