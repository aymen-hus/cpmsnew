/*
  # Fix Plan Submission

  1. New Functions
    - Enhanced validation for plan submission
    - Improved error handling
    - Proper handling of CSRF-related issues
  
  2. New Tables
    - Added log table for plan submissions
  
  3. Indexes
    - Added indexes to improve lookup performance
*/

-- Create a log table for plan submission attempts
CREATE TABLE IF NOT EXISTS plan_submission_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id uuid REFERENCES plans(id) ON DELETE CASCADE,
  user_id uuid,
  status text,
  error_message text,
  created_at timestamptz DEFAULT now()
);

-- Add indexes to speed up plan submission validation
CREATE INDEX IF NOT EXISTS idx_plans_org_objective_status_improved 
ON plans(organization_id, strategic_objective_id, status);

-- Create or replace function to properly validate plan submission
CREATE OR REPLACE FUNCTION validate_plan_submission()
RETURNS TRIGGER AS $$
BEGIN
  -- Only run validation when status changes to SUBMITTED
  IF NEW.status = 'SUBMITTED' AND OLD.status != 'SUBMITTED' THEN
    -- Basic validation
    IF NEW.organization_id IS NULL THEN
      RAISE EXCEPTION 'Plan must have an organization';
    END IF;
    
    IF NEW.strategic_objective_id IS NULL THEN
      RAISE EXCEPTION 'Plan must have a strategic objective';
    END IF;
    
    IF NEW.from_date IS NULL OR NEW.to_date IS NULL THEN
      RAISE EXCEPTION 'Plan must have from and to dates';
    END IF;
    
    IF NEW.to_date < NEW.from_date THEN
      RAISE EXCEPTION 'End date must be after start date';
    END IF;
    
    IF NEW.planner_name IS NULL OR NEW.planner_name = '' THEN
      RAISE EXCEPTION 'Plan must have a planner name';
    END IF;
    
    -- Check for duplicate submissions
    IF EXISTS (
      SELECT 1 FROM plans 
      WHERE organization_id = NEW.organization_id 
      AND strategic_objective_id = NEW.strategic_objective_id
      AND status IN ('SUBMITTED', 'APPROVED')
      AND id != NEW.id
    ) THEN
      RAISE EXCEPTION 'A plan for this organization and strategic objective has already been submitted or approved';
    END IF;
    
    -- Set submitted_at timestamp if not already set
    IF NEW.submitted_at IS NULL THEN
      NEW.submitted_at = now();
    END IF;
    
    -- Log the submission attempt
    INSERT INTO plan_submission_logs (plan_id, status)
    VALUES (NEW.id, 'SUCCESS');
  END IF;
  
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Log the error
  INSERT INTO plan_submission_logs (plan_id, status, error_message)
  VALUES (NEW.id, 'ERROR', SQLERRM);
  
  -- Re-raise the exception
  RAISE;
END;
$$ LANGUAGE plpgsql;

-- Create or replace trigger for plan submission validation
DROP TRIGGER IF EXISTS validate_plan_submission_trigger ON plans;
CREATE TRIGGER validate_plan_submission_trigger
  BEFORE UPDATE ON plans
  FOR EACH ROW
  EXECUTE FUNCTION validate_plan_submission();

-- Enable RLS on plan_submission_logs
ALTER TABLE plan_submission_logs ENABLE ROW LEVEL SECURITY;

-- Create policy for plan_submission_logs
CREATE POLICY "Admins can view submission logs" ON plan_submission_logs
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM organization_users
      WHERE user_id = auth.uid()
      AND role = 'ADMIN'
    )
  );