from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):

    dependencies = [
        ('organizations', '20250522194314_weathered_cottage'),  # Adjust this to the name of your last migration
    ]

    operations = [
        # Add program field to CustomStrategicObjective model
        migrations.AddField(
            model_name='customstrategicobjective',
            name='program',
            field=models.ForeignKey(
                blank=True,
                help_text='Associated program (optional)',
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='custom_objectives',
                to='organizations.program'
            ),
        ),
        
        # Add index for better query performance
        migrations.AddIndex(
            model_name='customstrategicobjective',
            index=models.Index(fields=['program'], name='idx_custom_objective_program'),
        ),
    ]