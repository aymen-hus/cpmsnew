/*
  # Add Annual Target Type

  1. Changes
    - Add 'annual' target type to valid target_type values in main_activities table
    - Add 'annual' target type to valid target_type values in performance_measures table
    - Update existing constraint to include the new target type

  2. Security
    - No security changes needed
*/

-- Update constraints for main_activities table
ALTER TABLE main_activities
DROP CONSTRAINT IF EXISTS valid_target_type;

ALTER TABLE main_activities
ADD CONSTRAINT valid_target_type CHECK (
  target_type IN ('cumulative', 'increasing', 'decreasing', 'annual')
);

-- Update constraints for performance_measures table
ALTER TABLE performance_measures
DROP CONSTRAINT IF EXISTS valid_target_type;

ALTER TABLE performance_measures
ADD CONSTRAINT valid_target_type CHECK (
  target_type IN ('cumulative', 'increasing', 'decreasing', 'annual')
);

-- Add validation function for annual target type
CREATE OR REPLACE FUNCTION validate_target_values()
RETURNS TRIGGER AS $$
BEGIN
  -- Annual target type validation (all quarters must equal annual target)
  IF NEW.target_type = 'annual' THEN
    -- Ensure all quarterly targets equal the annual target
    IF NEW.q1_target != NEW.annual_target OR 
       NEW.q2_target != NEW.annual_target OR 
       NEW.q3_target != NEW.annual_target OR 
       NEW.q4_target != NEW.annual_target THEN
      RAISE EXCEPTION 'For annual target type, all quarterly targets must equal the annual target';
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for both tables
DROP TRIGGER IF EXISTS validate_main_activity_targets ON main_activities;
CREATE TRIGGER validate_main_activity_targets
  BEFORE INSERT OR UPDATE ON main_activities
  FOR EACH ROW
  EXECUTE FUNCTION validate_target_values();

DROP TRIGGER IF EXISTS validate_performance_measure_targets ON performance_measures;
CREATE TRIGGER validate_performance_measure_targets
  BEFORE INSERT OR UPDATE ON performance_measures
  FOR EACH ROW
  EXECUTE FUNCTION validate_target_values();