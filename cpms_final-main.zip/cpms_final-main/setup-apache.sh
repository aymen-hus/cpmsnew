#!/bin/bash
set -e

echo "=== Setting up Apache for MOH Planning Application ==="

# Check if we're running as root
if [[ $EUID -ne 0 ]]; then
    echo "⚠️  This script should be run as root"
    echo "   Please run with: sudo ./setup-apache.sh"
    exit 1
fi

# Install required packages if not already installed
echo "Installing required packages..."
apt-get update
apt-get install -y apache2 libapache2-mod-wsgi-py3

# Enable required Apache modules
echo "Enabling required Apache modules..."
a2enmod wsgi
a2enmod rewrite

# Copy configuration file
echo "Copying Apache configuration file..."
cp moh-planning-apache.conf /etc/apache2/sites-available/moh-planning.conf

# Create necessary directories
echo "Creating necessary directories..."
mkdir -p /var/www/moh-planning/logs
mkdir -p /var/www/moh-planning/staticfiles
mkdir -p /var/www/moh-planning/media

# Ensure correct permissions
echo "Setting correct permissions..."
chown -R www-data:www-data /var/www/moh-planning
chmod -R 755 /var/www/moh-planning/staticfiles
chmod -R 755 /var/www/moh-planning/media

# Enable the site
echo "Enabling site configuration..."
a2dissite 000-default.conf
a2ensite moh-planning.conf

# Test Apache configuration
echo "Testing Apache configuration..."
apache2ctl configtest

# Restart Apache
echo "Restarting Apache..."
systemctl restart apache2

echo "=== Setup complete ==="
echo "Apache has been configured to serve the MOH Planning application."
echo "If you encounter any issues, check the logs:"
echo "  - Apache error log: tail -f /var/log/apache2/moh-planning-error.log"
echo "  - Apache access log: tail -f /var/log/apache2/moh-planning-access.log"
echo "  - Django log: tail -f /var/www/moh-planning/logs/django.log"