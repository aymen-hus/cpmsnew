#!/bin/bash
set -e

# Configuration
DEPLOY_DIR="/var/www/moh-planning"
REPO_DIR="$PWD"
VENV_DIR="$DEPLOY_DIR/venv"
LOG_FILE="$DEPLOY_DIR/deploy.log"

echo "Starting deployment process..." | tee -a $LOG_FILE
date | tee -a $LOG_FILE

# Create deployment directory if it doesn't exist
sudo mkdir -p $DEPLOY_DIR
sudo chown -R $(whoami):$(whoami) $DEPLOY_DIR
mkdir -p $DEPLOY_DIR/logs

# Set up Python virtual environment
echo "Setting up Python virtual environment..." | tee -a $LOG_FILE
if [ ! -d "$VENV_DIR" ]; then
    python3 -m venv $VENV_DIR
fi
source $VENV_DIR/bin/activate

# Install Python dependencies
echo "Installing Python dependencies..." | tee -a $LOG_FILE
pip install --upgrade pip | tee -a $LOG_FILE
pip install wheel | tee -a $LOG_FILE

# Install mysqlclient with error handling
echo "Installing mysqlclient..." | tee -a $LOG_FILE
pip install mysqlclient || {
    echo "mysqlclient failed, installing dependencies..." | tee -a $LOG_FILE
    sudo apt-get update
    sudo apt-get install -y python3-dev default-libmysqlclient-dev build-essential pkg-config
    pip install mysqlclient
}

# Install production requirements
pip install -r requirements.production.txt | tee -a $LOG_FILE

# Check Node.js version
echo "Checking Node.js version..." | tee -a $LOG_FILE
NODE_VERSION=$(node -v | cut -d 'v' -f 2 | cut -d '.' -f 1)
echo "Detected Node.js version: $(node -v)" | tee -a $LOG_FILE

# Install Node.js dependencies
echo "Installing Node.js dependencies..." | tee -a $LOG_FILE
npm ci | tee -a $LOG_FILE

# Build the React frontend
echo "Building React frontend..." | tee -a $LOG_FILE
if [ "$NODE_VERSION" -lt "14" ]; then
    echo "Using compatibility build script for Node.js < 14..." | tee -a $LOG_FILE
    node build.js | tee -a $LOG_FILE
else
    echo "Using standard build command for Node.js >= 14..." | tee -a $LOG_FILE
    npm run build | tee -a $LOG_FILE
fi

# Copy files to deployment directory
echo "Copying files to deployment directory..." | tee -a $LOG_FILE
# Copy Django files
rsync -av --exclude="node_modules" \
         --exclude=".git" \
         --exclude="venv" \
         --exclude="__pycache__" \
         --exclude="*.pyc" \
         $REPO_DIR/ $DEPLOY_DIR/ | tee -a $LOG_FILE

# Ensure static files directory exists
mkdir -p $DEPLOY_DIR/staticfiles
mkdir -p $DEPLOY_DIR/media

# Django setup
echo "Setting up Django..." | tee -a $LOG_FILE
cd $DEPLOY_DIR
source $VENV_DIR/bin/activate

# Copy production environment file if it doesn't exist
if [ ! -f $DEPLOY_DIR/.env ]; then
    cp $DEPLOY_DIR/.env.production $DEPLOY_DIR/.env
    echo "Created production .env file" | tee -a $LOG_FILE
fi

# Run Django commands
echo "Running Django collectstatic..." | tee -a $LOG_FILE
python manage.py collectstatic --noinput | tee -a $LOG_FILE
echo "Running Django migrations..." | tee -a $LOG_FILE
python manage.py migrate --noinput | tee -a $LOG_FILE

# Set correct permissions
echo "Setting correct permissions..." | tee -a $LOG_FILE
sudo chown -R www-data:www-data $DEPLOY_DIR
sudo chmod -R 755 $DEPLOY_DIR/staticfiles
sudo chmod -R 755 $DEPLOY_DIR/media

# Configure nginx
echo "Setting up Nginx configuration..." | tee -a $LOG_FILE
sudo cp $DEPLOY_DIR/moh-planning.nginx.conf /etc/nginx/sites-available/moh-planning
if [ ! -f /etc/nginx/sites-enabled/moh-planning ]; then
    sudo ln -s /etc/nginx/sites-available/moh-planning /etc/nginx/sites-enabled/
    echo "Created Nginx symlink" | tee -a $LOG_FILE
fi

# Configure systemd
echo "Setting up systemd service..." | tee -a $LOG_FILE
sudo cp $DEPLOY_DIR/moh-planning.service /etc/systemd/system/
sudo systemctl daemon-reload

# Restart services
echo "Restarting services..." | tee -a $LOG_FILE
sudo systemctl restart moh-planning || {
    echo "Failed to restart moh-planning service. Check systemd logs with: sudo journalctl -u moh-planning" | tee -a $LOG_FILE
    exit 1
}

sudo systemctl restart nginx || {
    echo "Failed to restart nginx. Check nginx logs with: sudo journalctl -u nginx" | tee -a $LOG_FILE
    exit 1
}

echo "Deployment completed successfully at $(date)" | tee -a $LOG_FILE
echo "Checking service status:" | tee -a $LOG_FILE
sudo systemctl status moh-planning --no-pager | tee -a $LOG_FILE