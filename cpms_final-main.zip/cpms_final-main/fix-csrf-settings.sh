#!/bin/bash
set -e

echo "=== Fixing CSRF Settings in Django ==="

# Check if we're running as root
if [[ $EUID -ne 0 ]]; then
    echo "⚠️  This script should be run as root"
    echo "   Please run with: sudo ./fix-csrf-settings.sh"
    exit 1
fi

# Path to project directory
APP_DIR="/var/www/moh-planning"
SETTINGS_FILE="${APP_DIR}/core/settings.py"
ENV_FILE="${APP_DIR}/.env"

# Create backup of current settings
cp "${SETTINGS_FILE}" "${SETTINGS_FILE}.bak"
echo "Created backup of current settings at ${SETTINGS_FILE}.bak"

# Update CSRF and cookie settings
echo "Updating CSRF and cookie settings..."

# Add new settings using sed
sed -i 's/CSRF_COOKIE_SECURE = False/CSRF_COOKIE_SECURE = False  # Keep False for HTTP/' "${SETTINGS_FILE}"
sed -i 's/SESSION_COOKIE_SECURE = False/SESSION_COOKIE_SECURE = False  # Keep False for HTTP/' "${SETTINGS_FILE}"

# Add new setting to make CSRF work with your domain
sed -i '/CSRF_TRUSTED_ORIGINS/c\CSRF_TRUSTED_ORIGINS = [\n    "http://localhost:5173",\n    "http://localhost:4173",\n    "http://196.190.255.168",\n    "http://196.190.251.168",\n    "http://196.188.120.132"\n]' "${SETTINGS_FILE}"

# Add allowed hosts to .env file if it exists
if [ -f "${ENV_FILE}" ]; then
    echo "Updating ALLOWED_HOSTS in .env file..."
    sed -i 's/ALLOWED_HOSTS=.*/ALLOWED_HOSTS=localhost,127.0.0.1,196.190.255.168,196.190.251.168,196.188.120.132/' "${ENV_FILE}"
fi

# Make sure the wsgi.py file is updated to use the right settings module
echo "Updating wsgi.py to use appropriate settings..."
cat > "${APP_DIR}/core/wsgi.py" << 'EOL'
"""
WSGI config for core project.

It exposes the WSGI callable as a module-level variable named ``application``.
"""

import os

from django.core.wsgi import get_wsgi_application

# Check if we're running in production
if os.environ.get('DEBUG', 'True') == 'False':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.production')
else:
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')

application = get_wsgi_application()
EOL

# Make sure permissions are correct
chown www-data:www-data "${SETTINGS_FILE}"
chown www-data:www-data "${APP_DIR}/core/wsgi.py"
if [ -f "${ENV_FILE}" ]; then
    chown www-data:www-data "${ENV_FILE}"
fi

# Restart the application
echo "Restarting Apache..."
systemctl restart apache2

echo "=== CSRF settings fixed ==="
echo "Try accessing the admin page again: http://196.190.255.168/admin/"