# Complete MOH Planning Application Deployment Guide for Ubuntu VPS

This guide provides detailed instructions for deploying the Ministry of Health Planning application on an Ubuntu VPS using Nginx and Gunicorn.

## 1. Initial Server Setup

### 1.1 Connect to your VPS and update packages
```bash
ssh user@your_server_ip
sudo apt update && sudo apt upgrade -y
```

### 1.2 Install required packages
```bash
sudo apt install -y python3 python3-pip python3-dev python3-venv build-essential libssl-dev libffi-dev nginx mysql-server libmysqlclient-dev git
```

### 1.3 Configure basic firewall
```bash
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw enable
```

## 2. MySQL Database Setup

### 2.1 Secure MySQL installation
```bash
sudo mysql_secure_installation
```

Follow the prompts to:
- Set a root password
- Remove anonymous users
- Disallow root login remotely
- Remove test database
- Reload privilege tables

### 2.2 Create database and user
```bash
sudo mysql -u root -p
```

Run these SQL commands:
```sql
CREATE DATABASE organization_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'moh_user'@'localhost' IDENTIFIED BY 'secure_password';
GRANT ALL PRIVILEGES ON organization_db.* TO 'moh_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

## 3. Application Setup

### 3.1 Create application directory
```bash
sudo mkdir -p /var/www/moh-planning
sudo chown -R $USER:$USER /var/www/moh-planning
```

### 3.2 Clone or upload your project
Either clone your repository:
```bash
cd /var/www/moh-planning
git clone https://your-repository-url.git .
```

Or upload your files using SCP/SFTP and extract them.

### 3.3 Create required directories
```bash
mkdir -p /var/www/moh-planning/logs
mkdir -p /var/www/moh-planning/staticfiles
mkdir -p /var/www/moh-planning/media
```

## 4. Python Environment Setup

### 4.1 Create and activate virtual environment
```bash
cd /var/www/moh-planning
python3 -m venv venv
source venv/bin/activate
```

### 4.2 Upgrade pip and install dependencies
```bash
pip install --upgrade pip
pip install wheel  # Helps with binary package installation
pip install -r requirements.production.txt
```

## 5. Node.js Setup and Frontend Build

### 5.1 Install Node.js
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### 5.2 Verify Node.js installation
```bash
node -v
npm -v
```

### 5.3 Install npm dependencies and build frontend
```bash
cd /var/www/moh-planning
npm ci
npm run build
```

## 6. Django Configuration

### 6.1 Create production .env file
```bash
cp .env.production /var/www/moh-planning/.env
```

### 6.2 Edit .env file
```bash
nano /var/www/moh-planning/.env
```

Update with your production values:
```
DEBUG=False
DJANGO_SECRET_KEY=your_very_secure_random_key_here
ALLOWED_HOSTS=localhost,127.0.0.1,196.190.255.168,196.190.251.168,your-domain.com

# Database configuration
DB_NAME=organization_db
DB_USER=moh_user
DB_PASSWORD=secure_password
DB_HOST=localhost
DB_PORT=3306

# Static files
STATIC_URL=/static/
STATIC_ROOT=/var/www/moh-planning/staticfiles

# Security settings - for HTTP
CSRF_COOKIE_SECURE=False
SESSION_COOKIE_SECURE=False
CSRF_COOKIE_HTTPONLY=False
SESSION_COOKIE_HTTPONLY=True
CSRF_TRUSTED_ORIGINS=http://196.190.255.168,http://196.190.251.168,http://your-domain.com

# API URL for frontend - match your actual server address
VITE_API_URL=http://196.190.255.168
```

### 6.3 Apply database migrations
```bash
cd /var/www/moh-planning
source venv/bin/activate
python manage.py migrate
```

### 6.4 Collect static files
```bash
python manage.py collectstatic --noinput
```

### 6.5 Create admin superuser
```bash
python manage.py createsuperuser
```

## 7. Gunicorn Configuration

### 7.1 Create Gunicorn config file
```bash
nano /var/www/moh-planning/gunicorn.conf.py
```

Content:
```python
# Gunicorn configuration file
import multiprocessing
import os

# Bind to localhost only (Nginx will proxy requests)
bind = "127.0.0.1:8000"

# Number of worker processes (2-4 x number of CPU cores)
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = "sync"

# Timeouts - increase for admin pages
timeout = 300

# Logging
log_dir = "/var/www/moh-planning/logs"
# Create logs directory if it doesn't exist
if not os.path.exists(log_dir):
    try:
        os.makedirs(log_dir)
    except:
        pass

accesslog = f"{log_dir}/gunicorn-access.log"
errorlog = f"{log_dir}/gunicorn-error.log"
loglevel = "debug"  # Increase log level for troubleshooting
capture_output = True  # Ensure all app output is captured

# Security and performance
max_requests = 1000
max_requests_jitter = 50
keepalive = 2

# Improve worker process name
proc_name = "moh-planning"
```

## 8. Systemd Service Configuration

### 8.1 Create systemd service file
```bash
sudo nano /etc/systemd/system/moh-planning.service
```

Content:
```ini
[Unit]
Description=Ministry of Health Planning and Reporting Application
After=network.target mysql.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/moh-planning
Environment="PATH=/var/www/moh-planning/venv/bin:/usr/local/bin:/usr/bin:/bin"
Environment="DJANGO_SETTINGS_MODULE=core.production"
Environment="DEBUG=False"
Environment="ALLOWED_HOSTS=localhost,127.0.0.1,196.190.255.168,196.190.251.168,your-domain.com"

# Explicitly set CSRF trusted origins
Environment="CSRF_TRUSTED_ORIGINS=http://196.190.255.168,http://196.190.251.168,http://your-domain.com"

ExecStart=/var/www/moh-planning/venv/bin/gunicorn core.wsgi:application --config=/var/www/moh-planning/gunicorn.conf.py
Restart=always
RestartSec=5s
StartLimitIntervalSec=0

# Give time for gunicorn to start properly
TimeoutStartSec=60s

[Install]
WantedBy=multi-user.target
```

Replace your-domain.com, 196.190.255.168, and 196.190.251.168 with your actual domain/IPs.

## 9. Nginx Configuration

### 9.1 Create Nginx server configuration
```bash
sudo nano /etc/nginx/sites-available/moh-planning
```

Content:
```nginx
server {
    listen 80;
    server_name 196.190.255.168 196.190.251.168 your-domain.com;

    # Logs
    access_log /var/log/nginx/moh-planning-access.log;
    error_log /var/log/nginx/moh-planning-error.log error;

    # Static files with improved caching
    location /static/ {
        alias /var/www/moh-planning/staticfiles/;
        expires 30d;
        add_header Cache-Control "public, max-age=2592000";
        try_files $uri $uri/ =404;
        access_log off;
    }

    # Media files
    location /media/ {
        alias /var/www/moh-planning/media/;
        expires 30d;
        add_header Cache-Control "public, max-age=2592000";
        access_log off;
    }

    # Django admin with extended timeout
    location /admin/ {
        proxy_pass http://127.0.0.1:8000/admin/;
        proxy_set_header Host $http_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Extended timeout for admin
        proxy_connect_timeout 300s;
        proxy_send_timeout 300s;
        proxy_read_timeout 300s;
        
        # Increased buffer size for admin responses
        proxy_buffer_size 16k;
        proxy_buffers 8 16k;
        proxy_busy_buffers_size 32k;
    }
    
    # Django API
    location /api/ {
        proxy_pass http://127.0.0.1:8000/api/;
        proxy_set_header Host $http_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 120s;
        
        # CORS headers
        add_header 'Access-Control-Allow-Origin' '*' always;
        add_header 'Access-Control-Allow-Methods' 'GET, POST, PUT, DELETE, OPTIONS' always;
        add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization,X-CSRFToken' always;
        
        # Handle OPTIONS requests for CORS preflight
        if ($request_method = 'OPTIONS') {
            add_header 'Access-Control-Allow-Origin' '*';
            add_header 'Access-Control-Allow-Methods' 'GET, POST, PUT, DELETE, OPTIONS';
            add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization,X-CSRFToken';
            add_header 'Access-Control-Max-Age' 1728000;
            add_header 'Content-Type' 'text/plain; charset=utf-8';
            add_header 'Content-Length' 0;
            return 204;
        }
        
        # Buffering settings
        proxy_buffer_size 16k;
        proxy_buffers 8 16k;
    }

    # Frontend React app and catch-all
    location / {
        root /var/www/moh-planning/dist;
        try_files $uri $uri/ /index.html;
        expires 1h;
    }
    
    # Increase max request size
    client_max_body_size 10M;
    
    # Error pages
    error_page 500 502 503 504 /500.html;
    location = /500.html {
        root /var/www/moh-planning/dist;
        internal;
    }
}
```

Replace your-domain.com, 196.190.255.168, and 196.190.251.168 with your actual domain/IPs.

### 9.2 Enable the Nginx site and test configuration
```bash
sudo ln -sf /etc/nginx/sites-available/moh-planning /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default  # Remove default site if it exists
sudo nginx -t  # Test nginx configuration
```

If the test is successful, proceed to reload Nginx.

## 10. Set Permissions and Error Pages

### 10.1 Copy error pages
```bash
cp /var/www/moh-planning/500.html /var/www/moh-planning/dist/
cp /var/www/moh-planning/502.html /var/www/moh-planning/dist/
```

### 10.2 Set correct permissions
```bash
sudo chown -R www-data:www-data /var/www/moh-planning
sudo chmod -R 755 /var/www/moh-planning/staticfiles
sudo chmod -R 755 /var/www/moh-planning/media
sudo chmod -R 755 /var/www/moh-planning/dist
sudo chmod 664 /var/www/moh-planning/.env
```

## 11. Start and Enable Services

```bash
sudo systemctl daemon-reload
sudo systemctl enable moh-planning
sudo systemctl start moh-planning
sudo systemctl restart nginx
```

## 12. Verify the Deployment

### 12.1 Check service status
```bash
sudo systemctl status moh-planning
sudo systemctl status nginx
```

### 12.2 Test API connection
```bash
curl -I http://127.0.0.1:8000/api/auth/check/
curl -I http://localhost/api/auth/check/
```

### 12.3 Check logs for errors
```bash
sudo tail -f /var/www/moh-planning/logs/gunicorn-error.log
sudo tail -f /var/log/nginx/moh-planning-error.log
```

## 13. Common Issues and Fixes

### 13.1 "500 Internal Server Error" when accessing frontend

1. Check Django logs:
```bash
sudo tail -f /var/www/moh-planning/logs/gunicorn-error.log
```

2. Verify that Gunicorn is running:
```bash
sudo systemctl status moh-planning
```

3. Make sure dist directory contains index.html:
```bash
ls -la /var/www/moh-planning/dist/
```

4. Fix: If the issue is with the frontend, rebuild it:
```bash
cd /var/www/moh-planning
npm run build
```

5. If it's a Django issue, check the application's logs and debug the backend.

### 13.2 "502 Bad Gateway" error

1. Check if Gunicorn is running and listening on port 8000:
```bash
sudo ss -tlnp | grep 8000
```

2. If not running, start the service:
```bash
sudo systemctl restart moh-planning
```

3. Check Gunicorn logs for errors:
```bash
sudo tail -f /var/www/moh-planning/logs/gunicorn-error.log
```

4. Verify Nginx configuration:
```bash
sudo nginx -t
```

### 13.3 CSRF issues with API calls

1. Verify CSRF settings in .env file:
```bash
sudo nano /var/www/moh-planning/.env
```

2. Make sure CSRF_TRUSTED_ORIGINS includes all domains/IPs:
```
CSRF_TRUSTED_ORIGINS=http://196.190.255.168,http://196.190.251.168,http://your-domain.com
```

3. Ensure the frontend is making API calls with the correct CSRF header:
```bash
sudo nano /var/www/moh-planning/src/lib/api.ts
```

Look for code like:
```typescript
api.interceptors.request.use(
  (config) => {
    // Add CSRF token to requests if available
    const csrfToken = Cookies.get('csrftoken');
    if (csrfToken) {
      config.headers['X-CSRFToken'] = csrfToken;
    }
    return config;
  },
  ...
```

4. Restart the application to apply changes:
```bash
sudo systemctl restart moh-planning
```

### 13.4 Static files not loading

1. Verify static files were collected:
```bash
ls -la /var/www/moh-planning/staticfiles/
```

2. If missing, collect them:
```bash
cd /var/www/moh-planning
source venv/bin/activate
python manage.py collectstatic --noinput
```

3. Check Nginx configuration:
```bash
sudo cat /etc/nginx/sites-available/moh-planning
```

4. Look for correct static files configuration:
```
location /static/ {
    alias /var/www/moh-planning/staticfiles/;
    ...
}
```

## 14. Maintenance

### 14.1 Set up database backups
```bash
sudo nano /var/www/moh-planning/backup.sh
```

Content:
```bash
#!/bin/bash
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="/var/backups/moh-planning"
mkdir -p $BACKUP_DIR
mysqldump -u moh_user -p'secure_password' organization_db | gzip > "$BACKUP_DIR/db_backup_$TIMESTAMP.sql.gz"
# Keep only last 10 backups
find $BACKUP_DIR -type f -name "db_backup_*" | sort -r | tail -n +11 | xargs -r rm
```

Make it executable and set up cron job:
```bash
sudo chmod +x /var/www/moh-planning/backup.sh
sudo crontab -e
```

Add to run daily at 2 AM:
```
0 2 * * * /var/www/moh-planning/backup.sh
```

### 14.2 Set up log rotation
```bash
sudo nano /etc/logrotate.d/moh-planning
```

Content:
```
/var/www/moh-planning/logs/*.log {
    daily
    missingok
    rotate 7
    compress
    delaycompress
    notifempty
    create 0640 www-data www-data
    sharedscripts
    postrotate
        systemctl reload moh-planning
    endscript
}
```

## 15. Quick Troubleshooting Script

Create a troubleshooting script for quick diagnostics:

```bash
sudo nano /var/www/moh-planning/troubleshoot.sh
```

Content:
```bash
#!/bin/bash

echo "=== MOH Planning Troubleshooter ==="
echo "Running basic diagnostics..."

# Check service status
echo "Checking services status..."
sudo systemctl status moh-planning --no-pager || true
sudo systemctl status nginx --no-pager || true

# Check ports
echo -e "\nChecking port bindings..."
sudo ss -tlnp | grep -E ':80|:8000' || echo "No services found on ports 80 or 8000"

# Check logs
echo -e "\nChecking recent error logs..."
echo "Nginx errors:"
sudo tail -n 15 /var/log/nginx/moh-planning-error.log || echo "No Nginx error log found"
echo -e "\nGunicorn errors:"
sudo tail -n 15 /var/www/moh-planning/logs/gunicorn-error.log || echo "No Gunicorn error log found"

# Test backend connectivity
echo -e "\nTesting direct backend connectivity..."
curl -I http://127.0.0.1:8000/api/auth/check/ || echo "Backend not responding"

# Check file existence
echo -e "\nChecking critical files..."
[ -f /var/www/moh-planning/dist/index.html ] && echo "✓ Frontend index.html exists" || echo "✗ Frontend index.html missing"
[ -d /var/www/moh-planning/staticfiles/admin ] && echo "✓ Django admin static files exist" || echo "✗ Django admin static files missing"
[ -f /var/www/moh-planning/.env ] && echo "✓ Environment file exists" || echo "✗ Environment file missing"

# Check database connectivity
echo -e "\nChecking database connectivity..."
cd /var/www/moh-planning
source venv/bin/activate
python -c "import django; django.setup(); from django.db import connections; connections['default'].ensure_connection()" && echo "✓ Database connection successful" || echo "✗ Database connection failed"

echo -e "\n=== Troubleshooting completed ==="
```

Make it executable:
```bash
sudo chmod +x /var/www/moh-planning/troubleshoot.sh
```

## 16. Deployment Checklist

- [ ] Server has required packages installed
- [ ] Database is created and configured
- [ ] Python dependencies are installed
- [ ] Frontend is built and in the dist directory
- [ ] Django static files are collected
- [ ] .env file is configured with correct settings
- [ ] Gunicorn configuration is in place
- [ ] Systemd service is created and enabled
- [ ] Nginx configuration is correct and enabled
- [ ] File permissions are set properly
- [ ] Error pages are in place
- [ ] Services are running without errors
- [ ] You can access the admin interface at http://your-server-ip/admin/
- [ ] You can access the API at http://your-server-ip/api/
- [ ] The frontend loads correctly at http://your-server-ip/

This guide provides a comprehensive, error-free deployment process for the Ministry of Health Planning application on an Ubuntu VPS with Nginx.