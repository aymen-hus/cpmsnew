#!/bin/bash
set -e

echo "=== Fixing 502 Bad Gateway Error ==="
echo "Running diagnostics..."

# Create necessary directories
sudo mkdir -p /var/www/moh-planning/logs
sudo mkdir -p /var/www/moh-planning/staticfiles
sudo chown -R www-data:www-data /var/www/moh-planning

# Copy configuration files
echo "Updating configuration files..."
sudo cp moh-planning.nginx.conf /etc/nginx/sites-available/moh-planning
sudo cp gunicorn.conf.py /var/www/moh-planning/
sudo cp moh-planning.service /etc/systemd/system/

# Ensure static files are collected
echo "Checking for Django static files..."
if [ ! -d "/var/www/moh-planning/staticfiles/admin" ]; then
    echo "Collecting Django static files..."
    cd /var/www/moh-planning
    source venv/bin/activate
    python manage.py collectstatic --noinput
    deactivate
    sudo chown -R www-data:www-data /var/www/moh-planning/staticfiles
fi

# Reload systemd to apply service changes
echo "Reloading systemd daemon..."
sudo systemctl daemon-reload

# Test Nginx configuration
echo "Testing Nginx configuration..."
sudo nginx -t

# Restart services
echo "Restarting services..."
sudo systemctl restart moh-planning
sudo systemctl restart nginx

# Check service status
echo "Checking service status..."
echo "=== Gunicorn service status ==="
sudo systemctl status moh-planning --no-pager || true
echo
echo "=== Nginx status ==="
sudo systemctl status nginx --no-pager || true

# Check network connections
echo
echo "=== Network connections ==="
echo "Checking if Gunicorn is listening on port 8000..."
sudo ss -tlnp | grep 8000 || echo "⚠️ Nothing appears to be listening on port 8000!"

echo
echo "=== Log file information ==="
echo "Checking recent Gunicorn error log:"
sudo tail -n 20 /var/www/moh-planning/logs/gunicorn-error.log 2>/dev/null || echo "No Gunicorn error log found"
echo
echo "Checking recent Nginx error log:"
sudo tail -n 20 /var/log/nginx/moh-planning-error.log 2>/dev/null || echo "No Nginx error log found"

echo
echo "=== Fix completed ==="
echo "If the 502 error persists, try these troubleshooting steps:"
echo "1. Manually check if gunicorn is running: ps aux | grep gunicorn"
echo "2. Try starting gunicorn manually to see any errors:"
echo "   cd /var/www/moh-planning && venv/bin/gunicorn core.wsgi:application --bind 127.0.0.1:8000"
echo "3. Check logs for more details:"
echo "   - Gunicorn: /var/www/moh-planning/logs/gunicorn-error.log"
echo "   - Nginx: /var/log/nginx/moh-planning-error.log"
echo "   - System: sudo journalctl -u moh-planning -n 50"