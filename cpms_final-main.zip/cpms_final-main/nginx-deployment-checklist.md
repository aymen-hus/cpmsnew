# Nginx Deployment Checklist for MOH Planning Application

Use this checklist to ensure all aspects of your Nginx configuration are properly set up for the MOH Planning application.

## 1. Basic Configuration

- [ ] Server block is correctly configured for your domain/IP
- [ ] Document root is set to `/var/www/moh-planning/dist`
- [ ] Static files location is properly configured
- [ ] Media files location is properly configured
- [ ] Proxy settings for backend are correct
- [ ] Error pages are properly configured

## 2. Proxy Configuration

- [ ] Proxy pass for API endpoints is set to `http://127.0.0.1:8000`
- [ ] Proxy pass for admin interface is set to `http://127.0.0.1:8000/admin/`
- [ ] `proxy_set_header Host $host` is included
- [ ] `proxy_set_header X-Real-IP $remote_addr` is included
- [ ] `proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for` is included
- [ ] `proxy_set_header X-Forwarded-Proto $scheme` is included

## 3. CORS Configuration

- [ ] CORS headers are properly set for API endpoints
- [ ] `Access-Control-Allow-Origin` is configured
- [ ] `Access-Control-Allow-Methods` includes all necessary methods
- [ ] `Access-Control-Allow-Headers` includes necessary headers (especially `X-CSRFToken`)
- [ ] OPTIONS method is properly handled for preflight requests

## 4. Timeouts

- [ ] `proxy_connect_timeout` is set to an appropriate value (recommended: 60s)
- [ ] `proxy_send_timeout` is set to an appropriate value (recommended: 60s)
- [ ] `proxy_read_timeout` is set to an appropriate value (recommended: 60s for regular endpoints, 300s for admin)
- [ ] Admin interface has extended timeouts configured

## 5. Buffer Sizes

- [ ] `proxy_buffer_size` is configured (recommended: 16k)
- [ ] `proxy_buffers` is configured (recommended: 8 16k)
- [ ] `proxy_busy_buffers_size` is configured (recommended: 32k)
- [ ] `client_max_body_size` is set to accommodate uploads (recommended: 10M)

## 6. Caching

- [ ] Static files have appropriate cache headers
- [ ] Media files have appropriate cache headers
- [ ] Cache headers are set properly for JS/CSS files

## 7. Frontend Routing

- [ ] SPA routing is configured correctly with `try_files $uri $uri/ /index.html`
- [ ] Frontend routes are excluded from backend proxy rules

## 8. Security

- [ ] Server tokens are disabled (`server_tokens off`)
- [ ] X-Frame-Options headers are set
- [ ] Content-Security-Policy is configured if needed
- [ ] SSL/TLS is configured if using HTTPS

## 9. Error Handling

- [ ] Custom error pages are configured for 500, 502, 503, 504 errors
- [ ] Error pages exist in the correct location
- [ ] Error logs are configured correctly

## 10. Testing

- [ ] Configuration syntax is valid (`nginx -t`)
- [ ] All locations resolve correctly
- [ ] Static files are served correctly
- [ ] API requests are properly proxied to the backend
- [ ] SPA routing works correctly
- [ ] Error pages display correctly when appropriate

## Troubleshooting Commands

```bash
# Test Nginx configuration
sudo nginx -t

# Check for syntax errors
sudo nginx -T | grep -i error

# View error logs
sudo tail -f /var/log/nginx/error.log
sudo tail -f /var/log/nginx/moh-planning-error.log

# Check if Nginx is listening on port 80
sudo ss -tulpn | grep :80

# Test a backend connection
curl -I http://localhost:8000/api/auth/check/

# Test frontend routing
curl -I http://your-server-ip/
```