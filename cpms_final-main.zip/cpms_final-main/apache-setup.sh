#!/bin/bash
set -e

echo "=== Setting up Apache for MOH Planning Application ==="

# Check if we're running as root
if [[ $EUID -ne 0 ]]; then
    echo "⚠️  This script should be run as root"
    echo "   Please run with: sudo ./apache-setup.sh"
    exit 1
fi

# Install required packages
echo "Installing required packages..."
apt-get update
apt-get install -y apache2 libapache2-mod-wsgi-py3 python3-dev default-libmysqlclient-dev build-essential

# Enable required Apache modules
echo "Enabling required Apache modules..."
a2enmod wsgi
a2enmod rewrite

# Create application directory structure
echo "Creating application directory structure..."
mkdir -p /var/www/moh-planning/logs
mkdir -p /var/www/moh-planning/staticfiles
mkdir -p /var/www/moh-planning/media
mkdir -p /var/www/moh-planning/dist

# Create Python virtual environment
echo "Setting up Python virtual environment..."
python3 -m venv /var/www/moh-planning/venv
/var/www/moh-planning/venv/bin/pip install --upgrade pip

# Copy configuration files
echo "Copying configuration files..."
cp apache-deployment-guide.md /var/www/moh-planning/DEPLOYMENT.md
cp moh-planning.apache.conf /etc/apache2/sites-available/moh-planning.conf

# Copy application files
echo "Copying application files..."
current_dir=$(pwd)
rsync -av --exclude={node_modules,venv,dist,.git} $current_dir/ /var/www/moh-planning/

# Copy .env file if it exists
if [ -f ".env.production" ]; then
    echo "Copying .env.production to /var/www/moh-planning/.env"
    cp .env.production /var/www/moh-planning/.env
else
    echo "⚠️ .env.production not found. Please create it manually."
fi

# Build frontend
echo "Building frontend..."
# Check if frontend is already built
if [ -d "$current_dir/dist" ]; then
    echo "Copying pre-built frontend..."
    cp -r $current_dir/dist/* /var/www/moh-planning/dist/
else
    echo "Building frontend from source..."
    npm ci
    npm run build
    cp -r dist/* /var/www/moh-planning/dist/
fi

# Install Python dependencies
echo "Installing Python dependencies..."
/var/www/moh-planning/venv/bin/pip install -r requirements.production.txt

# Collect static files
echo "Collecting static files..."
cd /var/www/moh-planning
/var/www/moh-planning/venv/bin/python manage.py collectstatic --noinput

# Run migrations
echo "Running database migrations..."
/var/www/moh-planning/venv/bin/python manage.py migrate

# Set permissions
echo "Setting correct permissions..."
chown -R www-data:www-data /var/www/moh-planning
chmod -R 755 /var/www/moh-planning/staticfiles
chmod -R 755 /var/www/moh-planning/media
chmod 664 /var/www/moh-planning/.env

# Enable site
echo "Enabling site..."
a2dissite 000-default.conf
a2ensite moh-planning.conf

# Test Apache configuration
echo "Testing Apache configuration..."
apache2ctl configtest

# Restart Apache
echo "Restarting Apache..."
systemctl restart apache2

echo "=== Apache setup completed ==="
echo "Your application should now be accessible at http://196.190.255.168/"
echo "If you encounter any issues, check the logs:"
echo "  - Apache error log: sudo tail -f /var/log/apache2/moh-planning-error.log"
echo "  - Django log: sudo tail -f /var/www/moh-planning/logs/django.log"