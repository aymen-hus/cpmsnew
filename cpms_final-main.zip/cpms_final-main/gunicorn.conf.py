# Gunicorn configuration file
import multiprocessing
import os

# Bind to localhost only (Nginx will proxy requests)
bind = "127.0.0.1:8000"

# Number of worker processes (2-4 x number of CPU cores)
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = "sync"

# Timeouts - increase for admin pages
timeout = 300

# Logging
log_dir = "/var/www/moh-planning/logs"
# Create logs directory if it doesn't exist
if not os.path.exists(log_dir):
    try:
        os.makedirs(log_dir)
    except:
        pass

accesslog = f"{log_dir}/gunicorn-access.log"
errorlog = f"{log_dir}/gunicorn-error.log"
loglevel = "debug"  # Increase log level for troubleshooting
capture_output = True  # Ensure all app output is captured

# Security and performance
max_requests = 1000
max_requests_jitter = 50
keepalive = 2

# Improve worker process name
proc_name = "moh-planning"

# Set low keep-alive to prevent long-running connections
keepalive = 2