#!/bin/bash
set -e

echo "=== Fixing 500 Internal Server Error ==="
echo "Running diagnostics..."

# Create necessary directories if they don't exist
sudo mkdir -p /var/www/moh-planning/logs
sudo mkdir -p /var/www/moh-planning/staticfiles
sudo mkdir -p /var/www/moh-planning/dist
sudo mkdir -p /var/www/moh-planning/media

# Check if we can find the issue in logs
echo "Checking logs for errors..."
echo "Nginx error log:"
sudo tail -n 20 /var/log/nginx/error.log /var/log/nginx/moh-planning-error.log 2>/dev/null || echo "No nginx error logs found"

echo "Django error log:"
sudo tail -n 20 /var/www/moh-planning/logs/django.log 2>/dev/null || echo "No Django log found"
sudo tail -n 20 /var/www/moh-planning/logs/gunicorn-error.log 2>/dev/null || echo "No Gunicorn error log found"

# Check server status
echo "Checking server status..."
if systemctl is-active --quiet nginx; then
  echo "✅ Nginx is running"
else
  echo "❌ Nginx is NOT running, starting it..."
  sudo systemctl start nginx
fi

if systemctl is-active --quiet moh-planning; then
  echo "✅ MOH Planning service is running"
else
  echo "❌ MOH Planning service is NOT running, starting it..."
  sudo systemctl start moh-planning
fi

# Test if Django backend is accessible
echo "Testing if Django backend is accessible..."
curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/api/auth/check/ || {
  echo "❌ Django backend is not accessible, checking what's listening on port 8000..."
  sudo ss -tlnp | grep :8000 || echo "Nothing is listening on port 8000"
  
  echo "Checking Gunicorn configuration..."
  cat /var/www/moh-planning/gunicorn.conf.py || echo "Gunicorn config not found"
  
  echo "Restarting MOH Planning service..."
  sudo systemctl restart moh-planning
}

# Check if frontend files exist
echo "Checking frontend files..."
if [ ! -f /var/www/moh-planning/dist/index.html ]; then
  echo "❌ Frontend files are missing or incomplete"
  echo "Looking for the build directory in the current directory..."
  
  if [ -d "dist" ] && [ -f "dist/index.html" ]; then
    echo "✅ Found local build, copying to server..."
    sudo cp -r dist/* /var/www/moh-planning/dist/
    sudo chown -R www-data:www-data /var/www/moh-planning/dist
  else
    echo "❌ Local build not found. Please run 'npm run build' and then copy the files"
  fi
else
  echo "✅ Frontend files exist"
fi

# Check if Django static files exist
echo "Checking Django static files..."
if [ ! -d /var/www/moh-planning/staticfiles/admin ]; then
  echo "❌ Django static files are missing, collecting them..."
  cd /var/www/moh-planning
  source venv/bin/activate
  python manage.py collectstatic --noinput
  sudo chown -R www-data:www-data /var/www/moh-planning/staticfiles
else
  echo "✅ Django static files exist"
fi

# Fix permissions
echo "Setting correct permissions..."
sudo chown -R www-data:www-data /var/www/moh-planning
sudo chmod -R 755 /var/www/moh-planning/staticfiles
sudo chmod -R 755 /var/www/moh-planning/media
sudo chmod -R 755 /var/www/moh-planning/dist

# Fix nginx configuration
echo "Updating Nginx configuration..."
sudo cp moh-planning.nginx.conf /etc/nginx/sites-available/moh-planning
sudo ln -sf /etc/nginx/sites-available/moh-planning /etc/nginx/sites-enabled/moh-planning

# Check for default site and disable it if it exists
if [ -f /etc/nginx/sites-enabled/default ]; then
  echo "Disabling default Nginx site..."
  sudo rm /etc/nginx/sites-enabled/default
fi

# Test Nginx configuration
echo "Testing Nginx configuration..."
sudo nginx -t && {
  echo "✅ Nginx configuration is valid"
  echo "Restarting Nginx..."
  sudo systemctl restart nginx
} || {
  echo "❌ Nginx configuration is invalid"
  exit 1
}

# Fix .env file
echo "Checking .env configuration..."
if [ -f /var/www/moh-planning/.env ]; then
  echo "Updating .env file with correct values..."
  sudo sed -i 's/^DEBUG=.*/DEBUG=False/' /var/www/moh-planning/.env
  sudo sed -i 's/^ALLOWED_HOSTS=.*/ALLOWED_HOSTS=localhost,127.0.0.1,196.190.255.168,196.190.251.168/' /var/www/moh-planning/.env
  
  # Add proper CSRF_TRUSTED_ORIGINS if not already present
  if ! grep -q "CSRF_TRUSTED_ORIGINS" /var/www/moh-planning/.env; then
    echo "CSRF_TRUSTED_ORIGINS=http://localhost:5173,http://localhost:4173,http://196.190.255.168,http://196.190.251.168" | sudo tee -a /var/www/moh-planning/.env
  fi
else
  echo "❌ No .env file found, copying from .env.production..."
  sudo cp .env.production /var/www/moh-planning/.env
fi

# Fix 502.html to handle 500 errors as well
echo "Updating error page to handle 500 errors..."
if [ -f /var/www/moh-planning/dist/502.html ] && [ ! -f /var/www/moh-planning/dist/500.html ]; then
  sudo cp /var/www/moh-planning/dist/502.html /var/www/moh-planning/dist/500.html
fi

# Restart services one final time
echo "Restarting all services..."
sudo systemctl restart moh-planning
sudo systemctl restart nginx

echo "=== Fix completed ==="
echo "Try accessing your site again at http://196.190.251.168/"
echo ""
echo "If you still experience issues, check the logs:"
echo "  sudo tail -f /var/log/nginx/moh-planning-error.log"
echo "  sudo tail -f /var/www/moh-planning/logs/gunicorn-error.log"
echo "  sudo tail -f /var/www/moh-planning/logs/django.log"
echo ""
echo "You can also manually test the backend with:"
echo "  curl -v http://localhost:8000/api/auth/check/"