#!/bin/bash
set -e

echo "=== Checking Setup for MOH Planning Application ==="

# Check if required files exist
echo "Checking if required files exist..."
required_files=(
  "/var/www/moh-planning/gunicorn.conf.py"
  "/etc/systemd/system/moh-planning.service"
  "/etc/nginx/sites-available/moh-planning"
)

missing_files=0
for file in "${required_files[@]}"; do
  if [ ! -f "$file" ]; then
    echo "❌ Missing file: $file"
    missing_files=$((missing_files+1))
  else
    echo "✅ Found: $file"
  fi
done

if [ $missing_files -gt 0 ]; then
  echo "Found $missing_files missing files. Please run the fix-connection.sh script."
fi

# Check if services are running
echo "Checking if services are running..."
if systemctl is-active --quiet moh-planning; then
  echo "✅ moh-planning service is active"
else
  echo "❌ moh-planning service is not active"
fi

if systemctl is-active --quiet nginx; then
  echo "✅ nginx service is active"
else
  echo "❌ nginx service is not active"
fi

# Check if port 8000 is in use
echo "Checking if port 8000 is in use..."
if ss -tlnp | grep :8000 > /dev/null; then
  echo "✅ Port 8000 is in use"
else
  echo "❌ Port 8000 is not in use"
fi

# Check if we can connect to port 8000
echo "Testing connection to Django backend..."
if curl -s --max-time 5 http://localhost:8000 > /dev/null; then
  echo "✅ Successfully connected to Django backend"
else
  echo "❌ Failed to connect to Django backend"
fi

# Display recent log entries
echo "Recent logs from gunicorn:"
tail -n 10 /var/www/moh-planning/logs/gunicorn-error.log 2>/dev/null || echo "No gunicorn error log found"

echo "Recent logs from nginx:"
tail -n 10 /var/log/nginx/moh-planning-error.log 2>/dev/null || echo "No nginx error log found"

echo "=== Check completed ==="