#!/bin/bash
set -e

echo "=== Fixing Connection Error Between Nginx and Django ==="
echo "Diagnosing the issue..."

# Check if the gunicorn service is running
echo "Checking if moh-planning service is running..."
if sudo systemctl is-active --quiet moh-planning; then
  echo "✅ The moh-planning service is running"
else
  echo "❌ The moh-planning service is NOT running"
  echo "Starting the service..."
  sudo systemctl start moh-planning
  
  # Check if it started successfully
  if sudo systemctl is-active --quiet moh-planning; then
    echo "✅ Successfully started the moh-planning service"
  else
    echo "❌ Failed to start the service. Checking logs..."
    sudo journalctl -u moh-planning -n 30 --no-pager
    exit 1
  fi
fi

# Check if something is actually listening on port 8000
echo "Checking if anything is listening on port 8000..."
if sudo ss -tlnp | grep :8000 > /dev/null; then
  echo "✅ Something is listening on port 8000"
else
  echo "❌ Nothing is listening on port 8000"
  echo "This indicates Gunicorn isn't binding to the port correctly"
  
  # Check the gunicorn configuration
  echo "Checking gunicorn configuration..."
  if grep -q "bind = \"127.0.0.1:8000\"" /var/www/moh-planning/gunicorn.conf.py; then
    echo "✅ Gunicorn configuration has the correct binding"
  else
    echo "❌ Gunicorn configuration might have incorrect binding"
    
    # Fix the gunicorn configuration
    echo "Updating gunicorn configuration..."
    sudo cp gunicorn.conf.py /var/www/moh-planning/
    sudo chown www-data:www-data /var/www/moh-planning/gunicorn.conf.py
    
    # Restart the service
    echo "Restarting moh-planning service..."
    sudo systemctl restart moh-planning
  fi
  
  # Check again if it's listening
  if sudo ss -tlnp | grep :8000 > /dev/null; then
    echo "✅ Successfully fixed - now listening on port 8000"
  else
    echo "❌ Still not listening on port 8000 after configuration change"
    echo "Let's check the service logs:"
    sudo journalctl -u moh-planning -n 30 --no-pager
  fi
fi

# Check if we can connect to the backend directly
echo "Testing direct connection to the Django backend..."
if curl -s --max-time 5 http://localhost:8000/api/auth/check/ > /dev/null; then
  echo "✅ Successfully connected to Django backend directly"
else
  echo "❌ Failed to connect to Django backend directly"
  echo "This suggests the Django service is running but not responding properly"
  
  # Try a more comprehensive restart
  echo "Performing a complete restart of the Django service..."
  sudo systemctl stop moh-planning
  sleep 2
  sudo systemctl start moh-planning
  sleep 5
  
  # Check status after restart
  sudo systemctl status moh-planning --no-pager
fi

# Check nginx configuration
echo "Checking nginx configuration..."
if sudo nginx -t; then
  echo "✅ Nginx configuration is valid"
else
  echo "❌ Nginx configuration has errors"
  echo "Updating nginx configuration..."
  sudo cp moh-planning.nginx.conf /etc/nginx/sites-available/moh-planning
  
  # Test again
  if sudo nginx -t; then
    echo "✅ Fixed Nginx configuration"
    echo "Reloading Nginx..."
    sudo systemctl reload nginx
  else
    echo "❌ Nginx configuration still has errors"
    exit 1
  fi
fi

# Check for specific upstream errors in logs
echo "Checking nginx error logs for upstream issues..."
if sudo grep -i "connect() failed" /var/log/nginx/moh-planning-error.log | tail -5; then
  echo "⚠️ Found upstream connection errors in the logs"
else
  echo "✅ No recent upstream errors found in logs"
fi

# Update .env file with proper settings if needed
echo "Checking .env configuration..."
if [ -f /var/www/moh-planning/.env ]; then
  if ! grep -q "ALLOWED_HOSTS=.*196.190.255.168" /var/www/moh-planning/.env; then
    echo "⚠️ Server IP not found in ALLOWED_HOSTS, updating..."
    sudo sed -i 's/ALLOWED_HOSTS=.*/ALLOWED_HOSTS=localhost,127.0.0.1,196.190.255.168,196.190.251.168/g' /var/www/moh-planning/.env
    echo "✅ Updated ALLOWED_HOSTS in .env"
    echo "Restarting service to apply changes..."
    sudo systemctl restart moh-planning
  else
    echo "✅ ALLOWED_HOSTS configuration looks good"
  fi
else
  echo "❌ No .env file found at /var/www/moh-planning/.env"
fi

echo "=== Fix completed ==="
echo "Try accessing your site again. If the issue persists:"
echo "1. Check firewall settings: sudo ufw status"
echo "2. Examine gunicorn logs: sudo cat /var/www/moh-planning/logs/gunicorn-error.log"
echo "3. Try manually starting gunicorn to see errors:"
echo "   cd /var/www/moh-planning && source venv/bin/activate && gunicorn core.wsgi:application --bind 127.0.0.1:8000"
echo "4. Check SELinux status if applicable: sudo sestatus"

echo "You can also run the diagnostics script: sudo ./troubleshoot.sh"